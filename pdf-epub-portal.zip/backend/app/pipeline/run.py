import json, sys, os
from .analyzer import analyze_pdf
from .structure import detect_structure
from .epub_builder import build_epub
from .validator import check_epub, run_epubcheck

def convert(pdf, outdir):
    os.makedirs(outdir, exist_ok=True); epub = os.path.join(outdir, "final.epub")
    pages, meta = analyze_pdf(pdf); ents = detect_structure(pages)
    stats = build_epub(ents, pages, meta, epub)
    checks = check_epub(epub); ec = run_epubcheck(epub)
    ocr = [p["page"] for p in pages if p["ocr_required"]]
    critical = bool(checks["duplicate_ids"] or checks["broken_links"] or checks["xml_errors"] or ocr
                    or not ec["executed"] or ec.get("errors"))
    report = {"pages": len(pages), "ocr_pages_unprocessed": ocr, "links": stats, **checks, "epubcheck": ec,
              "final_status": "FAIL" if critical else "PASS"}
    json.dump(report, open(os.path.join(outdir, "qa-report.json"), "w"), indent=2)
    return report

if __name__ == "__main__":
    print(json.dumps(convert(sys.argv[1], sys.argv[2]), indent=2))
