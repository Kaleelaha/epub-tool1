import fitz

def analyze_pdf(path):
    doc = fitz.open(path); pages = []
    for i, p in enumerate(doc, 1):
        blocks = []
        for b in p.get_text("dict")["blocks"]:
            if b["type"] != 0: continue
            lines = []
            for l in b["lines"]:
                t = "".join(s["text"] for s in l["spans"]).strip()
                if t: lines.append((t, max(s["size"] for s in l["spans"])))
            if lines: blocks.append(lines)
        chars = sum(len(t) for b in blocks for t, _ in b)
        pages.append({"page": i, "text_layer": chars > 20, "ocr_required": chars <= 20,
                      "images": len(p.get_images()), "blocks": blocks})
    return pages, doc.metadata
