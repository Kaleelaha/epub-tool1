import re, zipfile, os, shutil, subprocess
from lxml import etree

def check_epub(path):
    ids, dups, broken, xml_errors = {}, [], [], []
    with zipfile.ZipFile(path) as z:
        docs = {n: z.read(n) for n in z.namelist() if n.endswith(".xhtml")}
    for n, data in docs.items():
        try: root = etree.fromstring(data)
        except etree.XMLSyntaxError as e: xml_errors.append(f"{n}: {e}"); continue
        ids[n] = [e.get("id") for e in root.iter() if e.get("id")]
    flat = [i for v in ids.values() for i in v]
    dups = sorted({i for i in flat if flat.count(i) > 1})
    for n, data in docs.items():
        for h in re.findall(rb'href="([^"]+)"', data):
            h = h.decode()
            if h.startswith("http") or h.endswith(".css"): continue
            f, _, frag = h.partition("#")
            tgt = os.path.normpath(os.path.join(os.path.dirname(n), f)).replace("\\", "/") if f else n
            if tgt not in ids or (frag and frag not in ids[tgt]): broken.append(f"{n} -> {h}")
    return {"duplicate_ids": dups, "broken_links": broken, "xml_errors": xml_errors}

def run_epubcheck(path):
    jar = os.environ.get("EPUBCHECK_PATH")
    if not (jar and os.path.exists(jar) and shutil.which("java")):
        return {"executed": False, "status": "EPUBCheck unavailable"}
    r = subprocess.run(["java", "-jar", jar, path], capture_output=True, text=True, timeout=300)
    out = r.stdout + r.stderr
    return {"executed": True, "errors": len(re.findall(r"^ERROR", out, re.M)),
            "warnings": len(re.findall(r"^WARNING", out, re.M)), "output": out[-4000:]}
