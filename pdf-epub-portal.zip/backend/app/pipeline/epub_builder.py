import re, zipfile, uuid
from html import escape
NS = ('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" '
      'xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="en" lang="en"><head><meta charset="utf-8"/>'
      '<title>{t}</title><link rel="stylesheet" type="text/css" href="../styles/Styles.css"/></head><body>{b}</body></html>')
CSS = "body{font-family:serif;line-height:1.4}h1,h2,h3{font-family:sans-serif}p.caption{font-style:italic}\n"
REF = re.compile(r"\b(Section|Figure|Table|Chapter)\s+(\d+(?:\.\d+)*)")

def _split(ents):
    chaps, cur = [], []
    for e in ents:
        if e["type"] == "heading" and e["level"] == 1 and cur: chaps.append(cur); cur = []
        cur.append(e)
    if cur: chaps.append(cur)
    return chaps

def build_model(ents):
    """assign deterministic ids + file names; returns chapters and target map."""
    chaps, targets, used = _split(ents), {}, set()
    for ci, ch in enumerate(chaps, 1):
        fn = f"Chapter{ci:02d}.xhtml"
        for n, e in enumerate(ch):
            e["file"] = fn
            if e["type"] == "heading":
                m = re.match(r"^(?:(?:Chapter|Section)\s+)?(\d+(?:\.\d+)*)", e["text"])
                e["id"] = ("sec" + m.group(1).replace(".", "-")) if m else f"chap{ci:02d}-h{n}"
                if m: targets[("Section", m.group(1))] = (fn, e["id"]); targets[("Chapter", m.group(1))] = (fn, e["id"])
            elif e["type"] == "caption":
                m = REF.match(e["text"])
                kind, num = m.groups(); e["id"] = ("f" if kind == "Figure" else "t") + num
                targets[(kind, num)] = (fn, e["id"])
            if e.get("id") in used: e["id"] += f"-{n}"
            if "id" in e: used.add(e["id"])
    return chaps, targets

def _link(text, fn, targets, stats):
    def sub(m):
        t = targets.get((m.group(1), m.group(2)))
        if not t: stats["unresolved"] += 1; return m.group(0)
        stats["resolved"] += 1
        return f'<a href="{"" if t[0]==fn else t[0]}#{t[1]}">{m.group(0)}</a>'
    return REF.sub(sub, escape(text))

def build_epub(ents, pages, meta, out):
    chaps, targets = build_model(ents); stats = {"resolved": 0, "unresolved": 0}
    title = (meta or {}).get("title") or "Untitled"; author = (meta or {}).get("author") or ""
    files, headings, seen_pages, page_file = {}, [], set(), {}
    for ci, ch in enumerate(chaps, 1):
        fn = f"Chapter{ci:02d}.xhtml"; body = []
        for e in ch:
            if e["page"] not in seen_pages:
                seen_pages.add(e["page"]); page_file[e["page"]] = fn; pid = f'page_{e["page"]}'
                body.append(f'<span id="{pid}" aria-label="page {e["page"]}" epub:type="pagebreak" role="doc-pagebreak"> </span>')
            t = e["type"]
            if t == "heading":
                body.append(f'<h{e["level"]} id="{e["id"]}">{escape(e["text"])}</h{e["level"]}>')
                if e["level"] <= 2: headings.append((fn, e["id"], e["text"]))
            elif t == "list": body.append("<ul>" + "".join(f"<li>{_link(i, fn, targets, stats)}</li>" for i in e["items"]) + "</ul>")
            elif t == "caption": body.append(f'<p class="caption" id="{e["id"]}">{escape(e["text"])}</p>')
            else: body.append(f'<p class="text">{_link(e["text"], fn, targets, stats)}</p>')
        files[fn] = NS.format(t=escape(title), b="\n".join(body))
    toc = "".join(f'<li><a href="xhtml/{f}#{i}">{escape(t)}</a></li>' for f, i, t in headings) or f'<li><a href="xhtml/{next(iter(files))}">{escape(title)}</a></li>'
    plist = "".join(f'<li><a href="xhtml/{page_file[p]}#page_{p}">{p}</a></li>' for p in sorted(seen_pages))  # simplified target
    nav = NS.format(t="Contents", b=f'<nav epub:type="toc" id="toc"><h1>Contents</h1><ol>{toc}</ol></nav>'
                    f'<nav epub:type="landmarks" hidden="hidden"><ol><li><a epub:type="bodymatter" href="xhtml/{next(iter(files))}">Start</a></li></ol></nav>'
                    f'<nav epub:type="page-list" hidden="hidden"><ol>{plist}</ol></nav>').replace("../styles", "styles")
    items = "".join(f'<item id="c{i}" href="xhtml/{f}" media-type="application/xhtml+xml"/>' for i, f in enumerate(files))
    refs = "".join(f'<itemref idref="c{i}"/>' for i in range(len(files)))
    opf = ('<?xml version="1.0" encoding="UTF-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid">'
           f'<metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="uid">urn:uuid:{uuid.uuid4()}</dc:identifier>'
           f'<dc:title>{escape(title)}</dc:title>' + (f'<dc:creator>{escape(author)}</dc:creator>' if author else "") +
           '<dc:language>en</dc:language><meta property="dcterms:modified">2026-01-01T00:00:00Z</meta></metadata><manifest>'
           '<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>'
           '<item id="css" href="styles/Styles.css" media-type="text/css"/>' + items + f'</manifest><spine>{refs}</spine></package>')
    with zipfile.ZipFile(out, "w") as z:
        z.writestr(zipfile.ZipInfo("mimetype"), "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        z.writestr("META-INF/container.xml", '<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>', compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("OEBPS/content.opf", opf, compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("OEBPS/nav.xhtml", nav, compress_type=zipfile.ZIP_DEFLATED)
        z.writestr("OEBPS/styles/Styles.css", CSS, compress_type=zipfile.ZIP_DEFLATED)
        for f, x in files.items(): z.writestr(f"OEBPS/xhtml/{f}", x, compress_type=zipfile.ZIP_DEFLATED)
    return stats
