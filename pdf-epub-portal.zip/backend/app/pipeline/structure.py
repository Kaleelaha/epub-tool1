import re, statistics
BUL = re.compile(r"^[•\-–*]\s+")

def detect_structure(pages):
    sizes = [round(s) for p in pages for b in p["blocks"] for t, s in b for _ in t]
    body = statistics.median(sizes) if sizes else 11
    ents = []
    for p in pages:
        for b in p["blocks"]:
            text = " ".join(t for t, _ in b); size = max(s for _, s in b)
            if size >= body * 1.15 and len(text) < 120:
                lvl = 1 if size >= body * 1.6 else 2 if size >= body * 1.3 else 3
                ents.append({"type": "heading", "level": lvl, "text": text, "page": p["page"]})
            elif all(BUL.match(t) for t, _ in b):
                ents.append({"type": "list", "items": [BUL.sub("", t) for t, _ in b], "page": p["page"]})
            elif re.match(r"^(Figure|Table)\s+\d", text):
                ents.append({"type": "caption", "text": text, "page": p["page"]})
            else:
                ents.append({"type": "paragraph", "text": re.sub(r"(\w)- (\w)", r"\1\2", text), "page": p["page"]})
    return ents
