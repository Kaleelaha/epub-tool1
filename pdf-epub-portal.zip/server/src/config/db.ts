import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { ENV } from './env';
import { logger } from '../utils/logger';

let mongoMemoryServer: MongoMemoryServer | null = null;

export const connectDB = async (): Promise<void> => {
  try {
    await mongoose.connect(ENV.MONGO_URL, {
      serverSelectionTimeoutMS: 2000
    });
    logger.info(`MongoDB connected to ${ENV.MONGO_URL}`);
  } catch (err) {
    logger.warn(`Could not connect to local MongoDB (${(err as Error).message}). Starting auto in-memory MongoDB server...`);
    try {
      mongoMemoryServer = await MongoMemoryServer.create({
        instance: { port: 27017, dbName: 'pdf_epub_portal' }
      });
      const uri = mongoMemoryServer.getUri();
      await mongoose.connect(uri);
      logger.info(`In-Memory MongoDB server started & connected at ${uri}`);
    } catch (memErr) {
      // If port 27017 is used by another instance or random port
      mongoMemoryServer = await MongoMemoryServer.create();
      const uri = mongoMemoryServer.getUri();
      await mongoose.connect(uri);
      logger.info(`In-Memory MongoDB connected at ${uri}`);
    }
  }
};
