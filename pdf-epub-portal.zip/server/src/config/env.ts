import dotenv from 'dotenv';
import path from 'path';

dotenv.config();

export const ENV = {
  PORT: process.env.PORT || '5000',
  MONGO_URL: process.env.MONGO_URL || 'mongodb://localhost:27017/pdf_epub_portal',
  JWT_SECRET: process.env.JWT_SECRET || 'super-secret-jwt-key-epub-portal-2026',
  UPLOAD_DIR: process.env.UPLOAD_DIR || path.join(__dirname, '../../../storage/uploads'),
  OUTPUT_DIR: process.env.OUTPUT_DIR || path.join(__dirname, '../../../storage/output'),
  PROCESSING_DIR: path.join(__dirname, '../../../storage/processing'),
  EPUBCHECK_PATH: process.env.EPUBCHECK_PATH || '',
  MAX_UPLOAD_SIZE: parseInt(process.env.MAX_UPLOAD_SIZE || '52428800', 10), // 50MB
  OCR_LANGUAGE: process.env.OCR_LANGUAGE || 'eng',
  PYTHON_BIN: process.env.PYTHON_BIN || 'py',
  CLIENT_ORIGIN: process.env.CLIENT_ORIGIN || '*'
};
