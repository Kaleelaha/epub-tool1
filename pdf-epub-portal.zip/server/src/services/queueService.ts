import { Job, IJob } from '../models/job';
import { Project } from '../models/project';
import { Types } from 'mongoose';

export class QueueService {
  static async enqueueJob(projectId: string, config: Record<string, any> = {}): Promise<IJob> {
    // Reset job if already exists or create new
    await Job.deleteMany({ project: projectId });
    
    const job = await Job.create({
      project: projectId,
      type: 'conversion',
      status: 'PENDING',
      config
    });

    await Project.findByIdAndUpdate(projectId, {
      status: 'PENDING',
      progress: 0,
      currentStage: 'queued',
      errorMessage: null
    });

    return job;
  }

  static async claimJob(): Promise<IJob | null> {
    // Atomic findOneAndUpdate claiming
    const job = await Job.findOneAndUpdate(
      { status: 'PENDING', attempts: { $lt: 3 } },
      { 
        status: 'PROCESSING', 
        lockedAt: new Date(), 
        $inc: { attempts: 1 },
        updatedAt: new Date()
      },
      { sort: { createdAt: 1 }, new: true }
    );
    return job;
  }

  static async setCancelFlag(projectId: string): Promise<boolean> {
    const job = await Job.findOneAndUpdate(
      { project: projectId, status: 'PROCESSING' },
      { cancelFlag: true, status: 'CANCELLED', updatedAt: new Date() },
      { new: true }
    );

    await Project.findByIdAndUpdate(projectId, {
      status: 'CANCELLED',
      errorMessage: 'Pipeline processing cancelled by user.'
    });

    return !!job;
  }
}
