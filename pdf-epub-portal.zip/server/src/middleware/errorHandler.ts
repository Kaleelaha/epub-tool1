import { Request, Response, NextFunction } from 'express';
import multer from 'multer';
import { logger } from '../utils/logger';

export const errorHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
  logger.error({ err, path: req.path }, 'Unhandled API Error');
  
  let status = err.status || err.statusCode;

  if (!status) {
    if (err instanceof multer.MulterError || (err.message && err.message.includes('PDF files are allowed'))) {
      status = 400;
    } else {
      status = 500;
    }
  }

  const message = status === 500 ? 'Internal Server Error' : (err.message || 'An error occurred');
  
  // Never expose server file paths or internal stack traces to users
  res.status(status).json({
    error: message
  });
};
