import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import swaggerUi from 'swagger-ui-express';
import { connectDB } from './config/db';
import { ENV } from './config/env';
import { logger } from './utils/logger';
import { openApiSpec } from './utils/openapi';
import authRoutes from './routes/authRoutes';
import projectRoutes from './routes/projectRoutes';
import pipelineRoutes from './routes/pipelineRoutes';
import dataRoutes from './routes/dataRoutes';
import { errorHandler } from './middleware/errorHandler';
import { startWorker } from './worker';

const app = express();

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(cors({
  origin: ENV.CLIENT_ORIGIN === '*' ? true : ENV.CLIENT_ORIGIN,
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Swagger OpenAPI documentation route
app.use('/docs', swaggerUi.serve, swaggerUi.setup(openApiSpec));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/projects', pipelineRoutes);
app.use('/api/projects', dataRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Centralized Error Handler
app.use(errorHandler);

export const serverApp = app;

if (require.main === module) {
  connectDB().then(() => {
    app.listen(ENV.PORT, () => {
      logger.info(`Server running on port ${ENV.PORT}. API docs available at http://localhost:${ENV.PORT}/docs`);
    });
    // Start background job worker
    startWorker().catch((err) => logger.error(`Worker failed: ${err.message}`));
  });
}
