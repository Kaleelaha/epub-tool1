export const openApiSpec = {
  openapi: "3.0.0",
  info: {
    title: "PDF to EPUB 3 Conversion API",
    version: "1.0.0",
    description: "REST API for managing PDF to EPUB 3 conversion jobs, stages, validation, and QA reports."
  },
  servers: [
    { url: "/api", description: "API Base Path" }
  ],
  components: {
    securitySchemes: {
      bearerAuth: {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT"
      }
    }
  },
  security: [{ bearerAuth: [] }],
  paths: {
    "/auth/register": {
      post: {
        summary: "Register new user",
        requestBody: {
          content: { "application/json": { schema: { type: "object", properties: { email: { type: "string" }, password: { type: "string" } } } } }
        },
        responses: { "201": { description: "User registered" } }
      }
    },
    "/auth/login": {
      post: {
        summary: "Login user",
        requestBody: {
          content: { "application/json": { schema: { type: "object", properties: { email: { type: "string" }, password: { type: "string" } } } } }
        },
        responses: { "200": { description: "User logged in with JWT" } }
      }
    },
    "/projects": {
      get: { summary: "List projects", responses: { "200": { description: "List of projects" } } },
      post: { summary: "Create new project", responses: { "201": { description: "Project created" } } }
    },
    "/projects/{id}/start": {
      post: { summary: "Start conversion pipeline", responses: { "200": { description: "Pipeline queued" } } }
    },
    "/projects/{id}/pipeline": {
      get: { summary: "Get pipeline progress & steps", responses: { "200": { description: "Pipeline status" } } }
    }
  }
};
