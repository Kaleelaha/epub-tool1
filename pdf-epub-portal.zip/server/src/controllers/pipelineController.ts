import { Response } from 'express';
import { Project } from '../models/project';
import { PipelineStep } from '../models/dataModels';
import { QueueService } from '../services/queueService';
import { AuthRequest } from '../middleware/auth';

export const startPipeline = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (req.user?.role !== 'admin' && project.owner.toString() !== req.user?.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const job = await QueueService.enqueueJob(id, {
      pdf_path: project.sourcePdf,
      ocr_language: project.config.ocr_language || 'eng',
      epubcheck_path: process.env.EPUBCHECK_PATH || ''
    });

    return res.json({
      message: 'Conversion pipeline queued',
      jobId: job._id,
      project
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to start pipeline' });
  }
};

export const getPipelineStatus = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (req.user?.role !== 'admin' && project.owner.toString() !== req.user?.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const steps = await PipelineStep.find({ project: id }).sort({ createdAt: 1 });

    return res.json({
      projectStatus: project.status,
      progress: project.progress,
      currentStage: project.currentStage,
      errorMessage: project.errorMessage,
      steps
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch pipeline status' });
  }
};

export const cancelPipeline = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (req.user?.role !== 'admin' && project.owner.toString() !== req.user?.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    await QueueService.setCancelFlag(id);
    return res.json({ message: 'Pipeline cancellation requested' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to cancel pipeline' });
  }
};

export const retryPipeline = async (req: AuthRequest, res: Response) => {
  return startPipeline(req, res);
};

export const retryStep = async (req: AuthRequest, res: Response) => {
  return startPipeline(req, res);
};
