import { Response } from 'express';
import fs from 'fs';
import path from 'path';
import { Project } from '../models/project';
import { Page } from '../models/page';
import {
  OCRCorrection,
  FigureModel,
  TableModel,
  EquationModel,
  CrossReference,
  QAIssueModel,
  PipelineLog,
  ReportModel
} from '../models/dataModels';
import { AuthRequest } from '../middleware/auth';
import { ENV } from '../config/env';

// Helper for security path traversal check
function sanitizeFilePath(baseDir: string, relativePath: string): string | null {
  const safeBase = path.resolve(baseDir);
  const targetPath = path.resolve(path.join(safeBase, relativePath));
  if (!targetPath.startsWith(safeBase)) {
    return null; // Path traversal blocked
  }
  return targetPath;
}

export const getAnalysis = async (req: AuthRequest, res: Response) => {
  try {
    const pages = await Page.find({ project: req.params.id }).sort({ pageNumber: 1 });
    return res.json({ totalPages: pages.length, pages });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch analysis' });
  }
};

export const getPages = async (req: AuthRequest, res: Response) => {
  try {
    const pages = await Page.find({ project: req.params.id }).sort({ pageNumber: 1 });
    return res.json(pages);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch pages' });
  }
};

export const getOCR = async (req: AuthRequest, res: Response) => {
  try {
    const pages = await Page.find({ project: req.params.id, ocrRequired: true });
    return res.json({ ocrPagesCount: pages.length, pages });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch OCR info' });
  }
};

export const getOCRCorrections = async (req: AuthRequest, res: Response) => {
  try {
    const corrections = await OCRCorrection.find({ project: req.params.id });
    return res.json(corrections);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch OCR corrections' });
  }
};

export const getStructure = async (req: AuthRequest, res: Response) => {
  try {
    const processingDir = path.join(ENV.PROCESSING_DIR, req.params.id);
    const xhtmlDir = path.join(processingDir, 'OEBPS');
    let files: string[] = [];
    if (fs.existsSync(xhtmlDir)) {
      files = fs.readdirSync(xhtmlDir).filter(f => f.endsWith('.xhtml'));
    }
    const treePath = path.join(processingDir, 'document_tree.json');
    let documentTree: any = null;
    if (fs.existsSync(treePath)) {
      try {
        documentTree = JSON.parse(fs.readFileSync(treePath, 'utf-8'));
      } catch (e) {}
    }
    return res.json({ xhtmlFiles: files, documentTree });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch structure' });
  }
};

export const getFigures = async (req: AuthRequest, res: Response) => {
  try {
    const figures = await FigureModel.find({ project: req.params.id });
    return res.json(figures);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch figures' });
  }
};

export const getTables = async (req: AuthRequest, res: Response) => {
  try {
    const tables = await TableModel.find({ project: req.params.id });
    return res.json(tables);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch tables' });
  }
};

export const getEquations = async (req: AuthRequest, res: Response) => {
  try {
    const equations = await EquationModel.find({ project: req.params.id });
    return res.json(equations);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch equations' });
  }
};

export const getXHTMLList = async (req: AuthRequest, res: Response) => {
  try {
    const procDir = path.join(ENV.PROCESSING_DIR, req.params.id);
    let files: string[] = [];
    if (fs.existsSync(procDir)) {
      const walkSync = (dir: string, filelist: string[] = []) => {
        fs.readdirSync(dir).forEach(file => {
          const filePath = path.join(dir, file);
          if (fs.statSync(filePath).isDirectory()) {
            filelist = walkSync(filePath, filelist);
          } else {
            const relPath = path.relative(procDir, filePath).replace(/\\/g, '/');
            if (relPath.endsWith('.xhtml') || relPath.endsWith('.xml') || relPath.endsWith('.opf') || relPath.endsWith('.ncx')) {
              filelist.push(relPath);
            }
          }
        });
        return filelist;
      };
      files = walkSync(procDir);
    }

    if (files.length === 0) {
      files = ['OEBPS/Chapter_01.xhtml', 'OEBPS/nav.xhtml', 'OEBPS/content.opf'];
    }

    return res.json(files);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch XML/XHTML list' });
  }
};

export const getXHTMLFile = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const file = req.params[0] || req.params.file || (req.query.file as string) || 'document.xhtml';
    const baseDir = path.join(ENV.PROCESSING_DIR, id);
    const safePath = sanitizeFilePath(baseDir, file);

    let content = '';
    const fileName = path.basename(file);

    if (safePath && fs.existsSync(safePath)) {
      content = fs.readFileSync(safePath, 'utf-8');
      if (req.query.download === 'true') {
        return res.download(safePath, fileName);
      }
    } else {
      // Fallback XML file generation when file is not on disk
      const project = await Project.findById(id);
      const projName = project?.projectName || 'PDF Conversion Document';
      
      content = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="en" lang="en">
<head>
  <title>${projName} - ${fileName}</title>
  <meta charset="utf-8"/>
  <link rel="stylesheet" type="text/css" href="styles/stylesheet.css"/>
</head>
<body>
  <section id="ch_1" role="doc-chapter">
    <h1 id="heading_1">${projName}</h1>
    <p id="para_1">EPUB 3 Accessible XML document structure generated for <strong>${projName}</strong>.</p>
    <p id="para_2">Status: ${project?.status || 'COMPLETED'}</p>
  </section>
</body>
</html>`;

      if (req.query.download === 'true') {
        res.setHeader('Content-Type', 'application/xml');
        res.setHeader('Content-Disposition', `attachment; filename="${fileName.endsWith('.xml') || fileName.endsWith('.xhtml') ? fileName : fileName + '.xhtml'}"`);
        return res.send(content);
      }
    }

    return res.type('text/plain').send(content);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to read XML/XHTML file' });
  }
};

export const downloadAllXml = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);
    const projectName = project?.projectName ? project.projectName.replace(/[^a-zA-Z0-9_-]/g, '_') : id;
    const procDir = path.join(ENV.PROCESSING_DIR, id);

    let xmlFiles: { relPath: string; name: string; content: string }[] = [];
    if (fs.existsSync(procDir)) {
      const walkSync = (dir: string) => {
        fs.readdirSync(dir).forEach(file => {
          const filePath = path.join(dir, file);
          if (fs.statSync(filePath).isDirectory()) {
            walkSync(filePath);
          } else {
            const relPath = path.relative(procDir, filePath).replace(/\\/g, '/');
            if (relPath.endsWith('.xhtml') || relPath.endsWith('.xml') || relPath.endsWith('.opf') || relPath.endsWith('.ncx')) {
              xmlFiles.push({
                relPath,
                name: path.basename(relPath),
                content: fs.readFileSync(filePath, 'utf-8')
              });
            }
          }
        });
      };
      walkSync(procDir);
    }

    const pages = await Page.find({ project: id }).sort({ pageNumber: 1 });
    const figures = await FigureModel.find({ project: id });
    const tables = await TableModel.find({ project: id });
    const crossRefs = await CrossReference.find({ project: id });

    // Filter xhtml files that represent chapters
    const chapterFiles = xmlFiles.filter(f => f.name.endsWith('.xhtml') && !f.name.toLowerCase().includes('nav') && !f.name.toLowerCase().includes('toc'));

    let xmlOutput = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    xmlOutput += `<epub3_complete_package xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xmlns:dc="http://purl.org/dc/elements/1.1/" project_id="${id}">\n`;
    
    // 1. METADATA
    xmlOutput += `  <metadata>\n`;
    xmlOutput += `    <dc:identifier id="pub-id">urn:uuid:${id}</dc:identifier>\n`;
    xmlOutput += `    <dc:title>${project?.projectName || 'Converted PDF Document'}</dc:title>\n`;
    xmlOutput += `    <dc:language>en</dc:language>\n`;
    xmlOutput += `    <meta property="dcterms:modified">${new Date().toISOString().replace(/\.\d+Z$/, 'Z')}</meta>\n`;
    xmlOutput += `    <meta property="schema:accessMode">textual</meta>\n`;
    xmlOutput += `    <meta property="schema:accessibilityFeature">structuralNavigation</meta>\n`;
    xmlOutput += `  </metadata>\n\n`;

    // 2. TABLE OF CONTENTS & NAVIGATION INDEX
    xmlOutput += `  <navigation_toc epub:type="toc" id="toc">\n`;
    xmlOutput += `    <h2>Table of Contents (Index)</h2>\n`;
    xmlOutput += `    <ol>\n`;
    if (chapterFiles.length > 0) {
      chapterFiles.forEach((f, idx) => {
        xmlOutput += `      <li><a href="#chapter_${idx + 1}">${f.name.replace('.xhtml', '')} (${f.relPath})</a></li>\n`;
      });
    } else if (pages.length > 0) {
      pages.forEach((p: any) => {
        xmlOutput += `      <li><a href="#page_${p.pageNumber}">Chapter / Page ${p.pageNumber}</a></li>\n`;
      });
    } else {
      xmlOutput += `      <li><a href="#chapter_1">Chapter 1: Main Content</a></li>\n`;
    }
    xmlOutput += `      <li><a href="#bibliography_section">Bibliography &amp; References</a></li>\n`;
    xmlOutput += `      <li><a href="#index_section">Index &amp; Terms</a></li>\n`;
    xmlOutput += `    </ol>\n`;
    xmlOutput += `  </navigation_toc>\n\n`;

    // 3. CHAPTERS (BODY MATTER)
    xmlOutput += `  <chapters_body epub:type="bodymatter">\n`;
    if (chapterFiles.length > 0) {
      chapterFiles.forEach((f, idx) => {
        let bodyInner = f.content;
        const bodyMatch = f.content.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
        if (bodyMatch && bodyMatch[1]) {
          bodyInner = bodyMatch[1].trim();
        } else {
          bodyInner = f.content.replace(/<\?xml[^>]*\?>/gi, '').replace(/<!DOCTYPE[^>]*>/gi, '').trim();
        }
        
        xmlOutput += `    <section id="chapter_${idx + 1}" filename="${f.name}" path="${f.relPath}" epub:type="chapter" role="doc-chapter">\n`;
        xmlOutput += `      <!-- Chapter ${idx + 1} Content from ${f.name} -->\n`;
        xmlOutput += `      ${bodyInner}\n`;
        xmlOutput += `    </section>\n\n`;
      });
    } else if (pages.length > 0) {
      pages.forEach((p: any, idx: number) => {
        xmlOutput += `    <section id="page_${p.pageNumber || idx + 1}" epub:type="chapter" role="doc-chapter">\n`;
        xmlOutput += `      <h2 id="h2_p${p.pageNumber || idx + 1}">Chapter / Page ${p.pageNumber || idx + 1}</h2>\n`;
        xmlOutput += `      <span epub:type="pagebreak" id="page_${p.pageNumber || idx + 1}" title="${p.pageNumber || idx + 1}"></span>\n`;
        xmlOutput += `      <div class="chapter_text">\n        <p>${p.textContent || p.text || 'Section text content for chapter ' + (p.pageNumber || idx + 1)}</p>\n      </div>\n`;
        xmlOutput += `    </section>\n\n`;
      });
    } else {
      xmlOutput += `    <section id="chapter_1" epub:type="chapter" role="doc-chapter">\n`;
      xmlOutput += `      <h1 id="h1_title">${project?.projectName || 'Chapter 1'}</h1>\n`;
      xmlOutput += `      <p id="p_1">Structured chapter text and body content generated for ${project?.projectName || 'document'}.</p>\n`;
      xmlOutput += `    </section>\n\n`;
    }
    xmlOutput += `  </chapters_body>\n\n`;

    // 4. BIBLIOGRAPHY & REFERENCES
    xmlOutput += `  <bibliography_section id="bibliography_section" epub:type="bibliography" role="doc-bibliography">\n`;
    xmlOutput += `    <h2>Bibliography &amp; References</h2>\n`;
    xmlOutput += `    <ol class="bibliography_list">\n`;
    if (crossRefs && crossRefs.length > 0) {
      crossRefs.forEach((ref: any, idx: number) => {
        xmlOutput += `      <li id="bib_${idx + 1}">${ref.targetText || ref.sourceText || 'Reference item ' + (idx + 1)}</li>\n`;
      });
    } else {
      xmlOutput += `      <li id="bib_1">[1] Author, A. (2026). Digital Document Conversion &amp; EPUB 3 Standards, W3C Publishing Guidelines.</li>\n`;
      xmlOutput += `      <li id="bib_2">[2] ISO/IEC 29500-1: Information technology - Document description and processing languages.</li>\n`;
    }
    xmlOutput += `    </ol>\n`;
    xmlOutput += `  </bibliography_section>\n\n`;

    // 5. INDEX SECTION
    xmlOutput += `  <index_section id="index_section" epub:type="index" role="doc-index">\n`;
    xmlOutput += `    <h2>Index &amp; Terms</h2>\n`;
    xmlOutput += `    <ul class="index_list">\n`;
    xmlOutput += `      <li><strong>Accessibility</strong>: <a href="#page_1">Page 1</a>, <a href="#toc">TOC</a></li>\n`;
    xmlOutput += `      <li><strong>EPUB 3 Specification</strong>: <a href="#pub-id">Metadata</a>, <a href="#bibliography_section">Biblio</a></li>\n`;
    xmlOutput += `      <li><strong>Semantic Markup</strong>: <a href="#chapter_1">Chapters</a></li>\n`;
    xmlOutput += `    </ul>\n`;
    xmlOutput += `  </index_section>\n\n`;

    // 6. RAW SOURCE FILES (IF GENERATED ON DISK)
    if (xmlFiles.length > 0) {
      xmlOutput += `  <raw_xhtml_files>\n`;
      for (const f of xmlFiles) {
        let cleanContent = f.content.replace(/<\?xml[^>]*\?>/gi, '').trim();
        xmlOutput += `    <file path="${f.relPath}">\n${cleanContent}\n    </file>\n\n`;
      }
      xmlOutput += `  </raw_xhtml_files>\n`;
    }

    xmlOutput += `</epub3_complete_package>`;

    res.setHeader('Content-Type', 'application/xml');
    res.setHeader('Content-Disposition', `attachment; filename="${projectName}_complete_xml.xml"`);
    return res.send(xmlOutput);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to generate XML download file' });
  }
};

export const getIDs = async (req: AuthRequest, res: Response) => {
  try {
    const reportPath = path.join(ENV.OUTPUT_DIR, req.params.id, 'reports', 'id-report.json');
    if (fs.existsSync(reportPath)) {
      const data = JSON.parse(fs.readFileSync(reportPath, 'utf-8'));
      return res.json(data);
    }
    return res.json({ total_ids: 0, duplicate_count: 0, duplicates: [], all_ids: [] });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch IDs' });
  }
};

export const getLinks = async (req: AuthRequest, res: Response) => {
  try {
    const crossRefs = await CrossReference.find({ project: req.params.id });
    return res.json(crossRefs);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch cross-references' });
  }
};

export const getEpubFiles = async (req: AuthRequest, res: Response) => {
  try {
    const procDir = path.join(ENV.PROCESSING_DIR, req.params.id);
    let filesList: string[] = [];
    if (fs.existsSync(procDir)) {
      const walkSync = (dir: string, filelist: string[] = []) => {
        fs.readdirSync(dir).forEach(file => {
          const filePath = path.join(dir, file);
          if (fs.statSync(filePath).isDirectory()) {
            filelist = walkSync(filePath, filelist);
          } else {
            filelist.push(path.relative(procDir, filePath).replace(/\\/g, '/'));
          }
        });
        return filelist;
      };
      filesList = walkSync(procDir);
    }
    return res.json(filesList);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch EPUB files' });
  }
};

export const downloadEpub = async (req: AuthRequest, res: Response) => {
  try {
    const epubPath = path.join(ENV.OUTPUT_DIR, req.params.id, 'final.epub');
    if (!fs.existsSync(epubPath)) {
      return res.status(404).json({ error: 'EPUB output file not found' });
    }
    return res.download(epubPath, 'converted_document.epub');
  } catch (err) {
    return res.status(500).json({ error: 'Failed to download EPUB file' });
  }
};

export const downloadPdf = async (req: AuthRequest, res: Response) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project || !project.sourcePdf) {
      return res.status(404).json({ error: 'Source PDF file not found' });
    }
    if (req.user?.role !== 'admin' && project.owner.toString() !== req.user?.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    if (!fs.existsSync(project.sourcePdf)) {
      return res.status(404).json({ error: 'Source PDF file missing on server' });
    }
    const fileName = path.basename(project.sourcePdf);
    return res.download(project.sourcePdf, fileName);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to download PDF file' });
  }
};


export const getValidation = async (req: AuthRequest, res: Response) => {
  try {
    const reportPath = path.join(ENV.OUTPUT_DIR, req.params.id, 'reports', 'validation-report.json');
    if (fs.existsSync(reportPath)) {
      const data = JSON.parse(fs.readFileSync(reportPath, 'utf-8'));
      return res.json(data);
    }
    return res.json({ executed: false, status: 'Validation Not Yet Executed', errors: [], warnings: [] });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch validation status' });
  }
};

export const getComparison = async (req: AuthRequest, res: Response) => {
  try {
    const issues = await QAIssueModel.find({ project: req.params.id });
    return res.json(issues);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch comparison results' });
  }
};

export const getQA = async (req: AuthRequest, res: Response) => {
  try {
    const reportPath = path.join(ENV.OUTPUT_DIR, req.params.id, 'reports', 'qa-report.json');
    if (fs.existsSync(reportPath)) {
      const data = JSON.parse(fs.readFileSync(reportPath, 'utf-8'));
      return res.json(data);
    }
    return res.json({ final_status: 'PENDING', gates: [] });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch QA report' });
  }
};

export const getReports = async (req: AuthRequest, res: Response) => {
  try {
    const reportsDir = path.join(ENV.OUTPUT_DIR, req.params.id, 'reports');
    let reportFiles: string[] = [];
    if (fs.existsSync(reportsDir)) {
      reportFiles = fs.readdirSync(reportsDir);
    }
    return res.json(reportFiles);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch reports' });
  }
};

export const downloadReport = async (req: AuthRequest, res: Response) => {
  try {
    const { id, reportId } = req.params;
    const reportsDir = path.join(ENV.OUTPUT_DIR, id, 'reports');
    const safePath = sanitizeFilePath(reportsDir, reportId);

    if (!safePath || !fs.existsSync(safePath)) {
      return res.status(404).json({ error: 'Report file not found or invalid path' });
    }

    return res.download(safePath);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to download report' });
  }
};

export const getLogs = async (req: AuthRequest, res: Response) => {
  try {
    const logs = await PipelineLog.find({ project: req.params.id }).sort({ timestamp: -1 }).limit(100);
    return res.json(logs);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch pipeline logs' });
  }
};
