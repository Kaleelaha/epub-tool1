import { Response } from 'express';
import { z } from 'zod';
import fs from 'fs';
import path from 'path';
import { Project } from '../models/project';
import { AuthRequest } from '../middleware/auth';
import { ENV } from '../config/env';

export const createProjectSchema = z.object({
  projectName: z.string().min(1, 'Project name is required'),
  config: z.record(z.any()).optional()
});

export const getProjects = async (req: AuthRequest, res: Response) => {
  try {
    const filter = req.user?.role === 'admin' ? {} : { owner: req.user?.id };
    const projects = await Project.find(filter).sort({ createdAt: -1 });
    return res.json(projects);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch projects' });
  }
};

export const createProject = async (req: AuthRequest, res: Response) => {
  try {
    const { projectName, config } = req.body;
    const project = await Project.create({
      owner: req.user?.id,
      projectName,
      sourcePdf: 'pending_upload.pdf',
      config: config || {}
    });
    return res.status(201).json(project);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to create project' });
  }
};

export const getProjectById = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);
    
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (req.user?.role !== 'admin' && project.owner.toString() !== req.user?.id) {
      return res.status(403).json({ error: 'Access denied to this project' });
    }

    return res.json(project);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch project details' });
  }
};

export const deleteProject = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (req.user?.role !== 'admin' && project.owner.toString() !== req.user?.id) {
      return res.status(403).json({ error: 'Access denied to this project' });
    }

    await Project.findByIdAndDelete(id);
    return res.json({ message: 'Project deleted successfully' });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to delete project' });
  }
};

export const uploadPdf = async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (req.user?.role !== 'admin' && project.owner.toString() !== req.user?.id) {
      return res.status(403).json({ error: 'Access denied to this project' });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No PDF file uploaded' });
    }

    const fileSize = req.file.size;
    const sourcePdf = req.file.path;

    project.sourcePdf = sourcePdf;
    project.fileSize = fileSize;
    project.status = 'PENDING';
    project.updatedAt = new Date();
    await project.save();

    return res.json({
      message: 'PDF uploaded successfully',
      project
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to handle file upload' });
  }
};
