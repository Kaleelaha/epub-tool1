import { Router } from 'express';
import {
  getAnalysis,
  getPages,
  getOCR,
  getOCRCorrections,
  getStructure,
  getFigures,
  getTables,
  getEquations,
  getXHTMLList,
  getXHTMLFile,
  downloadAllXml,
  getIDs,
  getLinks,
  getEpubFiles,
  downloadEpub,
  downloadPdf,
  getValidation,
  getComparison,
  getQA,
  getReports,
  downloadReport,
  getLogs
} from '../controllers/dataController';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);

router.get('/:id/analysis', getAnalysis);
router.get('/:id/pages', getPages);
router.get('/:id/ocr', getOCR);
router.get('/:id/ocr/corrections', getOCRCorrections);
router.get('/:id/structure', getStructure);
router.get('/:id/figures', getFigures);
router.get('/:id/tables', getTables);
router.get('/:id/equations', getEquations);
router.get('/:id/xhtml', getXHTMLList);
router.get('/:id/xml/download', downloadAllXml);
router.get('/:id/xhtml/*', getXHTMLFile);
router.get('/:id/ids', getIDs);
router.get('/:id/links', getLinks);
router.get('/:id/epub/files', getEpubFiles);
router.get('/:id/epub/download', downloadEpub);
router.get('/:id/pdf/download', downloadPdf);
router.get('/:id/validation', getValidation);
router.post('/:id/validate', getValidation);
router.get('/:id/comparison', getComparison);
router.post('/:id/compare', getComparison);
router.get('/:id/qa', getQA);
router.get('/:id/reports', getReports);
router.get('/:id/reports/:reportId/download', downloadReport);
router.get('/:id/logs', getLogs);

export default router;
