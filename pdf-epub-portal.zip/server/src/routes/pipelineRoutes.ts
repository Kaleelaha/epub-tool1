import { Router } from 'express';
import {
  startPipeline,
  getPipelineStatus,
  cancelPipeline,
  retryPipeline,
  retryStep
} from '../controllers/pipelineController';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);

router.post('/:id/start', startPipeline);
router.get('/:id/pipeline', getPipelineStatus);
router.post('/:id/cancel', cancelPipeline);
router.post('/:id/pipeline/retry', retryPipeline);
router.post('/:id/pipeline/steps/:step/retry', retryStep);

export default router;
