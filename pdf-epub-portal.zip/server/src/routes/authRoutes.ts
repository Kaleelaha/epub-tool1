import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { register, login, getMe, registerSchema, loginSchema } from '../controllers/authController';
import { validateRequest } from '../middleware/validate';
import { authenticateToken } from '../middleware/auth';

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  message: { error: 'Too many login/register attempts. Please try again later.' }
});

const router = Router();

router.post('/register', authLimiter, validateRequest(registerSchema), register);
router.post('/login', authLimiter, validateRequest(loginSchema), login);
router.get('/me', authenticateToken, getMe);

export default router;
