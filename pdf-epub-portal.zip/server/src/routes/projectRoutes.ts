import { Router } from 'express';
import {
  getProjects,
  createProject,
  getProjectById,
  deleteProject,
  uploadPdf,
  createProjectSchema
} from '../controllers/projectController';
import { authenticateToken } from '../middleware/auth';
import { validateRequest } from '../middleware/validate';
import { upload, validateMagicBytes } from '../middleware/upload';

const router = Router();

router.use(authenticateToken);

router.get('/', getProjects);
router.post('/', validateRequest(createProjectSchema), createProject);
router.get('/:id', getProjectById);
router.delete('/:id', deleteProject);
router.post('/:id/upload', upload.single('file'), validateMagicBytes, uploadPdf);

export default router;
