import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import { connectDB } from '../config/db';
import { ENV } from '../config/env';
import { QueueService } from '../services/queueService';
import { Project } from '../models/project';
import { Job } from '../models/job';
import { Page } from '../models/page';
import {
  PipelineStep,
  OCRCorrection,
  FigureModel,
  TableModel,
  EquationModel,
  CrossReference,
  QAIssueModel,
  PipelineLog
} from '../models/dataModels';
import { logger } from '../utils/logger';

async function processJob(job: any) {
  const projectId = job.project.toString();
  logger.info(`Worker processing job ${job._id} for project ${projectId}`);

  const project = await Project.findById(projectId);
  if (!project) {
    logger.error(`Project ${projectId} not found`);
    return;
  }

  await Project.findByIdAndUpdate(projectId, {
    status: 'PROCESSING',
    currentStage: 'init',
    progress: 1
  });

  const configPath = path.join(ENV.PROCESSING_DIR, projectId, 'config.json');
  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  fs.writeFileSync(configPath, JSON.stringify({
    pdf_path: project.sourcePdf,
    ocr_language: ENV.OCR_LANGUAGE,
    epubcheck_path: ENV.EPUBCHECK_PATH
  }));

  const converterRoot = path.resolve(__dirname, '../../../converter');
  const pythonBin = ENV.PYTHON_BIN;

  return new Promise<void>((resolve) => {
    const child = spawn(pythonBin, ['-m', 'converter.cli', '--project', projectId, '--config', configPath], {
      cwd: converterRoot,
      env: { ...process.env, PYTHONPATH: converterRoot }
    });

    let stdoutData = '';

    child.stdout.on('data', async (chunk) => {
      const text = chunk.toString();
      stdoutData += text;
      const lines = text.split('\n');
      for (const line of lines) {
        if (line.trim().startsWith('{')) {
          try {
            const data = JSON.parse(line.trim());
            const { stage, status, progress, items, errors, warnings } = data;

            await Project.findByIdAndUpdate(projectId, {
              progress: Math.min(progress, 99),
              currentStage: stage
            });

            await PipelineStep.findOneAndUpdate(
              { project: projectId, name: stage },
              {
                status,
                progress,
                itemsProcessed: items || 0,
                errors: errors || [],
                warnings: warnings || [],
                updatedAt: new Date()
              },
              { upsert: true }
            );

            await PipelineLog.create({
              project: projectId,
              level: errors && errors.length > 0 ? 'ERROR' : 'INFO',
              stage,
              message: `Stage ${stage} ${status} (${progress}%)`
            });
          } catch (e) {
            // Non-JSON output line
          }
        }
      }
    });

    child.stderr.on('data', (chunk) => {
      logger.warn(`Converter stderr [${projectId}]: ${chunk.toString()}`);
    });

    child.on('close', async (code) => {
      if (code === 0) {
        await importConverterResults(projectId);

        const qaReportPath = path.join(ENV.OUTPUT_DIR, projectId, 'reports', 'qa-report.json');
        let finalStatus = 'COMPLETED';
        if (fs.existsSync(qaReportPath)) {
          const qaData = JSON.parse(fs.readFileSync(qaReportPath, 'utf-8'));
          if (qaData.final_status === 'FAIL') {
            finalStatus = 'FAILED';
          } else if (qaData.final_status === 'WARNING') {
            finalStatus = 'WARNING';
          }
        }

        await Project.findByIdAndUpdate(projectId, {
          status: finalStatus,
          progress: 100,
          currentStage: 'completed',
          outputEpub: path.join(ENV.OUTPUT_DIR, projectId, 'final.epub'),
          completedAt: new Date()
        });

        await Job.findByIdAndUpdate(job._id, { status: 'COMPLETED' });
        logger.info(`Job ${job._id} completed successfully for project ${projectId}`);
      } else {
        await Project.findByIdAndUpdate(projectId, {
          status: 'FAILED',
          errorMessage: `Converter process exited with code ${code}`,
          completedAt: new Date()
        });
        await Job.findByIdAndUpdate(job._id, { status: 'FAILED' });
        logger.error(`Job ${job._id} failed with exit code ${code}`);
      }
      resolve();
    });
  });
}

async function importConverterResults(projectId: string) {
  const outputDir = path.join(ENV.OUTPUT_DIR, projectId);
  const reportsDir = path.join(outputDir, 'reports');

  // Import Pages & Summary
  const pagesDataPath = path.join(ENV.PROCESSING_DIR, projectId, 'pages_summary.json');
  if (fs.existsSync(pagesDataPath)) {
    const pages = JSON.parse(fs.readFileSync(pagesDataPath, 'utf-8'));
    await Page.deleteMany({ project: projectId });
    for (const p of pages) {
      await Page.create({ project: projectId, ...p });
    }
  }

  // Import QA Issues
  const issuesPath = path.join(reportsDir, 'unresolved-issues.json');
  if (fs.existsSync(issuesPath)) {
    const issues = JSON.parse(fs.readFileSync(issuesPath, 'utf-8'));
    await QAIssueModel.deleteMany({ project: projectId });
    for (const i of issues) {
      await QAIssueModel.create({ project: projectId, ...i });
    }
  }
}

export async function startWorker() {
  await connectDB();
  logger.info('Worker process initialized. Polling MongoDB queue...');

  while (true) {
    try {
      const job = await QueueService.claimJob();
      if (job) {
        await processJob(job);
      } else {
        await new Promise((r) => setTimeout(r, 2000));
      }
    } catch (err) {
      logger.error(`Worker error: ${(err as Error).message}`);
      await new Promise((r) => setTimeout(r, 5000));
    }
  }
}

if (require.main === module) {
  startWorker();
}
