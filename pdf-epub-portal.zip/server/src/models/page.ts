import { Schema, model, Document, Types } from 'mongoose';

export interface IPage extends Document {
  project: Types.ObjectId | string;
  pageNumber: number;
  textLayerAvailable: boolean;
  ocrRequired: boolean;
  ocrStatus?: string;
  columnCount: number;
  readingOrderStatus: string;
  imageCount: number;
  tableCount: number;
  figureCount: number;
  equationCount: number;
  headingCount: number;
  paragraphCount: number;
  analysisStatus: string;
}

const pageSchema = new Schema<IPage>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  pageNumber: { type: Number, required: true },
  textLayerAvailable: { type: Boolean, default: true },
  ocrRequired: { type: Boolean, default: false },
  ocrStatus: { type: String, default: 'skipped' },
  columnCount: { type: Number, default: 1 },
  readingOrderStatus: { type: String, default: 'normal' },
  imageCount: { type: Number, default: 0 },
  tableCount: { type: Number, default: 0 },
  figureCount: { type: Number, default: 0 },
  equationCount: { type: Number, default: 0 },
  headingCount: { type: Number, default: 0 },
  paragraphCount: { type: Number, default: 0 },
  analysisStatus: { type: String, default: 'COMPLETED' }
});

export const Page = model<IPage>('Page', pageSchema);
