import { Schema, model, Document, Types } from 'mongoose';

export interface IJob extends Document {
  project: Types.ObjectId | string;
  type: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  attempts: number;
  maxAttempts: number;
  lockedAt?: Date;
  cancelFlag: boolean;
  config: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

const jobSchema = new Schema<IJob>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  type: { type: String, default: 'conversion' },
  status: { type: String, enum: ['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED'], default: 'PENDING', index: true },
  attempts: { type: Number, default: 0 },
  maxAttempts: { type: Number, default: 3 },
  lockedAt: { type: Date },
  cancelFlag: { type: Boolean, default: false },
  config: { type: Schema.Types.Mixed, default: {} },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

export const Job = model<IJob>('Job', jobSchema);
