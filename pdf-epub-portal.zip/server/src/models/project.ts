import { Schema, model, Document, Types } from 'mongoose';

export interface IProject extends Document {
  owner: Types.ObjectId | string;
  projectName: string;
  sourcePdf: string;
  fileSize: number;
  pageCount: number;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'WARNING' | 'FAILED' | 'CANCELLED';
  progress: number;
  currentStage: string;
  outputEpub?: string;
  errorMessage?: string;
  config: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
  completedAt?: Date;
}

const projectSchema = new Schema<IProject>({
  owner: { type: Schema.Types.Mixed, required: true },
  projectName: { type: String, required: true, trim: true },
  sourcePdf: { type: String, required: true },
  fileSize: { type: Number, default: 0 },
  pageCount: { type: Number, default: 0 },
  status: { type: String, enum: ['PENDING', 'PROCESSING', 'COMPLETED', 'WARNING', 'FAILED', 'CANCELLED'], default: 'PENDING' },
  progress: { type: Number, default: 0 },
  currentStage: { type: String, default: 'created' },
  outputEpub: { type: String },
  errorMessage: { type: String },
  config: { type: Schema.Types.Mixed, default: {} },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  completedAt: { type: Date }
});

export const Project = model<IProject>('Project', projectSchema);
