import { Schema, model, Document, Types } from 'mongoose';

// Pipeline Steps
export interface IPipelineStep extends Omit<Document, 'errors'> {
  project: Types.ObjectId | string;
  name: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'WARNING' | 'FAILED';
  progress: number;
  startedAt?: Date;
  completedAt?: Date;
  duration?: number;
  itemsProcessed: number;
  errors: string[];
  warnings: string[];
}

const pipelineStepSchema = new Schema<IPipelineStep>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  name: { type: String, required: true },
  status: { type: String, enum: ['PENDING', 'PROCESSING', 'COMPLETED', 'WARNING', 'FAILED'], default: 'PENDING' },
  progress: { type: Number, default: 0 },
  startedAt: { type: Date },
  completedAt: { type: Date },
  duration: { type: Number, default: 0 },
  itemsProcessed: { type: Number, default: 0 },
  errors: [{ type: String }],
  warnings: [{ type: String }]
});

export const PipelineStep = model<IPipelineStep>('PipelineStep', pipelineStepSchema);

// OCR Corrections
export interface IOCRCorrection extends Document {
  project: Types.ObjectId | string;
  page: number;
  original: string;
  corrected: string;
  confidence: number;
  reason: string;
  status: string;
}

const ocrCorrectionSchema = new Schema<IOCRCorrection>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  page: { type: Number, required: true },
  original: { type: String, required: true },
  corrected: { type: String, required: true },
  confidence: { type: Number, default: 0.85 },
  reason: { type: String },
  status: { type: String, default: 'corrected' }
});

export const OCRCorrection = model<IOCRCorrection>('OCRCorrection', ocrCorrectionSchema);

// Figures
export interface IFigure extends Document {
  project: Types.ObjectId | string;
  figureId: string;
  page: number;
  caption: string;
  altText: string;
  status: string;
}

const figureSchema = new Schema<IFigure>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  figureId: { type: String, required: true },
  page: { type: Number, required: true },
  caption: { type: String },
  altText: { type: String },
  status: { type: String, default: 'extracted' }
});

export const FigureModel = model<IFigure>('Figure', figureSchema);

// Tables
export interface ITable extends Document {
  project: Types.ObjectId | string;
  tableId: string;
  page: number;
  rows: number;
  cols: number;
  reconstruction: string;
  caption: string;
  status: string;
}

const tableSchema = new Schema<ITable>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  tableId: { type: String, required: true },
  page: { type: Number, required: true },
  rows: { type: Number, default: 0 },
  cols: { type: Number, default: 0 },
  reconstruction: { type: String, default: 'table' },
  caption: { type: String },
  status: { type: String, default: 'reconstructed' }
});

export const TableModel = model<ITable>('Table', tableSchema);

// Equations
export interface IEquation extends Document {
  project: Types.ObjectId | string;
  equationId: string;
  page: number;
  eqType: string;
  mathml: string;
  status: string;
}

const equationSchema = new Schema<IEquation>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  equationId: { type: String, required: true },
  page: { type: Number, required: true },
  eqType: { type: String, default: 'inline' },
  mathml: { type: String },
  status: { type: String, default: 'converted' }
});

export const EquationModel = model<IEquation>('Equation', equationSchema);

// Cross References
export interface ICrossReference extends Document {
  project: Types.ObjectId | string;
  reference: string;
  target: string;
  sourcePage: number;
  status: string;
}

const crossReferenceSchema = new Schema<ICrossReference>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  reference: { type: String, required: true },
  target: { type: String, required: true },
  sourcePage: { type: Number, required: true },
  status: { type: String, enum: ['resolved', 'broken'], default: 'resolved' }
});

export const CrossReference = model<ICrossReference>('CrossReference', crossReferenceSchema);

// QA Issues
export interface IQAIssue extends Document {
  project: Types.ObjectId | string;
  page: number;
  type: string;
  severity: string;
  expected: string;
  actual: string;
  status: string;
}

const qaIssueSchema = new Schema<IQAIssue>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  page: { type: Number, default: 1 },
  type: { type: String, required: true },
  severity: { type: String, enum: ['CRITICAL', 'WARNING', 'INFO'], default: 'WARNING' },
  expected: { type: String },
  actual: { type: String },
  status: { type: String, default: 'UNRESOLVED' }
});

export const QAIssueModel = model<IQAIssue>('QAIssue', qaIssueSchema);

// Pipeline Logs
export interface IPipelineLog extends Document {
  project: Types.ObjectId | string;
  level: string;
  timestamp: Date;
  stage: string;
  message: string;
}

const pipelineLogSchema = new Schema<IPipelineLog>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  level: { type: String, default: 'INFO' },
  timestamp: { type: Date, default: Date.now },
  stage: { type: String, default: 'general' },
  message: { type: String, required: true }
});

export const PipelineLog = model<IPipelineLog>('PipelineLog', pipelineLogSchema);

// Reports
export interface IReport extends Document {
  project: Types.ObjectId | string;
  name: string;
  reportType: string;
  format: 'json' | 'html';
  filePath: string;
  createdAt: Date;
}

const reportSchema = new Schema<IReport>({
  project: { type: Schema.Types.Mixed, required: true, index: true },
  name: { type: String, required: true },
  reportType: { type: String, required: true },
  format: { type: String, enum: ['json', 'html'], default: 'json' },
  filePath: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

export const ReportModel = model<IReport>('Report', reportSchema);
