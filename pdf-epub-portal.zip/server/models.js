const m = require('mongoose');
exports.User = m.model('User', new m.Schema({ email: { type: String, unique: true }, hash: String, role: { type: String, default: 'user' } }));
exports.Project = m.model('Project', new m.Schema({
  owner: m.Schema.Types.ObjectId, name: String, pdf: String, epub: String,
  status: { type: String, default: 'PENDING' }, progress: { type: Number, default: 0 },
  report: Object, error: String, log: [String]
}, { timestamps: true }));
