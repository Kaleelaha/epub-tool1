import request from 'supertest';
import mongoose from 'mongoose';
import path from 'path';
import fs from 'fs';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { serverApp } from '../src/index';
import { User } from '../src/models/user';
import { Project } from '../src/models/project';

let mongoServer: MongoMemoryServer;

describe('Server API Endpoints & Security Integration Tests', () => {
  let userToken: string;
  let adminToken: string;
  let userId: string;
  let adminId: string;
  let projectId: string;

  beforeAll(async () => {
    mongoServer = await MongoMemoryServer.create();
    const uri = mongoServer.getUri();
    await mongoose.connect(uri);
  });

  afterAll(async () => {
    await User.deleteMany({});
    await Project.deleteMany({});
    await mongoose.disconnect();
    if (mongoServer) {
      await mongoServer.stop();
    }
  });

  it('1. Auth: Registers Admin (First User) and Standard User', async () => {
    const resAdmin = await request(serverApp)
      .post('/api/auth/register')
      .send({ email: 'admin@gov.portal', password: 'password123' });

    expect(resAdmin.status).toBe(201);
    expect(resAdmin.body.user.role).toBe('admin');
    adminToken = resAdmin.body.token;
    adminId = resAdmin.body.user.id;

    const resUser = await request(serverApp)
      .post('/api/auth/register')
      .send({ email: 'user@gov.portal', password: 'password123' });

    expect(resUser.status).toBe(201);
    expect(resUser.body.user.role).toBe('user');
    userToken = resUser.body.token;
    userId = resUser.body.user.id;
  });

  it('2. Auth: User Login returns JWT Token', async () => {
    const res = await request(serverApp)
      .post('/api/auth/login')
      .send({ email: 'user@gov.portal', password: 'password123' });

    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
  });

  it('3. Upload Rejection: Rejects non-PDF file upload', async () => {
    const txtPath = path.join(__dirname, 'test.txt');
    fs.writeFileSync(txtPath, 'Hello World text file content');

    const projRes = await request(serverApp)
      .post('/api/projects')
      .set('Authorization', `Bearer ${userToken}`)
      .send({ projectName: 'Security Test Project' });

    projectId = projRes.body._id;

    const uploadRes = await request(serverApp)
      .post(`/api/projects/${projectId}/upload`)
      .set('Authorization', `Bearer ${userToken}`)
      .attach('file', txtPath);

    expect(uploadRes.status).toBe(400);
    expect(uploadRes.body.error).toContain('Only PDF files are allowed');

    if (fs.existsSync(txtPath)) fs.unlinkSync(txtPath);
  });

  it('4. Upload Rejection: Rejects fake .pdf file (invalid magic bytes)', async () => {
    const fakePdfPath = path.join(__dirname, 'fake.pdf');
    fs.writeFileSync(fakePdfPath, 'NOT A REAL PDF HEADER CONTENT');

    const uploadRes = await request(serverApp)
      .post(`/api/projects/${projectId}/upload`)
      .set('Authorization', `Bearer ${userToken}`)
      .attach('file', fakePdfPath);

    expect(uploadRes.status).toBe(400);
    expect(uploadRes.body.error).toContain('Magic bytes %PDF- missing');

    if (fs.existsSync(fakePdfPath)) fs.unlinkSync(fakePdfPath);
  });

  it('5. Access Control: Standard User cannot access another user project', async () => {
    const adminProjRes = await request(serverApp)
      .post('/api/projects')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ projectName: 'Admin Private Project' });

    const adminProjId = adminProjRes.body._id;

    const accessRes = await request(serverApp)
      .get(`/api/projects/${adminProjId}`)
      .set('Authorization', `Bearer ${userToken}`);

    expect(accessRes.status).toBe(403);
  });

  it('6. Path Traversal Protection: Blocks relative path traversal in XHTML / downloads', async () => {
    const pathRes = await request(serverApp)
      .get(`/api/projects/${projectId}/xhtml/..%2F..%2F..%2Fetc%2Fpasswd`)
      .set('Authorization', `Bearer ${userToken}`);

    expect(pathRes.status).toBe(404);
  });
});
