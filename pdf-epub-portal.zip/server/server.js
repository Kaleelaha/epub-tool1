require('dotenv').config();
const express = require('express'), cors = require('cors'), mongoose = require('mongoose'), bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken'), multer = require('multer'), rate = require('express-rate-limit');
const fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const { User, Project } = require('./models');
const app = express(), procs = {};
const ROOT = path.join(__dirname, 'storage'), CORE = path.join(__dirname, '..', 'backend');
const MAX = (+process.env.MAX_UPLOAD_MB || 50) * 1024 * 1024;
app.use(cors({ origin: process.env.CLIENT_ORIGIN })); app.use(express.json());
app.use('/api/auth', rate({ windowMs: 15 * 60 * 1000, max: 50 }));

const sign = u => jwt.sign({ id: u._id, role: u.role }, process.env.JWT_SECRET, { expiresIn: '8h' });
const auth = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), process.env.JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Unauthorized' }); }
};
const pub = p => ({ id: p._id, name: p.name, status: p.status, progress: p.progress, report: p.report,
  error: p.error, hasPdf: !!p.pdf, hasEpub: !!p.epub, log: p.log, createdAt: p.createdAt, updatedAt: p.updatedAt });
const mine = async (req, res) => {
  const p = await Project.findById(req.params.id).catch(() => null);
  if (!p || (req.user.role !== 'admin' && String(p.owner) !== req.user.id)) { res.status(404).json({ error: 'Not found' }); return null; }
  return p;
};

app.post('/api/auth/register', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password || password.length < 8) return res.status(400).json({ error: 'Email and password (8+ chars) required' });
  try { const u = await User.create({ email, hash: await bcrypt.hash(password, 10), role: (await User.countDocuments()) ? 'user' : 'admin' });
    res.json({ token: sign(u), role: u.role }); } catch { res.status(409).json({ error: 'Email already registered' }); }
});
app.post('/api/auth/login', async (req, res) => {
  const u = await User.findOne({ email: (req.body || {}).email });
  if (!u || !(await bcrypt.compare(req.body.password || '', u.hash))) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ token: sign(u), role: u.role });
});
app.get('/api/auth/me', auth, (req, res) => res.json(req.user));

app.get('/api/projects', auth, async (req, res) =>
  res.json((await Project.find(req.user.role === 'admin' ? {} : { owner: req.user.id }).sort('-createdAt')).map(pub)));
app.post('/api/projects', auth, async (req, res) => {
  const name = String((req.body || {}).name || '').trim().slice(0, 120);
  if (!name) return res.status(400).json({ error: 'Project name required' });
  res.json(pub(await Project.create({ owner: req.user.id, name })));
});
app.get('/api/projects/:id', auth, async (req, res) => { const p = await mine(req, res); if (p) res.json(pub(p)); });
app.delete('/api/projects/:id', auth, async (req, res) => {
  const p = await mine(req, res); if (!p) return;
  [p.pdf, p.epub].filter(Boolean).forEach(f => fs.rmSync(f, { force: true })); await p.deleteOne(); res.json({ ok: true });
});

const upload = multer({ dest: path.join(ROOT, 'uploads'), limits: { fileSize: MAX },
  fileFilter: (_, f, cb) => cb(null, /\.pdf$/i.test(f.originalname) && f.mimetype === 'application/pdf') });
app.post('/api/projects/:id/upload', auth, upload.single('file'), async (req, res) => {
  const p = await mine(req, res); if (!p) return;
  if (!req.file) return res.status(400).json({ error: 'A PDF file is required' });
  const head = Buffer.alloc(5); const fd = fs.openSync(req.file.path, 'r'); fs.readSync(fd, head, 0, 5, 0); fs.closeSync(fd);
  if (head.toString() !== '%PDF-') { fs.rmSync(req.file.path); return res.status(400).json({ error: 'Not a valid PDF' }); }
  p.pdf = req.file.path; await p.save(); res.json(pub(p));
});

app.post('/api/projects/:id/start', auth, async (req, res) => {
  const p = await mine(req, res); if (!p) return;
  if (!p.pdf) return res.status(400).json({ error: 'Upload a PDF first' });
  if (procs[p.id]) return res.status(409).json({ error: 'Already running' });
  const out = path.join(ROOT, 'output', String(p._id));
  Object.assign(p, { status: 'PROCESSING', progress: 10, error: null, report: null, log: [] }); await p.save();
  const c = spawn(process.env.PYTHON || 'python3', ['-m', 'app.pipeline.run', p.pdf, out],
    { cwd: CORE, env: { ...process.env, EPUBCHECK_PATH: process.env.EPUBCHECK_PATH || '' } });
  procs[p.id] = c; let so = '', se = '';
  c.stdout.on('data', d => so += d); c.stderr.on('data', d => se += d);
  c.on('close', async code => {
    delete procs[p.id]; const q = await Project.findById(p._id); if (!q || q.status === 'CANCELLED') return;
    q.log = (so + se).split('\n').slice(-40);
    try {
      if (code !== 0) throw new Error('exit');
      q.report = JSON.parse(fs.readFileSync(path.join(out, 'qa-report.json'), 'utf8'));
      q.epub = path.join(out, 'final.epub'); q.progress = 100;
      q.status = q.report.final_status === 'PASS' ? 'COMPLETED' : 'WARNING';   // never fake success
    } catch { q.status = 'FAILED'; q.error = 'Conversion failed. See log.'; }
    await q.save();
  });
  res.json(pub(p));
});
app.post('/api/projects/:id/cancel', auth, async (req, res) => {
  const p = await mine(req, res); if (!p) return;
  if (procs[p.id]) { p.status = 'CANCELLED'; await p.save(); procs[p.id].kill(); delete procs[p.id]; }
  res.json(pub(p));
});
app.get('/api/projects/:id/epub/download', auth, async (req, res) => {
  const p = await mine(req, res); if (!p) return;
  if (!p.epub || !fs.existsSync(p.epub)) return res.status(404).json({ error: 'No EPUB produced' });
  res.download(p.epub, 'final.epub');
});
app.get('/api/projects/:id/report', auth, async (req, res) => { const p = await mine(req, res); if (p) res.json(p.report || null); });

mongoose.connect(process.env.MONGO_URL).then(() => app.listen(process.env.PORT || 4000, () => console.log('API up')));
