# PDF → EPUB 3 Conversion Portal (MERN + Python Worker)

An end-to-end, government-styled online service portal designed for automated, accessible conversion of digital and scanned PDF documents into valid EPUB 3 packages.

---

## 1. Overview & Architecture

This system uses a decoupled MERN architecture with an isolated Python worker child process:
- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, TanStack Query, React Hook Form + Zod, Lucide React icons. Styled according to standard Government Online Service Portal rules (white background, simple blue accents, compact data tables, zero glassmorphism or dark mode).
- **Backend API:** Node 20 + Express + TypeScript, Mongoose (MongoDB), JWT authentication, bcryptjs, multer PDF magic-bytes validation, rate limiting, and Pino logging.
- **Worker Process:** Node background worker process claiming jobs atomically from MongoDB (`jobs` collection) via `findOneAndUpdate` with retry and cancellation support.
- **Converter Engine:** Modular Python package (`converter/`) invoked by the worker (`py -m converter.cli --project <id> --config <json>`), streaming stage progress as JSON lines.
- **EPUB Validation:** W3C EPUBCheck integration via Java CLI (`java -jar $EPUBCHECK_PATH`).

```
                              ┌────────────────────────┐
                              │  React 18 Frontend UI  │
                              └───────────┬────────────┘
                                          │ REST API
                              ┌───────────▼────────────┐
                              │ Node 20 Express Server │
                              └───────────┬────────────┘
                                          │ MongoDB Queue
                              ┌───────────▼────────────┐
                              │   Node Worker Process  │
                              └───────────┬────────────┘
                                          │ Child Process (stdout JSON)
                              ┌───────────▼────────────┐
                              │ Python Converter CLI   │
                              └────────────────────────┘
```

## 2. Directory Layout

```
pdf-epub-portal-mern/
├─ frontend/                # React 18 + TS + Vite UI
│  ├─ src/                  # Components, Pages, Layouts, Services, Types
│  └─ tests/                # Vitest test suite
├─ server/                  # Node Express + TS Backend API & Worker
│  ├─ src/                  # Config, Controllers, Models, Routes, Worker
│  └─ tests/                # Jest + Supertest integration tests
├─ converter/               # Modular Python 3 conversion pipeline
│  ├─ converter/            # 23 stages (analyzer, ocr, structure, xhtml, opf, validator, etc.)
│  └─ tests/                # Pytest unit tests
├─ samples/                 # PDF test sample generator and sample PDFs
├─ storage/                 # Uploads, processing, output, reports, logs
├─ docker-compose.yml       # Docker orchestrator configuration
├─ .env.example             # Environment variable template
├─ DECISIONS.md             # Design and engineering decisions
└─ BUILD_LOG.md             # Verification log and test evidence
```
---

## 3. Prerequisites & Installation

### Prerequisites:
- **Node.js:** v20+
- **Python:** 3.11+ (`py` on Windows / `python3` on Linux)
- **Java Runtime:** JDK/JRE 17+ (for EPUBCheck execution)
- **Tesseract OCR:** CLI installed and added to PATH (optional; for scanned PDF pages)
- **EPUBCheck:** Download jar from [W3C EPUBCheck Releases](https://github.com/w3c/epubcheck/releases)

### EPUBCheck Setup Steps:
1. Download `epubcheck-5.1.0.zip` from W3C GitHub releases.
2. Extract `epubcheck.jar` to `tools/epubcheck/epubcheck.jar`.
3. Set `EPUBCHECK_PATH=tools/epubcheck/epubcheck.jar` in `.env`.

---

## 4. Running Locally (Three Commands)

### 1. Start MongoDB & API Server:
```bash
cd server
npm install
npm start
```

### 2. Start Background Worker Process:
```bash
cd server
npm run worker
```

### 3. Start Frontend Client:
```bash
cd frontend
npm install
npm run dev
```

API Documentation will be accessible at: `http://localhost:5000/docs`

---

## 5. Running Tests

### Converter Python Tests:
```bash
$env:PYTHONPATH="converter"
py -m pytest converter/tests/test_converter.py
```

### Server API Integration Tests:
```bash
cd server
npm test
```

### Frontend Vitest UI Tests:
```bash
cd frontend
npm test
```

---

## 6. Docker Deployment

```bash
docker-compose up --build -d
```

---

## 7. Known Limitations

1. **Complex Vector Drawing Reconstruction:** Complex freehand drawings are preserved by rendering vector regions as high-DPI images with descriptive alt tags rather than raw SVG paths.
2. **EPUBCheck Runtime Fallback:** If Java or the EPUBCheck jar binary is absent in the host environment, the system displays `"EPUBCheck unavailable"`, sets the validation quality gate to `FAILED`, and marks the overall status as `FAIL` per Rule 1.
