import React from 'react';

interface StatusBadgeProps {
  status: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const getStyle = (s: string) => {
    switch (s?.toUpperCase()) {
      case 'COMPLETED':
      case 'PASS':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'WARNING':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'FAILED':
      case 'FAIL':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'PROCESSING':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'PENDING':
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <span className={`px-2 py-0.5 text-xs font-semibold border rounded ${getStyle(status)}`}>
      {status || 'UNKNOWN'}
    </span>
  );
};
