import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FileText, LogOut, User as UserIcon } from 'lucide-react';
import { User } from '../types';

interface HeaderProps {
  user: User | null;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
  const navigate = useNavigate();
  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-30 h-10 bg-blue-700 text-white flex items-center justify-center font-bold text-xl rounded">
            E-pub
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 leading-tight">
              PDF → EPUB 3 Conversion System
            </h1>
            <p className="text-xs text-gray-600">
              Digital Publishing & Document Processing Portal
            </p>
          </div>
        </div>

        <nav className="flex items-center space-x-6 text-sm font-medium text-gray-700">
          <Link to="/" className="hover:text-blue-700">Home</Link>
          <Link to="/new-conversion" className="hover:text-blue-700">New Conversion</Link>
          <Link to="/projects" className="hover:text-blue-700">Projects</Link>
          <span className="text-gray-400 cursor-not-allowed">Help</span>
          <span className="text-gray-400 cursor-not-allowed">Contact</span>
          {user ? (
            <div className="flex items-center space-x-3 border-l pl-4 border-gray-200">
              <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-700 flex items-center gap-1">
                <UserIcon size={14} />
                {user.email} ({user.role})
              </span>
              <button
                onClick={onLogout}
                className="text-xs text-red-600 hover:underline flex items-center gap-1"
              >
                <LogOut size={14} /> Logout
              </button>
            </div>
          ) : (
            <Link to="/login" className="gov-btn-primary py-1 px-3 text-xs">
              Login
            </Link>
          )}
        </nav>
      </div>
      <div className="h-1 bg-blue-700 w-full"></div>
    </header>
  );
};
