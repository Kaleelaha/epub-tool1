import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 mt-auto py-4 text-xs text-gray-600">
      <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
        <div>
          Official Digital Publishing Portal &bull; PDF to EPUB 3 Conversion & Standard Compliance
        </div>
        <div>
          &copy; 2026 Department of Digital Standards. All rights reserved.
        </div>
      </div>
    </footer>
  );
};
