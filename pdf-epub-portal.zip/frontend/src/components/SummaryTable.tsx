import React from 'react';
import { StatusBadge } from './StatusBadge';

interface SummaryData {
  inputPdf: string;
  outputEpub: string;
  pages: number;
  xhtmlFiles: number;
  figures: number;
  tables: number;
  equations: number;
  ocrPages: number;
  ocrCorrections: number;
  brokenLinks: number;
  duplicateIds: number;
  missingResources: number;
  discrepancies: number;
  epubcheckErrors: number;
  epubcheckWarnings: number;
  unresolvedIssues: number;
  finalStatus: string;
}

export const SummaryTable: React.FC<{ summary: SummaryData }> = ({ summary }) => {
  return (
    <div className="gov-border p-4 bg-white mb-6">
      <h3 className="text-md font-bold text-gray-900 border-b pb-2 mb-3">
        Conversion Executive Summary
      </h3>
      <table className="gov-table">
        <tbody>
          <tr>
            <td className="font-medium w-1/3">Input Source PDF:</td>
            <td>{summary.inputPdf}</td>
          </tr>
          <tr>
            <td className="font-medium">Output Package:</td>
            <td>{summary.outputEpub}</td>
          </tr>
          <tr>
            <td className="font-medium">Total Pages Processed:</td>
            <td>{summary.pages}</td>
          </tr>
          <tr>
            <td className="font-medium">XHTML Chapter Files:</td>
            <td>{summary.xhtmlFiles}</td>
          </tr>
          <tr>
            <td className="font-medium">Figures / Images Extracted:</td>
            <td>{summary.figures}</td>
          </tr>
          <tr>
            <td className="font-medium">Tables Reconstructed:</td>
            <td>{summary.tables}</td>
          </tr>
          <tr>
            <td className="font-medium">Equations / MathML:</td>
            <td>{summary.equations}</td>
          </tr>
          <tr>
            <td className="font-medium">OCR Pages Processed:</td>
            <td>{summary.ocrPages}</td>
          </tr>
          <tr>
            <td className="font-medium">OCR Corrections Audited:</td>
            <td>{summary.ocrCorrections}</td>
          </tr>
          <tr>
            <td className="font-medium">Broken Links:</td>
            <td className={summary.brokenLinks > 0 ? "text-red-600 font-bold" : "text-green-700"}>{summary.brokenLinks}</td>
          </tr>
          <tr>
            <td className="font-medium">Duplicate IDs:</td>
            <td className={summary.duplicateIds > 0 ? "text-red-600 font-bold" : "text-green-700"}>{summary.duplicateIds}</td>
          </tr>
          <tr>
            <td className="font-medium">Missing Manifest Resources:</td>
            <td>{summary.missingResources}</td>
          </tr>
          <tr>
            <td className="font-medium">PDF/EPUB Text Discrepancies:</td>
            <td>{summary.discrepancies}</td>
          </tr>
          <tr>
            <td className="font-medium">EPUBCheck Errors:</td>
            <td className={summary.epubcheckErrors > 0 ? "text-red-600 font-bold" : "text-green-700"}>{summary.epubcheckErrors}</td>
          </tr>
          <tr>
            <td className="font-medium">EPUBCheck Warnings:</td>
            <td>{summary.epubcheckWarnings}</td>
          </tr>
          <tr>
            <td className="font-medium">Unresolved QA Issues:</td>
            <td>{summary.unresolvedIssues}</td>
          </tr>
          <tr className="bg-gray-50">
            <td className="font-bold text-gray-900">FINAL STATUS:</td>
            <td><StatusBadge status={summary.finalStatus} /></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};
