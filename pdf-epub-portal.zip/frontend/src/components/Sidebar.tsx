import React from 'react';
import { NavLink, useParams } from 'react-router-dom';
import {
  LayoutDashboard,
  Folder,
  FileSearch,
  ScanText,
  GitBranch,
  Image,
  Binary,
  Code,
  Link2,
  Package,
  CheckCircle,
  FileDiff,
  ShieldCheck,
  Terminal,
  Settings
} from 'lucide-react';

interface SidebarProps {
  projectId?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ projectId: propId }) => {
  const params = useParams<{ id?: string }>();
  const id = propId || params.id;

  const baseItems = [
    { label: 'Projects', path: '/projects', icon: Folder }
  ];

  const projectItems = id ? [
    { label: 'Project Overview', path: `/projects/${id}`, icon: LayoutDashboard, end: true },
    { label: 'PDF Analysis', path: `/projects/${id}/analysis`, icon: FileSearch },
    { label: 'OCR Processing', path: `/projects/${id}/ocr`, icon: ScanText },
    { label: 'Document Structure', path: `/projects/${id}/structure`, icon: GitBranch },
    { label: 'Figures & Tables', path: `/projects/${id}/figures-tables`, icon: Image },
    { label: 'Equations', path: `/projects/${id}/equations`, icon: Binary },
    { label: 'XHTML Viewer', path: `/projects/${id}/xhtml`, icon: Code },
    { label: 'Cross References', path: `/projects/${id}/references`, icon: Link2 },
    { label: 'EPUB Package', path: `/projects/${id}/epub-package`, icon: Package },
    { label: 'Validation', path: `/projects/${id}/validation`, icon: CheckCircle },
    { label: 'PDF vs EPUB', path: `/projects/${id}/comparison`, icon: FileDiff },
    { label: 'QA Reports', path: `/projects/${id}/qa`, icon: ShieldCheck },
    { label: 'Pipeline Logs', path: `/projects/${id}/logs`, icon: Terminal },
    { label: 'Settings', path: `/projects/${id}/settings`, icon: Settings }
  ] : [];

  return (
    <aside className="w-64 bg-gray-50 border-r border-gray-200 min-h-screen p-4 flex flex-col gap-6">
      <div>
        <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
          Navigation
        </h2>
        <ul className="space-y-1">
          {baseItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3 py-2 text-sm rounded ${
                    isActive ? 'bg-blue-100 text-blue-800 font-medium' : 'text-gray-700 hover:bg-gray-100'
                  }`
                }
              >
                <item.icon size={16} />
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </div>

      {id && (
        <div>
          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
            Project Views
          </h2>
          <ul className="space-y-1">
            {projectItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  end={item.end}
                  className={({ isActive }) =>
                    `flex items-center gap-2 px-3 py-2 text-sm rounded ${
                      isActive ? 'bg-blue-100 text-blue-800 font-medium' : 'text-gray-700 hover:bg-gray-100'
                    }`
                  }
                >
                  <item.icon size={16} />
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </div>
      )}
    </aside>
  );
};
