import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface ErrorStateProps {
  message?: string;
  onRetry?: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({ message = 'Failed to load data from server.', onRetry }) => {
  return (
    <div className="p-6 bg-red-50 border border-red-200 text-red-800 my-4 rounded flex flex-col items-start gap-3">
      <div className="flex items-center gap-2 font-semibold">
        <AlertTriangle size={20} className="text-red-600" />
        <span>Error Encountered</span>
      </div>
      <p className="text-sm">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="gov-btn-secondary text-xs flex items-center gap-1 border-red-300 text-red-800 hover:bg-red-100"
        >
          <RefreshCw size={14} /> Retry Request
        </button>
      )}
    </div>
  );
};
