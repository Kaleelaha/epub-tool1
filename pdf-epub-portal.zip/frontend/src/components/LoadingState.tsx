import React from 'react';
import { Loader2 } from 'lucide-react';

export const LoadingState: React.FC<{ message?: string }> = ({ message = 'Loading document data...' }) => {
  return (
    <div className="p-8 text-center bg-gray-50 gov-border flex flex-col items-center justify-center gap-3 my-4">
      <Loader2 className="animate-spin text-blue-700" size={32} />
      <span className="text-sm font-medium text-gray-700">{message}</span>
    </div>
  );
};
