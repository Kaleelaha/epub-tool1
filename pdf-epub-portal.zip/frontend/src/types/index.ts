export interface User {
  id: string;
  email: string;
  role: 'admin' | 'user';
}

export interface Project {
  _id: string;
  projectName: string;
  sourcePdf: string;
  fileSize: number;
  pageCount: number;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'WARNING' | 'FAILED' | 'CANCELLED';
  progress: number;
  currentStage: string;
  outputEpub?: string;
  errorMessage?: string;
  config: Record<string, any>;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

export interface PipelineStep {
  _id?: string;
  name: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'WARNING' | 'FAILED';
  progress: number;
  itemsProcessed: number;
  errors: string[];
  warnings: string[];
}

export interface PageData {
  _id?: string;
  pageNumber: number;
  textLayerAvailable: boolean;
  ocrRequired: boolean;
  ocrStatus?: string;
  columnCount: number;
  imageCount: number;
  tableCount: number;
  figureCount: number;
  equationCount: number;
  quality_score?: number;
}

export interface Figure {
  figureId: string;
  page: number;
  caption: string;
  altText: string;
  status: string;
}

export interface TableItem {
  tableId: string;
  page: number;
  rows: number;
  cols: number;
  reconstruction: string;
  caption: string;
  status: string;
}

export interface EquationItem {
  equationId: string;
  page: number;
  eqType: string;
  mathml: string;
  status: string;
}

export interface QAGate {
  name: string;
  status: 'Completed' | 'Warning' | 'Failed' | 'Pending';
  critical: boolean;
}

export interface QAReportData {
  final_status: 'PASS' | 'FAIL' | 'WARNING' | 'PENDING';
  gates: QAGate[];
  duplicate_ids: number;
  broken_links: number;
  epubcheck_executed: boolean;
  epubcheck_errors: number;
  unresolved_issues: number;
}
