import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MainLayout } from './layouts/MainLayout';
import { Home } from './pages/Home';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { NewConversion } from './pages/NewConversion';
import { Projects } from './pages/Projects';
import { ProjectDetail } from './pages/ProjectDetail';
import { PdfAnalysis } from './pages/PdfAnalysis';
import { OcrView } from './pages/OcrView';
import { DocumentStructure } from './pages/DocumentStructure';
import { FiguresTables } from './pages/FiguresTables';
import { EquationsView } from './pages/EquationsView';
import { XhtmlViewer } from './pages/XhtmlViewer';
import { CrossReferences } from './pages/CrossReferences';
import { EpubPackage } from './pages/EpubPackage';
import { ValidationView } from './pages/ValidationView';
import { PdfVsEpub } from './pages/PdfVsEpub';
import { QaReports } from './pages/QaReports';
import { LogsView } from './pages/LogsView';
import { Settings } from './pages/Settings';
import { User } from './types';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: (failureCount, error: any) => {
        if (error?.response?.status === 401 || error?.response?.status === 403) {
          return false;
        }
        return failureCount < 2;
      }
    }
  }
});

interface ProtectedRouteProps {
  user: User | null;
  children: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ user, children }) => {
  if (!user && !localStorage.getItem('jwt_token')) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

export const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('user_info');
    return saved ? JSON.parse(saved) : null;
  });

  const handleLoginSuccess = (token: string, userData: User) => {
    localStorage.setItem('jwt_token', token);
    localStorage.setItem('user_info', JSON.stringify(userData));
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('jwt_token');
    localStorage.removeItem('user_info');
    setUser(null);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <Routes>
          <Route path="/login" element={<Login onLoginSuccess={handleLoginSuccess} />} />
          <Route path="/register" element={<Register onLoginSuccess={handleLoginSuccess} />} />

          <Route element={<MainLayout user={user} onLogout={handleLogout} />}>
            <Route path="/" element={<Home />} />
            
            {/* Protected Project Routes */}
            <Route path="/new-conversion" element={
              <ProtectedRoute user={user}><NewConversion /></ProtectedRoute>
            } />
            <Route path="/projects" element={
              <ProtectedRoute user={user}><Projects /></ProtectedRoute>
            } />
            <Route path="/projects/:id" element={
              <ProtectedRoute user={user}><ProjectDetail /></ProtectedRoute>
            } />
            <Route path="/projects/:id/analysis" element={
              <ProtectedRoute user={user}><PdfAnalysis /></ProtectedRoute>
            } />
            <Route path="/projects/:id/ocr" element={
              <ProtectedRoute user={user}><OcrView /></ProtectedRoute>
            } />
            <Route path="/projects/:id/structure" element={
              <ProtectedRoute user={user}><DocumentStructure /></ProtectedRoute>
            } />
            <Route path="/projects/:id/figures-tables" element={
              <ProtectedRoute user={user}><FiguresTables /></ProtectedRoute>
            } />
            <Route path="/projects/:id/equations" element={
              <ProtectedRoute user={user}><EquationsView /></ProtectedRoute>
            } />
            <Route path="/projects/:id/xhtml" element={
              <ProtectedRoute user={user}><XhtmlViewer /></ProtectedRoute>
            } />
            <Route path="/projects/:id/references" element={
              <ProtectedRoute user={user}><CrossReferences /></ProtectedRoute>
            } />
            <Route path="/projects/:id/epub-package" element={
              <ProtectedRoute user={user}><EpubPackage /></ProtectedRoute>
            } />
            <Route path="/projects/:id/validation" element={
              <ProtectedRoute user={user}><ValidationView /></ProtectedRoute>
            } />
            <Route path="/projects/:id/comparison" element={
              <ProtectedRoute user={user}><PdfVsEpub /></ProtectedRoute>
            } />
            <Route path="/projects/:id/qa" element={
              <ProtectedRoute user={user}><QaReports /></ProtectedRoute>
            } />
            <Route path="/projects/:id/logs" element={
              <ProtectedRoute user={user}><LogsView /></ProtectedRoute>
            } />
            <Route path="/projects/:id/settings" element={
              <ProtectedRoute user={user}><Settings /></ProtectedRoute>
            } />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
};

export default App;
