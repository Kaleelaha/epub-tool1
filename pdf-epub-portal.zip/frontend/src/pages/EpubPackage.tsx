import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { epubService } from '../services/epubService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { Package, Download, File, Folder } from 'lucide-react';

export const EpubPackage: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data: files, isLoading, isError, refetch } = useQuery({
    queryKey: ['epubFiles', id],
    queryFn: () => epubService.getEpubFiles(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Inspecting EPUB 3 zip package..." />;
  if (isError) return <ErrorState message="Failed to inspect EPUB package." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center border-b pb-2">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <Package size={20} className="text-blue-700" /> EPUB 3 Package Structure & Resource Inspection
        </h2>

        <button
          onClick={() => epubService.downloadEpub(id!)}
          className="gov-btn-primary text-xs flex items-center gap-1"
        >
          <Download size={14} /> Download final.epub
        </button>
      </div>

      <div className="gov-border p-4 bg-white">
        <h3 className="text-sm font-bold text-gray-800 border-b pb-2 mb-3">
          ZIP Package Directory Manifest (mimetype uncompressed first)
        </h3>
        <ul className="space-y-2 text-xs font-mono">
          <li className="flex items-center gap-2 text-green-700 font-bold bg-green-50 p-1 border border-green-200">
            <File size={14} /> mimetype (stored uncompressed)
          </li>
          <li className="flex items-center gap-2 text-blue-800 font-bold ml-3">
            <Folder size={14} /> META-INF/
          </li>
          <li className="flex items-center gap-2 text-gray-700 ml-6">
            <File size={14} /> container.xml
          </li>
          <li className="flex items-center gap-2 text-blue-800 font-bold ml-3 mt-2">
            <Folder size={14} /> OEBPS/
          </li>
          <li className="flex items-center gap-2 text-gray-700 ml-6">
            <File size={14} /> content.opf
          </li>
          <li className="flex items-center gap-2 text-gray-700 ml-6">
            <File size={14} /> nav.xhtml
          </li>
          {files && Array.isArray(files) && files.map((f: string) => (
            <li key={f} className="flex items-center gap-2 text-gray-600 ml-6">
              <File size={14} /> {f}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
