import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { epubService } from '../services/epubService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { Link2 } from 'lucide-react';

export const CrossReferences: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data: links, isLoading, isError, refetch } = useQuery({
    queryKey: ['links', id],
    queryFn: () => epubService.getLinks(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Resolving cross-references..." />;
  if (isError) return <ErrorState message="Failed to load cross references." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
        <Link2 size={20} className="text-blue-700" /> Cross-Reference Links Resolution Audit
      </h2>

      <table className="gov-table">
        <thead>
          <tr>
            <th>Reference Text</th>
            <th>Target Anchor ID</th>
            <th>Source Page</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {links && Array.isArray(links) && links.length > 0 ? (
            links.map((l: any, i: number) => (
              <tr key={i}>
                <td className="font-medium text-blue-700">{l.reference || l.text}</td>
                <td className="font-mono text-xs">{l.target || l.target_id}</td>
                <td>Page {l.sourcePage || 1}</td>
                <td>
                  <span className={`px-2 py-0.5 text-xs font-semibold rounded ${
                    l.status === 'resolved' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {l.status?.toUpperCase()}
                  </span>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={4} className="text-center text-xs text-gray-500 py-4">
                No cross-reference links resolved yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
