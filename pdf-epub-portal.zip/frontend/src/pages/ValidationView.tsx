import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { validationService } from '../services/validationService';
import { StatusBadge } from '../components/StatusBadge';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { CheckCircle, RotateCcw, AlertOctagon } from 'lucide-react';

export const ValidationView: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const queryClient = useQueryClient();

  const { data: valData, isLoading, isError, refetch } = useQuery({
    queryKey: ['validation', id],
    queryFn: () => validationService.getValidation(id!),
    enabled: !!id
  });

  const retryMutation = useMutation({
    mutationFn: () => validationService.runValidate(id!),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['validation', id] })
  });

  if (isLoading) return <LoadingState message="Fetching EPUBCheck validation status..." />;
  if (isError) return <ErrorState message="Failed to load validation status." onRetry={() => refetch()} />;

  const isExecuted = valData?.executed;
  const isUnavailable = valData?.status === 'EPUBCheck unavailable';

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center border-b pb-2">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <CheckCircle size={20} className="text-blue-700" /> W3C EPUBCheck Validation Status
        </h2>

        <button
          onClick={() => retryMutation.mutate()}
          className="gov-btn-secondary text-xs"
        >
          <RotateCcw size={14} /> Retry Validation
        </button>
      </div>

      {!isExecuted && isUnavailable && (
        <div className="p-4 bg-amber-50 border border-amber-300 text-amber-900 rounded flex items-center gap-3">
          <AlertOctagon size={24} className="text-amber-700 flex-shrink-0" />
          <div>
            <h4 className="font-bold text-sm">EPUBCheck unavailable</h4>
            <p className="text-xs mt-1">
              Java runtime or EPUBCheck jar file was not detected on the server system ($EPUBCHECK_PATH missing). 
              The validation gate has failed with fallback status.
            </p>
          </div>
        </div>
      )}

      {!isExecuted && !isUnavailable && (
        <div className="p-4 bg-gray-50 border border-gray-300 text-gray-700 text-center font-bold">
          Validation Not Yet Executed
        </div>
      )}

      {isExecuted && (
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <StatusBadge status={valData.status} />
            <span className="text-xs text-gray-700 font-semibold">
              Errors: <strong className="text-red-600">{valData.errors?.length || 0}</strong> &bull; 
              Warnings: <strong className="text-amber-600">{valData.warnings?.length || 0}</strong>
            </span>
          </div>

          <div className="gov-border p-4 bg-white">
            <h4 className="text-xs font-bold text-gray-800 uppercase border-b pb-1 mb-2">EPUBCheck Console Logs</h4>
            <pre className="text-xs font-mono text-gray-800 bg-gray-50 p-3 max-h-96 overflow-y-auto">
              {valData.output || 'No console output recorded.'}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
