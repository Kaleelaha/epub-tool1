import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { qaService } from '../services/qaService';
import { reportService } from '../services/reportService';
import { StatusBadge } from '../components/StatusBadge';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { ShieldCheck, Download, Check, AlertTriangle, X, Minus } from 'lucide-react';

export const QaReports: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data: qaReport, isLoading: qaLoading, isError: qaError, refetch: refetchQA } = useQuery({
    queryKey: ['qaReport', id],
    queryFn: () => qaService.getQA(id!),
    enabled: !!id
  });

  const { data: reportsList } = useQuery({
    queryKey: ['reportsList', id],
    queryFn: () => reportService.getReports(id!),
    enabled: !!id
  });

  if (qaLoading) return <LoadingState message="Evaluating QA quality gates..." />;
  if (qaError) return <ErrorState message="Failed to load QA evaluation." onRetry={() => refetchQA()} />;

  const getGateIcon = (status: string) => {
    switch (status) {
      case 'Completed':
        return <Check size={16} className="text-green-600 font-bold" />;
      case 'Warning':
        return <AlertTriangle size={16} className="text-amber-600" />;
      case 'Failed':
        return <X size={16} className="text-red-600 font-bold" />;
      default:
        return <Minus size={16} className="text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center border-b pb-2">
        <div>
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <ShieldCheck size={20} className="text-blue-700" /> Quality Gates Evaluation & Report Download
          </h2>
          <p className="text-xs text-gray-600">Standardized verification checklist for EPUB 3 release</p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-gray-700">FINAL STATUS:</span>
          <StatusBadge status={qaReport?.final_status || 'PENDING'} />
        </div>
      </div>

      <div className="gov-border p-4 bg-white">
        <h3 className="text-sm font-bold text-gray-800 border-b pb-2 mb-3">Quality Gates Checklist</h3>
        <table className="gov-table">
          <thead>
            <tr>
              <th>Status</th>
              <th>Gate Description</th>
              <th>Requirement Level</th>
              <th>Evaluation State</th>
            </tr>
          </thead>
          <tbody>
            {qaReport?.gates && Array.isArray(qaReport.gates) && qaReport.gates.length > 0 ? (
              qaReport.gates.map((g: any) => (
                <tr key={g.name}>
                  <td className="w-10 text-center">{getGateIcon(g.status)}</td>
                  <td className="font-medium">{g.name}</td>
                  <td className="text-xs">{g.critical ? 'Mandatory Gate' : 'Recommended'}</td>
                  <td>
                    <StatusBadge status={g.status} />
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4} className="text-center text-xs text-gray-500 py-4">
                  No QA gate evaluation results available.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="gov-border p-4 bg-white">
        <h3 className="text-sm font-bold text-gray-800 border-b pb-2 mb-3">Generated Artifact Reports</h3>
        <table className="gov-table">
          <thead>
            <tr>
              <th>Report File Name</th>
              <th>Format</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {reportsList && Array.isArray(reportsList) && reportsList.length > 0 ? (
              reportsList.map((rf: string) => (
                <tr key={rf}>
                  <td className="font-mono text-xs">{rf}</td>
                  <td className="text-xs uppercase">{rf.split('.').pop()}</td>
                  <td>
                    <button
                      onClick={() => reportService.downloadReport(id!, rf)}
                      className="gov-btn-secondary text-xs py-1 px-2 text-blue-700 flex items-center gap-1"
                    >
                      <Download size={14} /> Download Report
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3} className="text-center text-xs text-gray-500 py-4">
                  No generated report files available.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
