import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ocrService } from '../services/ocrService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';

export const OcrView: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<'extracted' | 'ocr' | 'corrections'>('corrections');

  const { data: corrections, isLoading, isError, refetch } = useQuery({
    queryKey: ['ocrCorrections', id],
    queryFn: () => ocrService.getCorrections(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Loading OCR & corrections data..." />;
  if (isError) return <ErrorState message="Failed to load OCR corrections." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2">
        OCR Processing & Confusion Audit Log
      </h2>

      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setActiveTab('corrections')}
          className={`px-4 py-2 text-sm font-medium border-b-2 ${
            activeTab === 'corrections'
              ? 'border-blue-700 text-blue-700'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          OCR Confusion Corrections
        </button>
        <button
          onClick={() => setActiveTab('ocr')}
          className={`px-4 py-2 text-sm font-medium border-b-2 ${
            activeTab === 'ocr'
              ? 'border-blue-700 text-blue-700'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Side-by-Side OCR Verification
        </button>
      </div>

      {activeTab === 'corrections' && (
        <table className="gov-table">
          <thead>
            <tr>
              <th>Page</th>
              <th>Original Token</th>
              <th>Corrected Token</th>
              <th>Confidence</th>
              <th>Reason</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {corrections && Array.isArray(corrections) && corrections.length > 0 ? (
              corrections.map((c: any, i: number) => (
                <tr key={i}>
                  <td>Page {c.page}</td>
                  <td className="font-mono text-red-700 bg-red-50 px-1">{c.original}</td>
                  <td className="font-mono text-green-700 bg-green-50 px-1">{c.corrected}</td>
                  <td>{(c.confidence * 100).toFixed(0)}%</td>
                  <td className="text-xs text-gray-600">{c.reason}</td>
                  <td className="text-xs font-semibold">{c.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="text-center text-xs text-gray-500 py-4">
                  No OCR confusion corrections recorded.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}

      {activeTab === 'ocr' && (
        <div className="grid grid-cols-2 gap-4">
          <div className="gov-border p-4 bg-gray-50">
            <h4 className="text-sm font-bold text-gray-800 border-b pb-2 mb-2">Original Scanned PDF Render</h4>
            <div className="p-8 text-center text-xs text-gray-500 border border-dashed border-gray-300">
              [ High-DPI 300 Render View ]
            </div>
          </div>
          <div className="gov-border p-4 bg-white">
            <h4 className="text-sm font-bold text-gray-800 border-b pb-2 mb-2">OCR Extracted Text Layer</h4>
            <pre className="text-xs font-mono text-gray-800 whitespace-pre-wrap">
              SCANNED DOCUMENT TEST PAGE...
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
