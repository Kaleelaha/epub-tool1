import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { comparisonService } from '../services/comparisonService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { FileDiff } from 'lucide-react';

export const PdfVsEpub: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data: issues, isLoading, isError, refetch } = useQuery({
    queryKey: ['comparison', id],
    queryFn: () => comparisonService.getComparison(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Comparing PDF source vs EPUB output..." />;
  if (isError) return <ErrorState message="Failed to load comparison results." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
        <FileDiff size={20} className="text-blue-700" /> PDF vs EPUB Source Text & Structure Comparison
      </h2>

      <div className="grid grid-cols-2 gap-4">
        <div className="gov-border p-4 bg-gray-50">
          <h3 className="text-sm font-bold text-gray-800 border-b pb-2 mb-2">Original PDF Text Stream</h3>
          <p className="text-xs text-gray-600">Normalized page-by-page text blocks from PyMuPDF</p>
        </div>
        <div className="gov-border p-4 bg-white">
          <h3 className="text-sm font-bold text-gray-800 border-b pb-2 mb-2">EPUB XHTML Extracted Text</h3>
          <p className="text-xs text-gray-600">Normalized text stream extracted from final.epub package</p>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-bold text-gray-800 border-b pb-2 mb-3">Detected Discrepancies & Issues</h3>
        <table className="gov-table">
          <thead>
            <tr>
              <th>Page</th>
              <th>Issue Type</th>
              <th>Severity</th>
              <th>Expected</th>
              <th>Actual Output</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {issues && Array.isArray(issues) && issues.length > 0 ? (
              issues.map((i: any, idx: number) => (
                <tr key={idx}>
                  <td>Page {i.page}</td>
                  <td className="font-semibold text-xs">{i.type}</td>
                  <td>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded ${
                      i.severity === 'CRITICAL' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {i.severity}
                    </span>
                  </td>
                  <td className="text-xs">{i.expected}</td>
                  <td className="text-xs">{i.actual}</td>
                  <td className="text-xs font-mono">{i.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="text-center text-xs text-gray-500 py-4">
                  Zero discrepancies detected! EPUB matches PDF source text.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
