import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { analysisService } from '../services/analysisService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';

export const PdfAnalysis: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['pdfAnalysis', id],
    queryFn: () => analysisService.getAnalysis(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Analyzing PDF pages..." />;
  if (isError) return <ErrorState message="Failed to load PDF analysis." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2">
        PDF Page-by-Page Structure Analysis
      </h2>

      <table className="gov-table">
        <thead>
          <tr>
            <th>Page #</th>
            <th>Text Layer</th>
            <th>Quality Score</th>
            <th>OCR Required</th>
            <th>Columns</th>
            <th>Figures</th>
            <th>Tables</th>
            <th>Equations</th>
          </tr>
        </thead>
        <tbody>
          {data?.pages && Array.isArray(data.pages) && data.pages.length > 0 ? (
            data.pages.map((p: any) => (
              <tr key={p.pageNumber}>
                <td className="font-bold">Page {p.pageNumber}</td>
                <td>{p.textLayerAvailable ? 'Available' : 'Missing'}</td>
                <td>{p.quality_score ? (p.quality_score * 100).toFixed(0) + '%' : '100%'}</td>
                <td className={p.ocrRequired ? 'text-amber-700 font-bold' : 'text-gray-600'}>
                  {p.ocrRequired ? 'YES' : 'NO'}
                </td>
                <td>{p.columnCount}</td>
                <td>{p.figureCount}</td>
                <td>{p.tableCount}</td>
                <td>{p.equationCount}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={8} className="text-center text-xs text-gray-500 py-4">
                No page analysis data available. Run conversion pipeline first.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
