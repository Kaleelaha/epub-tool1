import React from 'react';
import { useParams } from 'react-router-dom';
import { Settings as SettingsIcon } from 'lucide-react';

export const Settings: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  return (
    <div className="space-y-6 max-w-3xl">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
        <SettingsIcon size={20} className="text-blue-700" /> System & Project Configuration Settings
      </h2>

      <div className="gov-border p-4 bg-white space-y-4">
        <h3 className="text-sm font-bold text-gray-800 border-b pb-1">Environment Binaries</h3>
        <div className="text-xs space-y-2 text-gray-700">
          <div><strong className="w-36 inline-block">Python Runtime:</strong> <code>Python 3.13 (py)</code></div>
          <div><strong className="w-36 inline-block">Java Version:</strong> <code>Java 21.0.9 LTS</code></div>
          <div><strong className="w-36 inline-block">EPUBCheck Path:</strong> <code>$EPUBCHECK_PATH</code></div>
          <div><strong className="w-36 inline-block">OCR Engine:</strong> <code>Tesseract CLI (eng)</code></div>
        </div>
      </div>
    </div>
  );
};
