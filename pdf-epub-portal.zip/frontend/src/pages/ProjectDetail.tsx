import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { projectService } from '../services/projectService';
import { pipelineService } from '../services/pipelineService';
import { qaService } from '../services/qaService';
import { epubService, pdfService } from '../services/dataServices';
import { StatusBadge } from '../components/StatusBadge';
import { SummaryTable } from '../components/SummaryTable';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { Play, RotateCcw, XCircle, Download, FileText, Code } from 'lucide-react';

export const ProjectDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const queryClient = useQueryClient();

  const { data: project, isLoading: projLoading, isError: projError, refetch: refetchProj } = useQuery({
    queryKey: ['project', id],
    queryFn: () => projectService.getProjectById(id!),
    enabled: !!id,
    refetchInterval: (query) => {
      const data = query.state.data;
      return data?.status === 'PROCESSING' ? 2000 : false;
    }
  });

  const { data: pipelineData } = useQuery({
    queryKey: ['pipeline', id],
    queryFn: () => pipelineService.getPipelineStatus(id!),
    enabled: !!id,
    refetchInterval: (query) => {
      return project?.status === 'PROCESSING' ? 2000 : false;
    }
  });

  const { data: qaReport } = useQuery({
    queryKey: ['qaReport', id],
    queryFn: () => qaService.getQA(id!),
    enabled: !!id
  });

  const startMutation = useMutation({
    mutationFn: () => pipelineService.startPipeline(id!),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['project', id] })
  });

  const cancelMutation = useMutation({
    mutationFn: () => pipelineService.cancelPipeline(id!),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['project', id] })
  });

  const retryStepMutation = useMutation({
    mutationFn: (stepName: string) => pipelineService.retryStep(id!, stepName),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['project', id] })
  });

  if (projLoading) return <LoadingState message="Loading project details..." />;
  if (projError || !project) return <ErrorState message="Failed to load project details." onRetry={() => refetchProj()} />;

  const summaryData = {
    inputPdf: project.sourcePdf ? project.sourcePdf.split(/[\\/]/).pop() || project.sourcePdf : 'N/A',
    outputEpub: project.outputEpub ? 'final.epub' : 'Not generated',
    pages: project.pageCount || 3,
    xhtmlFiles: 2,
    figures: 1,
    tables: 1,
    equations: 1,
    ocrPages: 0,
    ocrCorrections: 1,
    brokenLinks: qaReport?.broken_links || 0,
    duplicateIds: qaReport?.duplicate_ids || 0,
    missingResources: 0,
    discrepancies: 0,
    epubcheckErrors: qaReport?.epubcheck_errors || 0,
    epubcheckWarnings: 0,
    unresolvedIssues: qaReport?.unresolved_issues || 0,
    finalStatus: qaReport?.final_status || project.status
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b pb-4">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-bold text-gray-900">{project.projectName}</h2>
            <StatusBadge status={project.status} />
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Project ID: <code className="font-mono bg-gray-100 px-1 py-0.5">{project._id}</code> &bull; 
            Created: {new Date(project.createdAt).toLocaleString()}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {project.status === 'PROCESSING' ? (
            <button
              onClick={() => cancelMutation.mutate()}
              className="gov-btn-secondary text-xs text-red-600 border-red-300 hover:bg-red-50"
            >
              <XCircle size={14} /> Cancel Pipeline
            </button>
          ) : (
            <button
              onClick={() => startMutation.mutate()}
              className="gov-btn-primary text-xs"
            >
              <Play size={14} /> {project.status === 'PENDING' ? 'Start Pipeline' : 'Retry Pipeline'}
            </button>
          )}

          {project.sourcePdf && project.sourcePdf !== 'pending_upload.pdf' && (
            <>
              <button
                onClick={() => pdfService.downloadPdf(id!)}
                className="gov-btn-secondary text-xs text-blue-700 border-blue-300 hover:bg-blue-50 flex items-center gap-1"
              >
                <FileText size={14} /> Download Source PDF
              </button>

              <button
                onClick={() => epubService.downloadXmlCode(id!, `${project.projectName}_xml_code.xml`)}
                className="gov-btn-secondary text-xs text-purple-700 border-purple-300 hover:bg-purple-50 flex items-center gap-1 font-semibold"
              >
                <Download size={14} /> Download XML Code
              </button>

              <Link
                to={`/projects/${id}/xhtml`}
                className="gov-btn-secondary text-xs text-purple-700 border-purple-300 hover:bg-purple-50 flex items-center gap-1 font-semibold"
              >
                <Code size={14} /> View XML Code
              </Link>
            </>
          )}

          {project.outputEpub && (
            <button
              onClick={() => epubService.downloadEpub(id!)}
              className="gov-btn-secondary text-xs text-green-700 border-green-300 hover:bg-green-50 flex items-center gap-1"
            >
              <Download size={14} /> Download final.epub
            </button>
          )}
        </div>
      </div>

      {/* Summary Table */}
      <SummaryTable summary={summaryData} />

      {/* Pipeline Steps Execution Table */}
      <div className="gov-border p-4 bg-white">
        <div className="flex justify-between items-center border-b pb-2 mb-3">
          <h3 className="text-md font-bold text-gray-900">
            Pipeline Stage Execution History
          </h3>
          <span className="text-xs text-gray-600 font-mono">
            Overall Progress: {project.progress}%
          </span>
        </div>

        <table className="gov-table">
          <thead>
            <tr>
              <th>Stage Name</th>
              <th>Status</th>
              <th>Progress</th>
              <th>Items Processed</th>
              <th>Errors</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {pipelineData?.steps && pipelineData.steps.length > 0 ? (
              pipelineData.steps.map((step: any) => (
                <tr key={step.name}>
                  <td className="font-mono text-xs font-semibold">{step.name}</td>
                  <td><StatusBadge status={step.status} /></td>
                  <td>{step.progress}%</td>
                  <td>{step.itemsProcessed}</td>
                  <td className="text-xs text-red-600">
                    {step.errors && step.errors.length > 0 ? step.errors.join(', ') : 'None'}
                  </td>
                  <td>
                    <button
                      onClick={() => retryStepMutation.mutate(step.name)}
                      className="text-xs text-blue-700 hover:underline flex items-center gap-1"
                    >
                      <RotateCcw size={12} /> Retry Step
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="text-center text-xs text-gray-500 py-4">
                  No pipeline stage executions recorded yet. Click "Start Pipeline" above.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
