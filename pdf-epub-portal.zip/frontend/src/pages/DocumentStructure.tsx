import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { structureService } from '../services/structureService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { GitBranch, FileText } from 'lucide-react';

export const DocumentStructure: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['structure', id],
    queryFn: () => structureService.getStructure(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Detecting document hierarchy..." />;
  if (isError) return <ErrorState message="Failed to load document structure." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
        <GitBranch size={20} className="text-blue-700" /> Document Tree & Hierarchy Detection
      </h2>

      <div className="gov-border p-4 bg-white">
        <h3 className="text-sm font-bold text-gray-800 border-b pb-2 mb-3">Detected Document Nodes</h3>
        <ul className="space-y-2 text-sm font-mono">
          <li className="flex items-center gap-2 text-blue-800 font-bold">
            <FileText size={16} /> Cover.xhtml (Front Matter)
          </li>
          <li className="flex items-center gap-2 text-blue-800 font-bold ml-4">
            <FileText size={16} /> Chapter_01.xhtml
          </li>
          <li className="ml-8 text-gray-700">• H1: Chapter 1: Introduction to Standard EPUB Conversion</li>
          <li className="ml-12 text-gray-600">• H2: 1.1 Primary Objectives</li>
          <li className="ml-16 text-gray-500">• Paragraph (class: noindent)</li>
          <li className="ml-16 text-gray-500">• List (4 items)</li>
          <li className="ml-16 text-gray-500">• Figure f1.1 [Sample Workflow Diagram]</li>
          
          <li className="flex items-center gap-2 text-blue-800 font-bold ml-4 mt-3">
            <FileText size={16} /> Chapter_02.xhtml
          </li>
          <li className="ml-8 text-gray-700">• H1: Chapter 2: Technical Specifications and Formulas</li>
          <li className="ml-12 text-gray-600">• H2: 2.1 Table Data and Structured Records</li>
          <li className="ml-16 text-gray-500">• Table t2.1 (4 rows, 3 cols)</li>
          <li className="ml-12 text-gray-600">• H2: 2.2 Mathematical Equations</li>
          <li className="ml-16 text-gray-500">• Equation eq2.1 (MathML)</li>
        </ul>
      </div>
    </div>
  );
};
