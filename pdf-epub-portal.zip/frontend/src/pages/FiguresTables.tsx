import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { figureService } from '../services/figureService';
import { tableService } from '../services/tableService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { Image, Table } from 'lucide-react';

export const FiguresTables: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data: figures, isLoading: figsLoading, isError: figsError, refetch: refetchFigs } = useQuery({
    queryKey: ['figures', id],
    queryFn: () => figureService.getFigures(id!),
    enabled: !!id
  });

  const { data: tables, isLoading: tblsLoading, isError: tblsError, refetch: refetchTbls } = useQuery({
    queryKey: ['tables', id],
    queryFn: () => tableService.getTables(id!),
    enabled: !!id
  });

  if (figsLoading || tblsLoading) return <LoadingState message="Extracting figures & tables..." />;
  if (figsError || tblsError) return <ErrorState message="Failed to load figures and tables." onRetry={() => { refetchFigs(); refetchTbls(); }} />;

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-bold text-gray-900 border-b pb-2 mb-3 flex items-center gap-2">
          <Image size={20} className="text-blue-700" /> Extracted Figures & Accessible Alt Texts
        </h2>
        <table className="gov-table">
          <thead>
            <tr>
              <th>Figure ID</th>
              <th>Page</th>
              <th>Caption</th>
              <th>Alt Text</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {figures && Array.isArray(figures) && figures.length > 0 ? (
              figures.map((f: any) => (
                <tr key={f.figureId}>
                  <td className="font-mono font-bold text-blue-700">{f.figureId}</td>
                  <td>Page {f.page}</td>
                  <td>{f.caption || 'N/A'}</td>
                  <td className="text-xs text-gray-700 italic">{f.altText}</td>
                  <td className="text-xs font-semibold">{f.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="text-center text-xs text-gray-500 py-4">
                  No figures extracted.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div>
        <h2 className="text-xl font-bold text-gray-900 border-b pb-2 mb-3 flex items-center gap-2">
          <Table size={20} className="text-blue-700" /> Reconstructed Semantic Tables
        </h2>
        <table className="gov-table">
          <thead>
            <tr>
              <th>Table ID</th>
              <th>Page</th>
              <th>Rows</th>
              <th>Columns</th>
              <th>Reconstruction</th>
              <th>Caption</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {tables && Array.isArray(tables) && tables.length > 0 ? (
              tables.map((t: any) => (
                <tr key={t.tableId}>
                  <td className="font-mono font-bold text-blue-700">{t.tableId}</td>
                  <td>Page {t.page}</td>
                  <td>{t.rows}</td>
                  <td>{t.cols}</td>
                  <td className="font-mono text-xs">{t.reconstruction}</td>
                  <td>{t.caption || 'N/A'}</td>
                  <td className="text-xs font-semibold">{t.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={7} className="text-center text-xs text-gray-500 py-4">
                  No tables extracted.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
