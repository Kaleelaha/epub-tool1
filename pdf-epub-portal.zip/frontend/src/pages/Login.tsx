import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { authService } from '../services/authService';
import { LogIn } from 'lucide-react';

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required')
});

type FormData = z.infer<typeof loginSchema>;

export const Login: React.FC<{ onLoginSuccess: (token: string, user: any) => void }> = ({ onLoginSuccess }) => {
  const navigate = useNavigate();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(loginSchema)
  });

  const onSubmit = async (data: FormData) => {
    setErrorMsg(null);
    try {
      const res = await authService.login(data);
      onLoginSuccess(res.token, res.user);
      navigate('/projects');
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || 'Login failed. Check credentials.');
    }
  };

  return (
    <div className="max-w-md mx-auto my-12 gov-border p-6 bg-white">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 mb-4 flex items-center gap-2">
        <LogIn size={20} className="text-blue-700" /> Portal User Login
      </h2>

      {errorMsg && (
        <div className="p-3 bg-red-50 text-red-700 text-xs border border-red-200 mb-4">
          {errorMsg}
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
          <input
            type="email"
            {...register('email')}
            className="w-full border border-gray-300 p-2 text-sm rounded focus:outline-none focus:border-blue-700"
            placeholder="user@government.portal"
          />
          {errors.email && <p className="text-xs text-red-600 mt-1">{errors.email.message}</p>}
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1">Password</label>
          <input
            type="password"
            {...register('password')}
            className="w-full border border-gray-300 p-2 text-sm rounded focus:outline-none focus:border-blue-700"
            placeholder="••••••••"
          />
          {errors.password && <p className="text-xs text-red-600 mt-1">{errors.password.message}</p>}
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="gov-btn-primary w-full justify-center py-2 text-sm"
        >
          {isSubmitting ? 'Authenticating...' : 'Sign In'}
        </button>

        <div className="text-xs text-center text-gray-600 pt-2 border-t">
          Don't have an account? <Link to="/register" className="text-blue-700 font-semibold hover:underline">Register here</Link>
        </div>
      </form>
    </div>
  );
};
