import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { logService } from '../services/logService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { Terminal } from 'lucide-react';

export const LogsView: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data: logs, isLoading, isError, refetch } = useQuery({
    queryKey: ['logs', id],
    queryFn: () => logService.getLogs(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Fetching pipeline execution logs..." />;
  if (isError) return <ErrorState message="Failed to load logs." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
        <Terminal size={20} className="text-blue-700" /> Pipeline Execution Audit Logs
      </h2>

      <table className="gov-table font-mono text-xs">
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Level</th>
            <th>Stage</th>
            <th>Message</th>
          </tr>
        </thead>
        <tbody>
          {logs && Array.isArray(logs) && logs.length > 0 ? (
            logs.map((l: any, i: number) => (
              <tr key={i}>
                <td className="text-gray-600">{new Date(l.timestamp).toISOString()}</td>
                <td>
                  <span className={`px-1.5 py-0.5 font-bold text-[10px] rounded ${
                    l.level === 'ERROR' || l.level === 'CRITICAL'
                      ? 'bg-red-100 text-red-800'
                      : l.level === 'WARNING'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}>
                    {l.level}
                  </span>
                </td>
                <td className="text-gray-800 font-semibold">{l.stage}</td>
                <td className="text-gray-900">{l.message}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={4} className="text-center text-xs text-gray-500 py-4 font-sans">
                No pipeline execution logs recorded yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
