import React from 'react';
import { Link } from 'react-router-dom';
import { FilePlus, Folder, CheckCircle, ArrowRight } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { projectService } from '../services/projectService';
import { StatusBadge } from '../components/StatusBadge';
import { LoadingState } from '../components/LoadingState';

export const Home: React.FC = () => {
  const { data: projects, isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: projectService.getProjects
  });

  return (
    <div className="space-y-6">
      <div className="gov-border p-6 bg-slate-50 border-l-4 border-l-blue-700">
        <h2 className="text-xl font-bold text-gray-900 mb-2">
          Automated PDF → EPUB 3 Conversion & Validation Portal
        </h2>
        <p className="text-sm text-gray-700 leading-relaxed mb-4">
          This portal provides standardized, accessible conversion of digital and scanned PDF documents into valid EPUB 3 packages.
          The system reconstructs semantic markup (HTML5 tags, MathML equations, structured tables) and validates output against standard quality gates.
        </p>
        <div className="flex gap-4">
          <Link to="/new-conversion" className="gov-btn-primary">
            <FilePlus size={16} /> Start New Conversion
          </Link>
          <Link to="/projects" className="gov-btn-secondary">
            <Folder size={16} /> View All Projects
          </Link>
        </div>
      </div>

      <div>
        <h3 className="text-md font-bold text-gray-900 border-b pb-2 mb-3">
          Recent Projects & Pipeline Status
        </h3>

        {isLoading ? (
          <LoadingState message="Fetching recent conversion projects..." />
        ) : !Array.isArray(projects) || projects.length === 0 ? (
          <div className="p-6 text-center gov-border bg-gray-50 text-gray-600 text-sm">
            {!projects || (projects as any).error ? (
              <span>Please <Link to="/login" className="text-blue-700 font-bold hover:underline">Login</Link> or <Link to="/register" className="text-blue-700 font-bold hover:underline">Register</Link> to create and view conversion projects.</span>
            ) : (
              <span>No conversion projects found. Click "Start New Conversion" to upload a PDF.</span>
            )}
          </div>
        ) : (
          <table className="gov-table">
            <thead>
              <tr>
                <th>Project Name</th>
                <th>File Size</th>
                <th>Status</th>
                <th>Stage</th>
                <th>Progress</th>
                <th>Created At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {projects.slice(0, 5).map((p) => (
                <tr key={p._id}>
                  <td className="font-medium text-blue-700">{p.projectName}</td>
                  <td>{(p.fileSize / (1024 * 1024)).toFixed(2)} MB</td>
                  <td><StatusBadge status={p.status} /></td>
                  <td className="text-xs font-mono">{p.currentStage}</td>
                  <td>
                    <div className="w-24 bg-gray-200 h-2.5 rounded overflow-hidden">
                      <div className="bg-blue-700 h-2.5" style={{ width: `${p.progress}%` }}></div>
                    </div>
                  </td>
                  <td className="text-xs text-gray-600">{new Date(p.createdAt).toLocaleDateString()}</td>
                  <td>
                    <Link to={`/projects/${p._id}`} className="text-xs font-medium text-blue-700 hover:underline flex items-center gap-1">
                      Details <ArrowRight size={12} />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
