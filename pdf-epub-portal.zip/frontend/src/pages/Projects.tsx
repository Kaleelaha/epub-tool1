import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { projectService } from '../services/projectService';
import { StatusBadge } from '../components/StatusBadge';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { FilePlus, Trash2, Eye } from 'lucide-react';

export const Projects: React.FC = () => {
  const queryClient = useQueryClient();

  const { data: projects, isLoading, isError, refetch } = useQuery({
    queryKey: ['projects'],
    queryFn: projectService.getProjects
  });

  const deleteMutation = useMutation({
    mutationFn: projectService.deleteProject,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
    }
  });

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete project "${name}"?`)) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center border-b pb-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Conversion Projects Repository</h2>
          <p className="text-xs text-gray-600">List of all document conversion jobs and status</p>
        </div>
        <Link to="/new-conversion" className="gov-btn-primary">
          <FilePlus size={16} /> New Conversion
        </Link>
      </div>

      {isLoading ? (
        <LoadingState message="Loading projects list..." />
      ) : isError ? (
        <ErrorState message="Failed to load projects." onRetry={() => refetch()} />
      ) : !Array.isArray(projects) || projects.length === 0 ? (
        <div className="p-8 text-center gov-border bg-gray-50 text-gray-600 text-sm">
          {!projects || (projects as any).error ? (
            <span>Please <Link to="/login" className="text-blue-700 font-bold hover:underline">Login</Link> or <Link to="/register" className="text-blue-700 font-bold hover:underline">Register</Link> to view projects.</span>
          ) : (
            <span>No projects found. Click "New Conversion" to convert a PDF document.</span>
          )}
        </div>
      ) : (
        <table className="gov-table">
          <thead>
            <tr>
              <th>Project Name</th>
              <th>Status</th>
              <th>Current Stage</th>
              <th>Progress</th>
              <th>File Size</th>
              <th>Created Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((p) => (
              <tr key={p._id}>
                <td className="font-medium text-blue-700">
                  <Link to={`/projects/${p._id}`} className="hover:underline">{p.projectName}</Link>
                </td>
                <td><StatusBadge status={p.status} /></td>
                <td className="text-xs font-mono">{p.currentStage}</td>
                <td>
                  <div className="w-24 bg-gray-200 h-2 rounded overflow-hidden">
                    <div className="bg-blue-700 h-2" style={{ width: `${p.progress}%` }}></div>
                  </div>
                </td>
                <td>{(p.fileSize / (1024 * 1024)).toFixed(2)} MB</td>
                <td className="text-xs text-gray-600">{new Date(p.createdAt).toLocaleString()}</td>
                <td>
                  <div className="flex items-center space-x-2">
                    <Link to={`/projects/${p._id}`} className="gov-btn-secondary text-xs py-1 px-2">
                      <Eye size={14} /> View
                    </Link>
                    <button
                      onClick={() => handleDelete(p._id, p.projectName)}
                      className="text-red-600 hover:text-red-800 p-1"
                      title="Delete Project"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};
