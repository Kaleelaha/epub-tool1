import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { epubService, downloadFileHelper } from '../services/dataServices';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { Code, Eye, Download, Copy, Check } from 'lucide-react';

export const XhtmlViewer: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [selectedFile, setSelectedFile] = useState<string>('');
  const [viewMode, setViewMode] = useState<'source' | 'rendered'>('source');
  const [copied, setCopied] = useState<boolean>(false);

  const { data: fileList, isLoading: listLoading } = useQuery({
    queryKey: ['xhtmlList', id],
    queryFn: () => epubService.getXHTMLList(id!),
    enabled: !!id
  });

  useEffect(() => {
    if (fileList && Array.isArray(fileList) && fileList.length > 0) {
      if (!selectedFile || !fileList.includes(selectedFile)) {
        setSelectedFile(fileList[0]);
      }
    }
  }, [fileList, selectedFile]);

  const { data: fileContent, isLoading: contentLoading, isError, refetch } = useQuery({
    queryKey: ['xhtmlFile', id, selectedFile],
    queryFn: () => epubService.getXHTMLFile(id!, selectedFile),
    enabled: !!id && !!selectedFile
  });

  const handleCopy = () => {
    if (fileContent) {
      navigator.clipboard.writeText(fileContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadFile = () => {
    if (id && selectedFile) {
      const filename = selectedFile.split('/').pop() || 'document.xml';
      downloadFileHelper(`/projects/${id}/xhtml/${selectedFile}`, filename);
    }
  };

  if (listLoading) return <LoadingState message="Loading XML & XHTML file manifest..." />;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center border-b pb-2 gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <Code size={20} className="text-blue-700" /> Generated XML & XHTML Code Viewer
          </h2>
          <p className="text-xs text-gray-600">
            Inspect & download the raw XML structures generated from your source PDF document
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => id && epubService.downloadXmlCode(id)}
            className="gov-btn-secondary text-xs text-purple-700 border-purple-300 hover:bg-purple-50 flex items-center gap-1 font-semibold"
          >
            <Download size={14} /> Download All XML Code
          </button>

          {selectedFile && (
            <>
              <button
                onClick={handleCopy}
                disabled={!fileContent}
                className="gov-btn-secondary text-xs flex items-center gap-1"
              >
                {copied ? <Check size={14} className="text-green-600" /> : <Copy size={14} />}
                {copied ? 'Copied XML!' : 'Copy Code'}
              </button>

              <button
                onClick={handleDownloadFile}
                disabled={!fileContent}
                className="gov-btn-primary text-xs flex items-center gap-1"
              >
                <Download size={14} /> Download {selectedFile.split('/').pop()}
              </button>
            </>
          )}

          <div className="flex gap-1 border-l pl-2 border-gray-300">
            <button
              onClick={() => setViewMode('source')}
              className={`gov-btn-secondary text-xs ${viewMode === 'source' ? 'bg-blue-100 font-bold text-blue-800' : ''}`}
            >
              <Code size={14} /> XML Code
            </button>
            <button
              onClick={() => setViewMode('rendered')}
              className={`gov-btn-secondary text-xs ${viewMode === 'rendered' ? 'bg-blue-100 font-bold text-blue-800' : ''}`}
            >
              <Eye size={14} /> Rendered View
            </button>
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="w-1/4 gov-border p-3 bg-gray-50 flex flex-col gap-2">
          <div className="flex justify-between items-center border-b pb-1">
            <h4 className="text-xs font-bold text-gray-700 uppercase">Generated XML Files</h4>
            <span className="text-xs font-mono bg-gray-200 px-1.5 py-0.5 rounded text-gray-800 font-bold">
              {fileList?.length || 0}
            </span>
          </div>

          <ul className="space-y-1 text-xs max-h-[550px] overflow-y-auto">
            {fileList && Array.isArray(fileList) && fileList.length > 0 ? (
              fileList.map((f: string) => (
                <li key={f}>
                  <button
                    onClick={() => setSelectedFile(f)}
                    className={`w-full text-left px-2 py-1.5 rounded font-mono text-xs truncate ${
                      selectedFile === f ? 'bg-blue-700 text-white font-bold' : 'hover:bg-gray-200 text-gray-800'
                    }`}
                    title={f}
                  >
                    {f}
                  </button>
                </li>
              ))
            ) : (
              <li className="text-gray-500 italic text-xs py-2">
                No XML files available. Run the pipeline to generate XML code.
              </li>
            )}
          </ul>
        </div>

        <div className="flex-1 gov-border p-4 bg-white overflow-x-auto min-h-[500px] flex flex-col">
          <div className="border-b pb-2 mb-3 flex justify-between items-center text-xs font-mono text-gray-600">
            <span>File Path: <strong>{selectedFile || 'None selected'}</strong></span>
            {fileContent && (
              <span>Size: {(new Blob([fileContent]).size / 1024).toFixed(2)} KB</span>
            )}
          </div>

          {contentLoading ? (
            <LoadingState message="Reading file content..." />
          ) : isError ? (
            <ErrorState message="Failed to load XML/XHTML content." onRetry={() => refetch()} />
          ) : viewMode === 'source' ? (
            <pre className="text-xs font-mono text-gray-800 bg-gray-50 p-4 rounded border border-gray-200 overflow-auto max-h-[600px] whitespace-pre-wrap">
              {fileContent || 'No content found in file.'}
            </pre>
          ) : (
            <div
              className="prose text-sm max-w-none p-4 bg-white border border-gray-200 rounded max-h-[600px] overflow-auto"
              dangerouslySetInnerHTML={{ __html: fileContent || '<p className="text-gray-500">No content rendered</p>' }}
            />
          )}
        </div>
      </div>
    </div>
  );
};
