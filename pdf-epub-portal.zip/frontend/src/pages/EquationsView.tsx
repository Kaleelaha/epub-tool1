import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { equationService } from '../services/equationService';
import { LoadingState } from '../components/LoadingState';
import { ErrorState } from '../components/ErrorState';
import { Binary } from 'lucide-react';

export const EquationsView: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const { data: equations, isLoading, isError, refetch } = useQuery({
    queryKey: ['equations', id],
    queryFn: () => equationService.getEquations(id!),
    enabled: !!id
  });

  if (isLoading) return <LoadingState message="Extracting MathML & chemical formulas..." />;
  if (isError) return <ErrorState message="Failed to load equations." onRetry={() => refetch()} />;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
        <Binary size={20} className="text-blue-700" /> Equations & MathML Conversion
      </h2>

      <table className="gov-table">
        <thead>
          <tr>
            <th>Equation ID</th>
            <th>Page</th>
            <th>Type</th>
            <th>MathML Output</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {equations && Array.isArray(equations) && equations.length > 0 ? (
            equations.map((eq: any) => (
              <tr key={eq.equationId}>
                <td className="font-mono font-bold text-blue-700">{eq.equationId}</td>
                <td>Page {eq.page}</td>
                <td>{eq.eqType}</td>
                <td className="font-mono text-xs bg-gray-50 p-2 max-w-md overflow-x-auto">
                  {eq.mathml}
                </td>
                <td className="text-xs font-semibold">{eq.status}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={5} className="text-center text-xs text-gray-500 py-4">
                No mathematical equations detected.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
