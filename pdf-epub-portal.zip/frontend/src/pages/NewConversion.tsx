import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { projectService } from '../services/projectService';
import { pipelineService } from '../services/pipelineService';
import { FileUp, CheckCircle, AlertCircle } from 'lucide-react';

const conversionSchema = z.object({
  projectName: z.string().min(1, 'Project name is required'),
  ocrMode: z.enum(['auto', 'force', 'skip']),
  ocrLanguage: z.string().min(1, 'OCR language required'),
  ocrVerification: z.boolean(),
  detectStructure: z.boolean(),
  detectFigures: z.boolean(),
  detectTables: z.boolean(),
  detectEquations: z.boolean(),
  resolveCrossRefs: z.boolean(),
  runEpubCheck: z.boolean(),
  runComparison: z.boolean(),
  runQA: z.boolean()
});

type FormData = z.infer<typeof conversionSchema>;

export const NewConversion: React.FC = () => {
  const navigate = useNavigate();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(conversionSchema),
    defaultValues: {
      projectName: '',
      ocrMode: 'auto',
      ocrLanguage: 'eng',
      ocrVerification: true,
      detectStructure: true,
      detectFigures: true,
      detectTables: true,
      detectEquations: true,
      resolveCrossRefs: true,
      runEpubCheck: true,
      runComparison: true,
      runQA: true
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setUploadStatus(`File selected: ${file.name} (${(file.size / (1024 * 1024)).toFixed(2)} MB)`);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (!selectedFile) {
      setErrorMsg('Please select a PDF file to upload.');
      return;
    }

    setErrorMsg(null);
    setUploadStatus('Creating project & uploading PDF file...');

    try {
      // 1. Create Project
      const project = await projectService.createProject({
        projectName: data.projectName,
        config: data
      });

      // 2. Upload PDF File
      await projectService.uploadPdf(project._id, selectedFile);
      setUploadStatus('Upload completed. Starting conversion pipeline...');

      // 3. Queue Pipeline
      await pipelineService.startPipeline(project._id);

      navigate(`/projects/${project._id}`);
    } catch (err: any) {
      setErrorMsg(err.response?.data?.error || 'Failed to initiate conversion.');
      setUploadStatus(null);
    }
  };

  return (
    <div className="max-w-3xl mx-auto gov-border p-6 bg-white space-y-6">
      <h2 className="text-xl font-bold text-gray-900 border-b pb-2 flex items-center gap-2">
        <FileUp size={20} className="text-blue-700" /> Start New PDF → EPUB 3 Conversion
      </h2>

      {errorMsg && (
        <div className="p-3 bg-red-50 text-red-700 text-xs border border-red-200 flex items-center gap-2">
          <AlertCircle size={16} />
          <span>{errorMsg}</span>
        </div>
      )}

      {uploadStatus && (
        <div className="p-3 bg-blue-50 text-blue-800 text-xs border border-blue-200 flex items-center gap-2">
          <CheckCircle size={16} />
          <span>{uploadStatus}</span>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wide border-b pb-1">
            1. Document & Metadata Setup
          </h3>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Project Name *</label>
            <input
              type="text"
              {...register('projectName')}
              className="w-full border border-gray-300 p-2 text-sm rounded focus:outline-none focus:border-blue-700"
              placeholder="e.g. Standard Guidelines 2026 Manual"
            />
            {errors.projectName && <p className="text-xs text-red-600 mt-1">{errors.projectName.message}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Select Source PDF File (.pdf) *</label>
            <input
              type="file"
              accept=".pdf,application/pdf"
              onChange={handleFileChange}
              className="w-full border border-gray-300 p-2 text-sm rounded bg-gray-50 focus:outline-none"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wide border-b pb-1">
            2. Pipeline Processing Options
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">OCR Strategy Mode</label>
              <select {...register('ocrMode')} className="w-full border border-gray-300 p-2 text-sm rounded">
                <option value="auto">Auto (OCR poor text pages only)</option>
                <option value="force">Force OCR (all pages)</option>
                <option value="skip">Skip OCR (text layer only)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">OCR Primary Language</label>
              <input
                type="text"
                {...register('ocrLanguage')}
                className="w-full border border-gray-300 p-2 text-sm rounded"
                placeholder="eng"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs text-gray-700 pt-2">
            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('ocrVerification')} className="rounded text-blue-700" />
              <span>Enable OCR Confusion Verification</span>
            </label>

            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('detectStructure')} className="rounded text-blue-700" />
              <span>Document Tree & Hierarchy Detection</span>
            </label>

            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('detectFigures')} className="rounded text-blue-700" />
              <span>Extract Embedded Figures & Alt Texts</span>
            </label>

            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('detectTables')} className="rounded text-blue-700" />
              <span>Reconstruct Semantic Tables</span>
            </label>

            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('detectEquations')} className="rounded text-blue-700" />
              <span>Math & MathML Equation Processing</span>
            </label>

            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('resolveCrossRefs')} className="rounded text-blue-700" />
              <span>Resolve Cross-Reference Links</span>
            </label>

            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('runEpubCheck')} className="rounded text-blue-700" />
              <span>Execute EPUBCheck Validator</span>
            </label>

            <label className="flex items-center gap-2">
              <input type="checkbox" {...register('runQA')} className="rounded text-blue-700" />
              <span>Run Quality Gates Evaluation</span>
            </label>
          </div>
        </div>

        <div className="pt-4 border-t flex justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate('/projects')}
            className="gov-btn-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="gov-btn-primary"
          >
            {isSubmitting ? 'Starting Pipeline...' : 'Upload & Start Conversion'}
          </button>
        </div>
      </form>
    </div>
  );
};
