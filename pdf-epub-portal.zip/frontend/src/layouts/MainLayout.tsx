import React from 'react';
import { Outlet } from 'react-router-dom';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { Sidebar } from '../components/Sidebar';
import { User } from '../types';

interface MainLayoutProps {
  children?: React.ReactNode;
  user: User | null;
  onLogout: () => void;
  projectId?: string;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children, user, onLogout, projectId }) => {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header user={user} onLogout={onLogout} />
      <div className="flex flex-1 max-w-7xl w-full mx-auto">
        <Sidebar projectId={projectId} />
        <main className="flex-1 p-6 overflow-x-auto">
          {children ? children : <Outlet />}
        </main>
      </div>
      <Footer />
    </div>
  );
};

