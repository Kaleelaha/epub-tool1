import { api } from './api';
import { Project } from '../types';

export const projectService = {
  getProjects: async (): Promise<Project[]> => {
    const res = await api.get('/projects');
    return res.data;
  },
  createProject: async (data: { projectName: string; config?: any }): Promise<Project> => {
    const res = await api.post('/projects', data);
    return res.data;
  },
  getProjectById: async (id: string): Promise<Project> => {
    const res = await api.get(`/projects/${id}`);
    return res.data;
  },
  deleteProject: async (id: string): Promise<void> => {
    await api.delete(`/projects/${id}`);
  },
  uploadPdf: async (id: string, file: File): Promise<any> => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await api.post(`/projects/${id}/upload`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    return res.data;
  }
};
