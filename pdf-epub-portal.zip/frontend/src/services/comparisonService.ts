export { comparisonService } from './dataServices';
