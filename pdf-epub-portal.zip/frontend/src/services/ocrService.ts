export { ocrService } from './dataServices';
