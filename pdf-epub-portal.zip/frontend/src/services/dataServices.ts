import { api } from './api';

export const analysisService = {
  getAnalysis: async (id: string) => {
    const res = await api.get(`/projects/${id}/analysis`);
    return res.data;
  },
  getPages: async (id: string) => {
    const res = await api.get(`/projects/${id}/pages`);
    return res.data;
  }
};

export const ocrService = {
  getOCRInfo: async (id: string) => {
    const res = await api.get(`/projects/${id}/ocr`);
    return res.data;
  },
  getCorrections: async (id: string) => {
    const res = await api.get(`/projects/${id}/ocr/corrections`);
    return res.data;
  }
};

export const structureService = {
  getStructure: async (id: string) => {
    const res = await api.get(`/projects/${id}/structure`);
    return res.data;
  }
};

export const figureService = {
  getFigures: async (id: string) => {
    const res = await api.get(`/projects/${id}/figures`);
    return res.data;
  }
};

export const tableService = {
  getTables: async (id: string) => {
    const res = await api.get(`/projects/${id}/tables`);
    return res.data;
  }
};

export const equationService = {
  getEquations: async (id: string) => {
    const res = await api.get(`/projects/${id}/equations`);
    return res.data;
  }
};

export const downloadFileHelper = async (url: string, defaultFilename: string) => {
  try {
    const res = await api.get(url, { responseType: 'blob' });
    const contentDisposition = typeof res.headers['content-disposition'] === 'string' ? res.headers['content-disposition'] : '';
    let filename = defaultFilename;
    if (contentDisposition) {
      const match = contentDisposition.match(/filename="?([^";]+)"?/);
      if (match && match[1]) {
        filename = match[1];
      }
    }
    const contentType = typeof res.headers['content-type'] === 'string' ? res.headers['content-type'] : 'application/octet-stream';
    const blob = new Blob([res.data], { type: contentType });
    const blobUrl = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(blobUrl);
  } catch (err: any) {
    let errorMsg = 'File not found or XML code has not been generated yet. Please run the pipeline first by clicking "Start Pipeline".';
    if (err.response && err.response.data instanceof Blob) {
      try {
        const text = await err.response.data.text();
        const json = JSON.parse(text);
        if (json.error) errorMsg = json.error;
      } catch (e) {}
    }
    alert(`⚠️ Download Notice: ${errorMsg}`);
  }
};

export const pdfService = {
  downloadPdf: async (id: string, filename: string = 'document.pdf') => {
    return downloadFileHelper(`/projects/${id}/pdf/download`, filename);
  }
};

export const epubService = {
  getXHTMLList: async (id: string) => {
    const res = await api.get(`/projects/${id}/xhtml`);
    return res.data;
  },
  getXHTMLFile: async (id: string, file: string) => {
    const res = await api.get(`/projects/${id}/xhtml/${file}`);
    return res.data;
  },
  getIDs: async (id: string) => {
    const res = await api.get(`/projects/${id}/ids`);
    return res.data;
  },
  getLinks: async (id: string) => {
    const res = await api.get(`/projects/${id}/links`);
    return res.data;
  },
  getEpubFiles: async (id: string) => {
    const res = await api.get(`/projects/${id}/epub/files`);
    return res.data;
  },
  downloadEpub: async (id: string, filename: string = 'final.epub') => {
    return downloadFileHelper(`/projects/${id}/epub/download`, filename);
  },
  downloadXmlCode: async (id: string, filename: string = 'project_code.xml') => {
    return downloadFileHelper(`/projects/${id}/xml/download`, filename);
  },
  getDownloadUrl: (id: string) => `/api/projects/${id}/epub/download`
};

export const validationService = {
  getValidation: async (id: string) => {
    const res = await api.get(`/projects/${id}/validation`);
    return res.data;
  },
  runValidate: async (id: string) => {
    const res = await api.post(`/projects/${id}/validate`);
    return res.data;
  }
};

export const comparisonService = {
  getComparison: async (id: string) => {
    const res = await api.get(`/projects/${id}/comparison`);
    return res.data;
  },
  runCompare: async (id: string) => {
    const res = await api.post(`/projects/${id}/compare`);
    return res.data;
  }
};

export const qaService = {
  getQA: async (id: string) => {
    const res = await api.get(`/projects/${id}/qa`);
    return res.data;
  }
};

export const reportService = {
  getReports: async (id: string) => {
    const res = await api.get(`/projects/${id}/reports`);
    return res.data;
  },
  downloadReport: async (id: string, reportId: string) => {
    return downloadFileHelper(`/projects/${id}/reports/${reportId}/download`, reportId);
  },
  getReportDownloadUrl: (id: string, reportId: string) => `/api/projects/${id}/reports/${reportId}/download`
};

export const logService = {
  getLogs: async (id: string) => {
    const res = await api.get(`/projects/${id}/logs`);
    return res.data;
  }
};
