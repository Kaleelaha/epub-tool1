import { api } from './api';

export const pipelineService = {
  startPipeline: async (id: string) => {
    const res = await api.post(`/projects/${id}/start`);
    return res.data;
  },
  getPipelineStatus: async (id: string) => {
    const res = await api.get(`/projects/${id}/pipeline`);
    return res.data;
  },
  cancelPipeline: async (id: string) => {
    const res = await api.post(`/projects/${id}/cancel`);
    return res.data;
  },
  retryPipeline: async (id: string) => {
    const res = await api.post(`/projects/${id}/pipeline/retry`);
    return res.data;
  },
  retryStep: async (id: string, step: string) => {
    const res = await api.post(`/projects/${id}/pipeline/steps/${step}/retry`);
    return res.data;
  }
};
