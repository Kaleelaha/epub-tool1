export { structureService } from './dataServices';
