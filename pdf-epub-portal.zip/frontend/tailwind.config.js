/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        govBlue: '#1d4ed8',
        govHover: '#1e40af',
        govBg: '#ffffff',
        govBorder: '#e5e7eb',
        govText: '#1f2937',
        govMuted: '#6b7280'
      }
    },
  },
  plugins: [],
};
