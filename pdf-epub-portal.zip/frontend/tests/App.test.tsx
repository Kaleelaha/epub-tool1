import { describe, it, expect } from 'vitest';
import React from 'react';
import { render, screen } from '@testing-library/react';
import { StatusBadge } from '../src/components/StatusBadge';
import { SummaryTable } from '../src/components/SummaryTable';

describe('Frontend Component & UI Integration Tests', () => {
  it('1. StatusBadge renders COMPLETED badge with green styling', () => {
    const { container } = render(<StatusBadge status="COMPLETED" />);
    expect(container.textContent).toContain('COMPLETED');
  });

  it('2. StatusBadge renders FAILED badge with red styling', () => {
    const { container } = render(<StatusBadge status="FAILED" />);
    expect(container.textContent).toContain('FAILED');
  });

  it('3. SummaryTable renders exact required fields', () => {
    const summaryData = {
      inputPdf: 'sample_a.pdf',
      outputEpub: 'final.epub',
      pages: 3,
      xhtmlFiles: 2,
      figures: 1,
      tables: 1,
      equations: 1,
      ocrPages: 0,
      ocrCorrections: 1,
      brokenLinks: 0,
      duplicateIds: 0,
      missingResources: 0,
      discrepancies: 0,
      epubcheckErrors: 0,
      epubcheckWarnings: 0,
      unresolvedIssues: 0,
      finalStatus: 'PASS'
    };

    const { container } = render(<SummaryTable summary={summaryData} />);
    expect(container.textContent).toContain('sample_a.pdf');
    expect(container.textContent).toContain('final.epub');
    expect(container.textContent).toContain('FINAL STATUS:');
    expect(container.textContent).toContain('PASS');
  });
});
