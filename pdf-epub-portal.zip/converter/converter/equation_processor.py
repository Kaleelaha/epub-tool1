import re
from typing import List, Dict, Any
from converter.models import PageData, ExtractedEquation

class EquationProcessor:
    def process(self, pages: List[PageData]) -> List[ExtractedEquation]:
        equations: List[ExtractedEquation] = []

        for p in pages:
            eq_idx = 0
            for b in p.text_blocks:
                t = b.text.strip()
                
                # Check chemical formulas (e.g. H2O, CO2, C6H12O6)
                chem_match = re.search(r'\b([A-Z][a-z]?\d+)+[A-Z]?\b', t)
                if chem_match and not re.search(r'(Equation|Figure|Table)', t):
                    # Format as HTML subscript
                    formatted_chem = re.sub(r'([A-Za-z])(\d+)', r'\1<sub>\2</sub>', t)
                    equations.append(ExtractedEquation(
                        id=f"chem{p.page_number}.{eq_idx+1}",
                        page_num=p.page_number,
                        text=t,
                        eq_type="chemical",
                        mathml=f"<span>{formatted_chem}</span>"
                    ))
                    eq_idx += 1
                    continue

                # Check explicit equation tag or math notation (e.g. E = m * c^2 or Equation 2.1)
                eq_match = re.search(r'([A-Za-z0-9\s\+\-\*\/\=\^\(\)]+)\s*\((Equation\s+\d+(\.\d+)?)\)', t, re.IGNORECASE)
                if eq_match or "E = m * c^2" in t or "^" in t:
                    expr = eq_match.group(1).strip() if eq_match else t
                    eq_id = f"eq{p.page_number}.{eq_idx+1}"
                    
                    # Small MathML builder
                    mathml = self._build_mathml(expr)
                    equations.append(ExtractedEquation(
                        id=eq_id,
                        page_num=p.page_number,
                        text=t,
                        eq_type="block",
                        mathml=mathml
                    ))
                    eq_idx += 1

        return equations

    def _build_mathml(self, expr: str) -> str:
        # Simple MathML generator for expressions like E = m * c^2 or a / b
        tokens = expr.split()
        elements = []
        for tok in tokens:
            if "^" in tok:
                base, exp = tok.split("^", 1)
                elements.append(f"<msup><mi>{base}</mi><mn>{exp}</mn></msup>")
            elif tok in ("=", "+", "-", "*", "/"):
                elements.append(f"<mo>{tok}</mo>")
            elif tok.isdigit():
                elements.append(f"<mn>{tok}</mn>")
            elif tok.isalpha():
                elements.append(f"<mi>{tok}</mi>")
            else:
                elements.append(f"<mi>{tok}</mi>")
        
        inner = "".join(elements)
        return f'<math xmlns="http://www.w3.org/1998/Math/MathML" display="block"><mrow>{inner}</mrow></math>'
