import re
from typing import List
from converter.models import PageData

class PDFTextExtractor:
    def process(self, pages: List[PageData]) -> List[PageData]:
        for page in pages:
            raw = page.raw_text
            if not raw or len(raw.strip()) < 10:
                page.quality_score = 0.0
                page.ocr_required = True
                continue

            # Compute quality metrics
            total_chars = len(raw)
            printable_chars = sum(1 for c in raw if c.isprintable())
            replacement_chars = raw.count('\ufffd') + raw.count('?')
            
            printable_ratio = printable_chars / float(total_chars) if total_chars > 0 else 0
            replacement_ratio = replacement_chars / float(total_chars) if total_chars > 0 else 0
            
            # Simple word validity check
            words = [w.strip() for w in re.split(r'\s+', raw) if w.strip()]
            valid_words = sum(1 for w in words if re.match(r'^[a-zA-Z0-9.,;:!?()\'"-]+$', w))
            word_validity_ratio = valid_words / float(len(words)) if words else 0.0

            # Score composite
            quality_score = round((printable_ratio * 0.4) + (word_validity_ratio * 0.5) - (replacement_ratio * 0.5), 2)
            quality_score = max(0.0, min(1.0, quality_score))

            page.quality_score = quality_score
            # Mark OCR required only if quality is poor (< 0.6) or missing text layer
            page.ocr_required = bool(quality_score < 0.60 or len(words) < 5)

        return pages
