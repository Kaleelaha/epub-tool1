import os
import re
import pymupdf as fitz
from typing import List, Dict, Any
from converter.models import PageData, ExtractedImage

class FigureProcessor:
    def __init__(self, pdf_path: str, output_img_dir: str):
        self.pdf_path = pdf_path
        self.output_img_dir = output_img_dir
        os.makedirs(output_img_dir, exist_ok=True)

    def process(self, pages: List[PageData]) -> List[ExtractedImage]:
        doc = fitz.open(self.pdf_path)
        extracted_figures: List[ExtractedImage] = []
        fig_count = 0

        for page_data in pages:
            page_idx = page_data.page_number - 1
            page = doc[page_idx]
            
            # Find caption in text blocks
            caption = ""
            for b in page_data.text_blocks:
                m = re.search(r'(Figure\s+\d+(\.\d+)?)[\:\.\s]*(.*)', b.text, re.IGNORECASE)
                if m:
                    caption = b.text.strip()
                    break

            # Extract images from PDF page
            image_list = page.get_images(full=True)
            if image_list:
                for img_idx, img_info in enumerate(image_list):
                    xref = img_info[0]
                    base_image = doc.extract_image(xref)
                    image_bytes = base_image["image"]
                    ext = base_image["ext"]
                    
                    fig_count += 1
                    fig_id = f"f{page_data.page_number}.{img_idx + 1}"
                    img_filename = f"image_{fig_id.replace('.', '_')}.{ext}"
                    img_path = os.path.join(self.output_img_dir, img_filename)
                    
                    with open(img_path, "wb") as f:
                        f.write(image_bytes)

                    alt_text = caption if caption else f"Figure {page_data.page_number}.{img_idx + 1}"

                    extracted_figures.append(ExtractedImage(
                        id=fig_id,
                        page_num=page_data.page_number,
                        bbox=[0, 0, 100, 100],
                        image_bytes=image_bytes,
                        format=ext,
                        width=base_image.get("width", 300),
                        height=base_image.get("height", 200),
                        caption=caption,
                        alt_text=alt_text
                    ))
            elif "figure" in page_data.raw_text.lower() or caption:
                # Vector figure or simulated block figure -> render bounding area or page snippet
                fig_count += 1
                fig_id = f"f{page_data.page_number}.1"
                pix = page.get_pixmap(dpi=150)
                img_bytes = pix.tobytes("png")
                img_filename = f"image_{fig_id.replace('.', '_')}.png"
                img_path = os.path.join(self.output_img_dir, img_filename)
                
                with open(img_path, "wb") as f:
                    f.write(img_bytes)

                alt_text = caption if caption else f"Figure {page_data.page_number}.1"

                extracted_figures.append(ExtractedImage(
                    id=fig_id,
                    page_num=page_data.page_number,
                    bbox=[0, 0, page_data.width, page_data.height],
                    image_bytes=img_bytes,
                    format="png",
                    width=int(pix.width),
                    height=int(pix.height),
                    caption=caption,
                    alt_text=alt_text
                ))

        doc.close()
        return extracted_figures
