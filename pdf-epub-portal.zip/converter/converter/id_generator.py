import re
from typing import List, Dict, Any

class IDGenerator:
    def generate(self, tagged_sections: List[Dict[str, Any]]) -> Dict[str, Any]:
        all_ids: List[str] = []
        id_map: Dict[str, str] = {} # element ref -> id
        duplicates: List[str] = []

        chap_counter = 1
        sec_counter = 1

        for sec in tagged_sections:
            if sec.get("type") == "chapter":
                sec_id = f"chap{chap_counter:02d}"
                chap_counter += 1
                sec["id"] = sec_id
                if sec_id in all_ids:
                    duplicates.append(sec_id)
                all_ids.append(sec_id)

            for elem in sec.get("elements", []):
                tag = elem.get("tag")
                
                # Pagebreak span id
                if tag == "span" and "id" in elem:
                    elem_id = elem["id"]
                    if elem_id in all_ids:
                        duplicates.append(elem_id)
                    all_ids.append(elem_id)
                    continue

                # Headings
                if tag in ("h1", "h2", "h3", "h4"):
                    heading_text = elem.get("text", "")
                    m_sec = re.search(r'(\d+\.\d+)', heading_text)
                    if m_sec:
                        elem_id = f"sec{m_sec.group(1).replace('.', '-')}"
                    else:
                        elem_id = f"sec{sec_counter}"
                        sec_counter += 1
                    
                    elem["id"] = elem_id
                    if elem_id in all_ids:
                        duplicates.append(elem_id)
                    all_ids.append(elem_id)

                # Figure, Table, Equation already have generated ids (f1.1, t2.1, eq2.1)
                elif tag in ("figure", "table", "equation"):
                    elem_id = elem.get("id")
                    if elem_id:
                        if elem_id in all_ids:
                            duplicates.append(elem_id)
                        all_ids.append(elem_id)

        report = {
            "total_ids": len(all_ids),
            "duplicate_count": len(duplicates),
            "duplicates": duplicates,
            "all_ids": all_ids
        }
        
        return {
            "tagged_sections": tagged_sections,
            "id_report": report
        }
