from typing import List
from converter.models import PageData

class PageClassifier:
    def classify(self, pages: List[PageData]) -> List[PageData]:
        for i, page in enumerate(pages):
            text_lower = page.raw_text.lower()
            if i == 0 and ("title" in text_lower or "cover" in text_lower or len(text_lower) < 300):
                page_type = "cover"
            elif "copyright" in text_lower or "all rights reserved" in text_lower:
                page_type = "copyright"
            elif "table of contents" in text_lower or "contents" in text_lower:
                page_type = "contents"
            elif "chapter" in text_lower:
                page_type = "chapter"
            else:
                page_type = "body"
            
            # Attach page_type metadata attribute
            setattr(page, "page_type", page_type)

        return pages
