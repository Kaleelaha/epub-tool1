import re
from typing import List, Dict, Any
from converter.models import PageData

class OCRCorrector:
    CONFUSIONS = [
        (r'\b0([a-zA-Z]{2,})\b', r'O\1', "O/0 confusion in word start"),
        (r'\b1([a-zA-Z]{2,})\b', r'I\1', "1/I confusion in word start"),
        (r'\b5([a-zA-Z]{2,})\b', r'S\1', "5/S confusion in word start"),
        (r'\b([a-zA-Z]+)rn([a-zA-Z]+)\b', r'\1m\2', "rn/m confusion"),
        (r'\b([a-zA-Z]+)cl([a-zA-Z]+)\b', r'\1d\2', "cl/d confusion"),
    ]

    def process(self, pages: List[PageData]) -> Dict[str, Any]:
        corrections: List[Dict[str, Any]] = []

        for page in pages:
            for block in page.text_blocks:
                original_text = block.text
                corrected_text = original_text
                
                # Check known confusion patterns
                for pat, repl, reason in self.CONFUSIONS:
                    matches = re.finditer(pat, corrected_text)
                    for m in matches:
                        orig_word = m.group(0)
                        # Do not correct acronyms like H2O or part numbers like P100
                        if re.match(r'^[A-Z0-9]{2,}$', orig_word):
                            continue
                        
                        repl_word = re.sub(pat, repl, orig_word)
                        corrections.append({
                            "page": page.page_number,
                            "original": orig_word,
                            "corrected": repl_word,
                            "confidence": 0.85,
                            "reason": reason,
                            "status": "corrected"
                        })
                        corrected_text = corrected_text.replace(orig_word, repl_word)

                block.text = corrected_text

        return {
            "pages": pages,
            "corrections": corrections
        }
