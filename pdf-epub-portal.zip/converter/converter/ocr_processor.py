import os
import shutil
import pymupdf as fitz
from PIL import Image
import pytesseract
from typing import List, Dict, Any
from converter.models import PageData, TextBlock

class OCRProcessor:
    def __init__(self, pdf_path: str, lang: str = "eng"):
        self.pdf_path = pdf_path
        self.lang = lang

    def process(self, pages: List[PageData]) -> List[PageData]:
        tesseract_available = bool(shutil.which("tesseract"))
        
        doc = fitz.open(self.pdf_path)

        for page_data in pages:
            if not page_data.ocr_required:
                page_data.ocr_status = "skipped"
                continue

            if not tesseract_available:
                page_data.ocr_status = "unavailable"
                continue

            try:
                page_idx = page_data.page_number - 1
                page = doc[page_idx]
                pix = page.get_pixmap(dpi=300)
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

                ocr_data = pytesseract.image_to_data(img, lang=self.lang, output_type=pytesseract.Output.DICT)
                
                new_blocks: List[TextBlock] = []
                words = ocr_data.get("text", [])
                lefts = ocr_data.get("left", [])
                tops = ocr_data.get("top", [])
                widths = ocr_data.get("width", [])
                heights = ocr_data.get("height", [])
                confs = ocr_data.get("conf", [])

                scale_x = page_data.width / float(pix.width)
                scale_y = page_data.height / float(pix.height)

                current_line = []
                current_bbox = None

                for i in range(len(words)):
                    w = words[i].strip()
                    conf = int(confs[i]) if str(confs[i]).replace('-', '').isdigit() else 0
                    if not w or conf < 30:
                        continue

                    bx0 = lefts[i] * scale_x
                    by0 = tops[i] * scale_y
                    bx1 = (lefts[i] + widths[i]) * scale_x
                    by1 = (tops[i] + heights[i]) * scale_y

                    current_line.append(w)
                    if current_bbox is None:
                        current_bbox = [bx0, by0, bx1, by1]
                    else:
                        current_bbox[2] = max(current_bbox[2], bx1)
                        current_bbox[3] = max(current_bbox[3], by1)

                    if len(current_line) >= 8:
                        new_blocks.append(TextBlock(
                            text=" ".join(current_line),
                            bbox=current_bbox,
                            font_size=11.0,
                            font_name="ocr-font",
                            block_type="paragraph"
                        ))
                        current_line = []
                        current_bbox = None

                if current_line and current_bbox:
                    new_blocks.append(TextBlock(
                        text=" ".join(current_line),
                        bbox=current_bbox,
                        font_size=11.0,
                        font_name="ocr-font",
                        block_type="paragraph"
                    ))

                if new_blocks:
                    page_data.text_blocks = new_blocks
                    page_data.raw_text = "\n".join([b.text for b in new_blocks])
                    page_data.ocr_status = "processed"
                else:
                    page_data.ocr_status = "failed"

            except Exception:
                page_data.ocr_status = "failed"

        doc.close()
        return pages
