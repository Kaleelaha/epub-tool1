import os
import json
from typing import Dict, Any

class ReportGenerator:
    def generate(self, project_dir: str, context: Dict[str, Any]) -> Dict[str, str]:
        reports_dir = os.path.join(project_dir, "reports")
        os.makedirs(reports_dir, exist_ok=True)

        qa_eval = context.get("qa_eval", {})
        id_report = context.get("id_report", {})
        link_report = context.get("link_report", {})
        figures = context.get("figures", [])
        validation_res = context.get("validation_result", {})
        qa_issues = context.get("qa_issues", [])

        # 1. id-report.json
        id_path = os.path.join(reports_dir, "id-report.json")
        with open(id_path, "w", encoding="utf-8") as f:
            json.dump(id_report, f, indent=2)

        # 2. link-report.json
        link_path = os.path.join(reports_dir, "link-report.json")
        with open(link_path, "w", encoding="utf-8") as f:
            json.dump(link_report, f, indent=2)

        # 3. image-report.json
        img_report = {
            "total_images": len(figures),
            "images": [{"id": fig.id, "page": fig.page_num, "alt": fig.alt_text, "caption": fig.caption} for fig in figures]
        }
        img_path = os.path.join(reports_dir, "image-report.json")
        with open(img_path, "w", encoding="utf-8") as f:
            json.dump(img_report, f, indent=2)

        # 4. unresolved-issues.json
        issues_data = [{"page": i.page, "type": i.type, "severity": i.severity, "expected": i.expected, "actual": i.actual, "status": i.status} for i in qa_issues]
        unresolved_path = os.path.join(reports_dir, "unresolved-issues.json")
        with open(unresolved_path, "w", encoding="utf-8") as f:
            json.dump(issues_data, f, indent=2)

        # 5. validation-report.json & html
        val_json_path = os.path.join(reports_dir, "validation-report.json")
        with open(val_json_path, "w", encoding="utf-8") as f:
            json.dump(validation_res, f, indent=2)

        val_html_path = os.path.join(reports_dir, "validation-report.html")
        val_status_str = validation_res.get("status", "EPUBCheck unavailable")
        val_html_content = f"""<!DOCTYPE html>
<html>
<head><title>Validation Report</title><style>body {{ font-family: sans-serif; padding: 20px; }} pre {{ background: #f4f4f4; padding: 10px; }}</style></head>
<body>
<h1>EPUB Validation Report</h1>
<p><strong>Status:</strong> {val_status_str}</p>
<p><strong>Errors:</strong> {validation_res.get('error_count', 0)}</p>
<p><strong>Warnings:</strong> {validation_res.get('warning_count', 0)}</p>
<h3>Console Output</h3>
<pre>{validation_res.get('output', 'No console output available.')}</pre>
</body>
</html>"""
        with open(val_html_path, "w", encoding="utf-8") as f:
            f.write(val_html_content)

        # 6. qa-report.json & html
        qa_json_path = os.path.join(reports_dir, "qa-report.json")
        with open(qa_json_path, "w", encoding="utf-8") as f:
            json.dump(qa_eval, f, indent=2)

        qa_html_path = os.path.join(reports_dir, "qa-report.html")
        gate_rows = "".join([f"<tr><td>{g['name']}</td><td>{g['status']}</td></tr>" for g in qa_eval.get("gates", [])])
        qa_html_content = f"""<!DOCTYPE html>
<html>
<head><title>QA Report</title><style>body {{ font-family: sans-serif; padding: 20px; }} table {{ border-collapse: collapse; width: 100%; }} th, td {{ border: 1px solid #ccc; padding: 8px; }}</style></head>
<body>
<h1>QA Quality Gates Report</h1>
<h2>FINAL STATUS: {qa_eval.get('final_status', 'FAIL')}</h2>
<table>
<tr><th>Quality Gate</th><th>Status</th></tr>
{gate_rows}
</table>
</body>
</html>"""
        with open(qa_html_path, "w", encoding="utf-8") as f:
            f.write(qa_html_content)

        return {
            "id_report": id_path,
            "link_report": link_path,
            "image_report": img_path,
            "unresolved_issues": unresolved_path,
            "validation_report_json": val_json_path,
            "validation_report_html": val_html_path,
            "qa_report_json": qa_json_path,
            "qa_report_html": qa_html_path
        }
