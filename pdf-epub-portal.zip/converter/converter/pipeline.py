import os
import sys
import json
import logging
import traceback
from typing import Dict, Any, List

from converter.models import PageData, PipelineStepResult
from converter.pdf_analyzer import PDFAnalyzer
from converter.pdf_text_extractor import PDFTextExtractor
from converter.ocr_processor import OCRProcessor
from converter.ocr_corrector import OCRCorrector
from converter.page_classifier import PageClassifier
from converter.document_structure_detector import DocumentStructureDetector
from converter.entity_detector import EntityDetector
from converter.figure_processor import FigureProcessor
from converter.table_processor import TableProcessor
from converter.equation_processor import EquationProcessor
from converter.semantic_tagger import SemanticTagger
from converter.id_generator import IDGenerator
from converter.link_resolver import LinkResolver
from converter.xhtml_generator import XHTMLGenerator
from converter.css_generator import CSSGenerator
from converter.nav_generator import NavGenerator
from converter.opf_generator import OPFGenerator
from converter.spell_checker import SpellChecker
from converter.epub_packager import EPUBPackager
from converter.epub_validator import EPUBValidator
from converter.source_comparator import SourceComparator
from converter.qa_engine import QAEngine
from converter.report_generator import ReportGenerator

class ConversionPipeline:
    def __init__(self, project_id: str, config: Dict[str, Any], base_dir: str = "storage"):
        self.project_id = project_id
        self.config = config
        self.pdf_path = config.get("pdf_path")
        self.processing_dir = os.path.join(base_dir, "processing", project_id)
        self.output_dir = os.path.join(base_dir, "output", project_id)
        self.logs_dir = os.path.join(self.output_dir, "logs")
        self.oebps_dir = os.path.join(self.processing_dir, "OEBPS")
        self.images_dir = os.path.join(self.oebps_dir, "images")
        self.styles_dir = os.path.join(self.oebps_dir, "styles")
        
        os.makedirs(self.processing_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.logs_dir, exist_ok=True)
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.styles_dir, exist_ok=True)

        self.logger = logging.getLogger(f"pipeline_{project_id}")
        self.logger.setLevel(logging.INFO)
        fh = logging.FileHandler(os.path.join(self.logs_dir, "pipeline.log"))
        fh.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(fh)

    def emit_progress(self, stage: str, status: str, progress: int, items: int = 0, errors: List[str] = None, warnings: List[str] = None):
        msg = {
            "stage": stage,
            "status": status,
            "progress": progress,
            "items": items,
            "errors": errors or [],
            "warnings": warnings or []
        }
        sys.stdout.write(json.dumps(msg) + "\n")
        sys.stdout.flush()
        self.logger.info(f"Stage {stage} [{status}]: {progress}% - Items: {items}")

    def run(self) -> Dict[str, Any]:
        context: Dict[str, Any] = {}

        stages = [
            ("analyze_pdf", self._stage_analyze_pdf, 5),
            ("extract_text", self._stage_extract_text, 10),
            ("process_ocr", self._stage_process_ocr, 20),
            ("verify_ocr", self._stage_verify_ocr, 25),
            ("detect_structure", self._stage_detect_structure, 35),
            ("process_figures", self._stage_process_figures, 45),
            ("process_tables", self._stage_process_tables, 55),
            ("process_equations", self._stage_process_equations, 65),
            ("generate_semantic_xhtml", self._stage_generate_xhtml, 70),
            ("generate_ids", self._stage_generate_ids, 75),
            ("resolve_links", self._stage_resolve_links, 80),
            ("generate_css_nav_opf", self._stage_generate_meta, 85),
            ("spell_check", self._stage_spell_check, 88),
            ("package_epub", self._stage_package_epub, 90),
            ("validate_epub", self._stage_validate_epub, 93),
            ("compare_source", self._stage_compare_source, 96),
            ("run_qa_generate_reports", self._stage_run_qa, 100)
        ]

        for stage_name, stage_fn, pct in stages:
            self.emit_progress(stage_name, "PROCESSING", pct - 2)
            try:
                stage_result = stage_fn(context)
                context.update(stage_result)
                self.emit_progress(stage_name, "COMPLETED", pct, items=stage_result.get("items_processed", 0))
            except Exception as e:
                err_msg = f"Error in stage {stage_name}: {str(e)}"
                self.logger.error(err_msg + "\n" + traceback.format_exc())
                self.emit_progress(stage_name, "FAILED", pct, errors=[err_msg])
                context["pipeline_status"] = "FAILED"
                return context

        context["pipeline_status"] = "COMPLETED"
        return context

    def _stage_analyze_pdf(self, context: Dict[str, Any]) -> Dict[str, Any]:
        analyzer = PDFAnalyzer(self.pdf_path)
        pages = analyzer.analyze()
        return {"pages": pages, "items_processed": len(pages)}

    def _stage_extract_text(self, context: Dict[str, Any]) -> Dict[str, Any]:
        extractor = PDFTextExtractor()
        pages = extractor.process(context["pages"])
        return {"pages": pages, "items_processed": len(pages)}

    def _stage_process_ocr(self, context: Dict[str, Any]) -> Dict[str, Any]:
        ocr = OCRProcessor(self.pdf_path, lang=self.config.get("ocr_language", "eng"))
        pages = ocr.process(context["pages"])
        ocr_pages_count = sum(1 for p in pages if p.ocr_status in ("processed", "failed"))
        return {"pages": pages, "items_processed": ocr_pages_count}

    def _stage_verify_ocr(self, context: Dict[str, Any]) -> Dict[str, Any]:
        corrector = OCRCorrector()
        res = corrector.process(context["pages"])
        return {"pages": res["pages"], "ocr_corrections": res["corrections"], "items_processed": len(res["corrections"])}

    def _stage_detect_structure(self, context: Dict[str, Any]) -> Dict[str, Any]:
        classifier = PageClassifier()
        pages = classifier.classify(context["pages"])
        
        detector = DocumentStructureDetector()
        struct_res = detector.detect(pages)
        
        entity_detector = EntityDetector()
        entities = entity_detector.detect(pages)

        try:
            with open(os.path.join(self.processing_dir, "document_tree.json"), "w", encoding="utf-8") as f:
                json.dump(struct_res["document_tree"], f, default=str)
        except Exception:
            pass

        return {
            "pages": pages,
            "document_tree": struct_res["document_tree"],
            "entities": entities,
            "items_processed": len(struct_res["document_tree"])
        }

    def _stage_process_figures(self, context: Dict[str, Any]) -> Dict[str, Any]:
        proc = FigureProcessor(self.pdf_path, self.images_dir)
        figures = proc.process(context["pages"])
        return {"figures": figures, "items_processed": len(figures)}

    def _stage_process_tables(self, context: Dict[str, Any]) -> Dict[str, Any]:
        proc = TableProcessor(self.pdf_path)
        tables = proc.process(context["pages"])
        return {"tables": tables, "items_processed": len(tables)}

    def _stage_process_equations(self, context: Dict[str, Any]) -> Dict[str, Any]:
        proc = EquationProcessor()
        equations = proc.process(context["pages"])
        return {"equations": equations, "items_processed": len(equations)}

    def _stage_generate_xhtml(self, context: Dict[str, Any]) -> Dict[str, Any]:
        tagger = SemanticTagger()
        tagged_sections = tagger.tag_document(
            context["document_tree"],
            context["figures"],
            context["tables"],
            context["equations"]
        )

        xhtml_gen = XHTMLGenerator()
        created_files = xhtml_gen.generate(tagged_sections, self.oebps_dir)
        return {"tagged_sections": tagged_sections, "xhtml_files": created_files, "items_processed": len(created_files)}

    def _stage_generate_ids(self, context: Dict[str, Any]) -> Dict[str, Any]:
        gen = IDGenerator()
        res = gen.generate(context["tagged_sections"])
        return {"tagged_sections": res["tagged_sections"], "id_report": res["id_report"], "items_processed": res["id_report"]["total_ids"]}

    def _stage_resolve_links(self, context: Dict[str, Any]) -> Dict[str, Any]:
        resolver = LinkResolver()
        res = resolver.resolve(context["tagged_sections"], context["id_report"])
        return {"tagged_sections": res["tagged_sections"], "link_report": res["link_report"], "items_processed": res["link_report"]["total_links"]}

    def _stage_generate_meta(self, context: Dict[str, Any]) -> Dict[str, Any]:
        css_gen = CSSGenerator()
        css_path = css_gen.generate(self.styles_dir)

        nav_gen = NavGenerator()
        nav_path = nav_gen.generate(context["tagged_sections"], len(context["pages"]), self.oebps_dir)

        opf_gen = OPFGenerator()
        opf_metadata = {"title": "Converted Document", "author": "EPUB Portal"}
        opf_path = opf_gen.generate(opf_metadata, context["tagged_sections"], self.oebps_dir)

        # Re-save XHTML files with final generated IDs and resolved links
        xhtml_gen = XHTMLGenerator()
        created_files = xhtml_gen.generate(context["tagged_sections"], self.oebps_dir)

        return {"css_path": css_path, "nav_path": nav_path, "opf_path": opf_path, "xhtml_files": created_files, "items_processed": 3}

    def _stage_spell_check(self, context: Dict[str, Any]) -> Dict[str, Any]:
        checker = SpellChecker()
        flagged = checker.check(context["tagged_sections"])
        return {"spelling_flags": flagged, "items_processed": len(flagged)}

    def _stage_package_epub(self, context: Dict[str, Any]) -> Dict[str, Any]:
        packager = EPUBPackager()
        output_epub = os.path.join(self.output_dir, "final.epub")
        packager.package(self.processing_dir, output_epub)
        return {"output_epub": output_epub, "items_processed": 1}

    def _stage_validate_epub(self, context: Dict[str, Any]) -> Dict[str, Any]:
        validator = EPUBValidator(self.config.get("epubcheck_path"))
        res = validator.validate(context["output_epub"])
        return {"validation_result": res, "items_processed": 1}

    def _stage_compare_source(self, context: Dict[str, Any]) -> Dict[str, Any]:
        comparator = SourceComparator()
        issues = comparator.compare(context["pages"], context["output_epub"])
        return {"qa_issues": issues, "items_processed": len(issues)}

    def _stage_run_qa(self, context: Dict[str, Any]) -> Dict[str, Any]:
        qa = QAEngine()
        eval_res = qa.evaluate(context)
        
        rep_gen = ReportGenerator()
        reports = rep_gen.generate(self.output_dir, {**context, "qa_eval": eval_res})

        return {"qa_eval": eval_res, "reports": reports, "items_processed": len(reports)}
