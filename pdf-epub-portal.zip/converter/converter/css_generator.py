import os

class CSSGenerator:
    def generate(self, styles_dir: str) -> str:
        os.makedirs(styles_dir, exist_ok=True)
        css_content = """/* EPUB 3 Standard Stylesheet */
@charset "utf-8";

body {
    font-family: serif;
    line-height: 1.5;
    margin: 1em;
    color: #1f2937;
    background-color: #ffffff;
}

h1, h2, h3, h4, h5, h6 {
    font-family: sans-serif;
    line-height: 1.2;
    color: #1d4ed8;
    margin-top: 1.5em;
    margin-bottom: 0.5em;
}

h1 { font-size: 1.8em; border-bottom: 1px solid #e5e7eb; padding-bottom: 0.3em; }
h2 { font-size: 1.4em; }
h3 { font-size: 1.2em; }
h4 { font-size: 1.0em; }

p {
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    text-align: justify;
}

p.noindent { text-indent: 0; }
p.indent { text-indent: 1.5em; }

ul, ol {
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    padding-left: 2em;
}

figure {
    margin: 1.5em 0;
    text-align: center;
}

figure img {
    max-width: 100%;
    height: auto;
    border: 1px solid #e5e7eb;
}

figcaption {
    font-size: 0.9em;
    font-style: italic;
    color: #4b5563;
    margin-top: 0.5em;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 1.5em 0;
}

table, th, td {
    border: 1px solid #d1d5db;
}

th, td {
    padding: 0.5em;
    text-align: left;
}

th {
    background-color: #f3f4f6;
    font-weight: bold;
}

caption {
    font-weight: bold;
    margin-bottom: 0.5em;
}

.equation-container {
    margin: 1.5em 0;
    text-align: center;
    overflow-x: auto;
}

span[epub|type~="pagebreak"] {
    display: none;
}
"""
        css_path = os.path.join(styles_dir, "Styles.css")
        with open(css_path, "w", encoding="utf-8") as f:
            f.write(css_content)
        return css_path
