import re
from typing import List, Dict, Any
from converter.models import PageData, TextBlock

class DocumentStructureDetector:
    def detect(self, pages: List[PageData]) -> Dict[str, Any]:
        # Gather font sizes to rank H1, H2, H3, Body
        all_sizes = []
        for p in pages:
            for b in p.text_blocks:
                if b.block_type not in ("header", "footer", "page_number"):
                    all_sizes.append(b.font_size)

        sorted_sizes = sorted(list(set(all_sizes)), reverse=True)
        h1_size = sorted_sizes[0] if len(sorted_sizes) > 0 else 18.0
        h2_size = sorted_sizes[1] if len(sorted_sizes) > 1 else 14.0
        h3_size = sorted_sizes[2] if len(sorted_sizes) > 2 else 12.0

        document_tree: List[Dict[str, Any]] = []

        for p in pages:
            page_items: List[Dict[str, Any]] = []
            blocks = p.text_blocks
            
            i = 0
            while i < len(blocks):
                b = blocks[i]
                text = b.text.strip()

                if b.block_type in ("header", "footer", "page_number") or not text:
                    i += 1
                    continue

                # Heading detection
                major_match = bool(re.search(
                    r'^(chapter\b|part\b|section\b|appendix\b|preface\b|foreword\b|acknowledgements?\b|contents\b|table\s+of\s+contents\b|executive\s+summary\b|introduction\b|abstract\b|references\b|bibliography\b|index\b|glossary\b|notes\b|about\s+the\s+author\b|title\s+page\b|copyright\b|\d+(\.\d+)*\s+[A-Z])',
                    text,
                    re.IGNORECASE
                ))
                
                is_heading = major_match or b.font_size >= h1_size or (b.is_bold and b.font_size >= h2_size and len(text) < 100)
                if is_heading:
                    if major_match or b.font_size >= h1_size or (b.is_bold and b.font_size >= (h1_size * 0.85) and len(text) < 80):
                        level = 1
                    elif b.font_size >= h2_size:
                        level = 2
                    else:
                        level = 3
                    
                    page_items.append({
                        "type": "heading",
                        "level": level,
                        "text": text,
                        "page": p.page_number
                    })
                    i += 1
                    continue

                # List item detection
                is_list_item = bool(re.match(r'^([\bullet\*\-\+]|\d+\.|\([a-z0-9]+\))\s+', text))
                if is_list_item:
                    page_items.append({
                        "type": "list_item",
                        "text": re.sub(r'^([\bullet\*\-\+]|\d+\.|\([a-z0-9]+\))\s+', '', text),
                        "page": p.page_number
                    })
                    i += 1
                    continue

                # Paragraph line merging and de-hyphenation
                para_lines = [text]
                j = i + 1
                while j < len(blocks):
                    next_b = blocks[j]
                    next_text = next_b.text.strip()
                    if next_b.block_type in ("header", "footer", "page_number") or not next_text:
                        j += 1
                        continue
                    
                    # Stop if next block is a heading or list item
                    if next_b.font_size >= h2_size or re.match(r'^([\bullet\*\-\+]|\d+\.|\([a-z0-9]+\))\s+', next_text):
                        break
                    
                    # De-hyphenate line end if ends with '-'
                    if para_lines[-1].endswith('-'):
                        para_lines[-1] = para_lines[-1][:-1] + next_text
                    else:
                        para_lines.append(next_text)
                    j += 1

                full_para = " ".join(para_lines)
                para_class = "noindent" if len(page_items) == 0 or page_items[-1].get("type") == "heading" else "indent"
                
                page_items.append({
                    "type": "paragraph",
                    "text": full_para,
                    "class": para_class,
                    "page": p.page_number
                })
                i = j

            document_tree.append({
                "page": p.page_number,
                "items": page_items
            })

        return {
            "document_tree": document_tree,
            "h1_size": h1_size,
            "h2_size": h2_size,
            "h3_size": h3_size
        }
