import os
import xml.etree.ElementTree as ET
from typing import List, Dict, Any

class XHTMLGenerator:
    def generate(self, tagged_sections: List[Dict[str, Any]], oebps_dir: str) -> List[str]:
        os.makedirs(oebps_dir, exist_ok=True)
        created_files = []

        for sec in tagged_sections:
            filename = sec.get("file", "Chapter_01.xhtml")
            filepath = os.path.join(oebps_dir, filename)
            sec_type = sec.get("type", "chapter")
            title = sec.get("title", "Document Chapter")

            lines = [
                '<?xml version="1.0" encoding="utf-8"?>',
                '<!DOCTYPE html>',
                '<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xmlns:m="http://www.w3.org/1998/Math/MathML" xml:lang="en" lang="en">',
                '<head>',
                '  <meta charset="utf-8"/>',
                f'  <title>{self._escape(title)}</title>',
                '  <link rel="stylesheet" type="text/css" href="styles/Styles.css"/>',
                '</head>',
                '<body>',
                f'  <section epub:type="{sec_type}">'
            ]

            for elem in sec.get("elements", []):
                tag = elem.get("tag")
                elem_id = f' id="{elem["id"]}"' if "id" in elem else ''
                
                if tag == "span":
                    # Pagebreak span
                    attrs_str = " ".join([f'{k}="{v}"' for k, v in elem.get("attrs", {}).items()])
                    lines.append(f'    <span{elem_id} {attrs_str}> </span>')
                elif tag in ("h1", "h2", "h3", "h4"):
                    lines.append(f'    <{tag}{elem_id}>{self._escape(elem.get("text", ""))}</{tag}>')
                elif tag == "p":
                    p_class = f' class="{elem.get("class", "text")}"'
                    lines.append(f'    <p{elem_id}{p_class}>{self._escape(elem.get("text", ""))}</p>')
                elif tag == "li":
                    lines.append(f'    <ul{elem_id}><li>{self._escape(elem.get("text", ""))}</li></ul>')
                elif tag == "figure":
                    img_src = elem.get("img_src", "")
                    alt = self._escape(elem.get("alt", ""))
                    caption = self._escape(elem.get("caption", ""))
                    lines.append(f'    <figure{elem_id}>')
                    lines.append(f'      <img src="{img_src}" alt="{alt}"/>')
                    if caption:
                        lines.append(f'      <figcaption>{caption}</figcaption>')
                    lines.append('    </figure>')
                elif tag == "table":
                    caption = self._escape(elem.get("caption", ""))
                    rows = elem.get("rows", [])
                    lines.append(f'    <table{elem_id}>')
                    if caption:
                        lines.append(f'      <caption>{caption}</caption>')
                    if rows:
                        # thead for first row
                        lines.append('      <thead>')
                        lines.append('        <tr>' + "".join([f'<th>{self._escape(c)}</th>' for c in rows[0]]) + '</tr>')
                        lines.append('      </thead>')
                        # tbody for remaining rows
                        if len(rows) > 1:
                            lines.append('      <tbody>')
                            for r in rows[1:]:
                                lines.append('        <tr>' + "".join([f'<td>{self._escape(c)}</td>' for c in r]) + '</tr>')
                            lines.append('      </tbody>')
                    lines.append('    </table>')
                elif tag == "equation":
                    mathml = elem.get("mathml", "")
                    lines.append(f'    <div{elem_id} class="equation-container">')
                    lines.append(f'      {mathml}')
                    lines.append('    </div>')

            lines.append('  </section>')
            lines.append('</body>')
            lines.append('</html>')

            content = "\n".join(lines)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)
            
            created_files.append(filename)

        return created_files

    def _escape(self, s: str) -> str:
        if not s:
            return ""
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
