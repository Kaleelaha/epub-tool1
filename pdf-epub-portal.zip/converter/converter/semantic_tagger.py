import re
from typing import List, Dict, Any

class SemanticTagger:
    def _determine_section_info(self, title: str, section_count: int) -> Dict[str, str]:
        t_lower = title.lower()
        if any(k in t_lower for k in ["cover", "title page", "copyright"]):
            return {"title": title or "Cover", "file": "Cover.xhtml", "type": "cover"}
        elif any(k in t_lower for k in ["table of contents", "contents"]):
            return {"title": title or "Table of Contents", "file": "TOC.xhtml", "type": "toc"}
        elif any(k in t_lower for k in ["preface", "foreword", "acknowledgement", "executive summary", "abstract"]):
            safe_name = re.sub(r'[^a-zA-Z0-9]', '_', title).strip('_') or 'Frontmatter'
            return {"title": title, "file": f"{safe_name[:20]}.xhtml", "type": "frontmatter"}
        elif "appendix" in t_lower:
            return {"title": title, "file": f"Appendix_{section_count:02d}.xhtml", "type": "appendix"}
        elif any(k in t_lower for k in ["references", "bibliography"]):
            return {"title": title or "Bibliography", "file": "Bibliography.xhtml", "type": "bibliography"}
        elif "index" in t_lower:
            return {"title": title or "Index", "file": "Index.xhtml", "type": "index"}
        else:
            return {"title": title, "file": f"Chapter_{section_count:02d}.xhtml", "type": "chapter"}

    def tag_document(self, document_tree: List[Dict[str, Any]], figures: List[Any], tables: List[Any], equations: List[Any]) -> List[Dict[str, Any]]:
        tagged_sections: List[Dict[str, Any]] = []
        
        current_section = {
            "title": "Cover",
            "file": "Cover.xhtml",
            "type": "cover",
            "elements": [],
            "start_page": 1,
            "page_count": 0
        }
        tagged_sections.append(current_section)

        major_heading_pattern = re.compile(
            r'^(chapter\b|part\b|section\b|appendix\b|preface\b|foreword\b|acknowledgements?\b|contents\b|table\s+of\s+contents\b|executive\s+summary\b|introduction\b|abstract\b|references\b|bibliography\b|index\b|glossary\b|notes\b|about\s+the\s+author\b|title\s+page\b|copyright\b|\d+(\.\d+)*\s+[A-Z])',
            re.IGNORECASE
        )

        pages_in_current_section = 0

        for page in document_tree:
            page_num = page["page"]
            pages_in_current_section += 1
            current_section["page_count"] = pages_in_current_section
            
            # Insert pagebreak anchor
            pagebreak_elem = {
                "tag": "span",
                "id": f"page_{page_num}",
                "attrs": {
                    "aria-label": f"page {page_num}",
                    "epub:type": "pagebreak",
                    "role": "doc-pagebreak"
                },
                "text": " "
            }

            items = page["items"]
            for idx, item in enumerate(items):
                itype = item.get("type")
                text = item.get("text", "").strip()

                is_major_h = False
                if itype == "heading":
                    level = item.get("level", 1)
                    if level == 1 or major_heading_pattern.search(text):
                        is_major_h = True
                
                # Fallback: if a section exceeds 15 pages without a new chapter, split at next heading/page start
                is_fallback_split = (pages_in_current_section > 15 and idx == 0 and len(items) > 0)

                if is_major_h or is_fallback_split:
                    chap_title = text if (itype == "heading" and text) else f"Section Page {page_num}"
                    sec_info = self._determine_section_info(chap_title, len(tagged_sections))
                    
                    # Avoid creating empty section if current has no real content
                    non_pg_elems = [e for e in current_section["elements"] if e.get("tag") != "span"]
                    if len(non_pg_elems) == 0 and len(tagged_sections) > 1:
                        current_section.update(sec_info)
                        current_section["title"] = chap_title
                    else:
                        current_section = {
                            "title": chap_title,
                            "file": sec_info["file"],
                            "type": sec_info["type"],
                            "elements": [],
                            "start_page": page_num,
                            "page_count": 1
                        }
                        tagged_sections.append(current_section)
                        pages_in_current_section = 1

                # Add pagebreak to current section if not present
                if pagebreak_elem not in current_section["elements"]:
                    current_section["elements"].append(pagebreak_elem)

                if itype == "heading":
                    level = item.get("level", 1)
                    current_section["elements"].append({
                        "tag": f"h{level}",
                        "text": text,
                        "page": page_num
                    })
                elif itype == "list_item":
                    current_section["elements"].append({
                        "tag": "li",
                        "text": text,
                        "page": page_num
                    })
                elif itype == "paragraph":
                    current_section["elements"].append({
                        "tag": "p",
                        "class": item.get("class", "text"),
                        "text": text,
                        "page": page_num
                    })

            # Append page figures
            page_figs = [f for f in figures if getattr(f, "page_num", 0) == page_num]
            for fig in page_figs:
                current_section["elements"].append({
                    "tag": "figure",
                    "id": getattr(fig, "id", f"fig_{page_num}"),
                    "img_src": f"images/image_{getattr(fig, 'id', f'fig_{page_num}').replace('.', '_')}.{getattr(fig, 'format', 'png')}",
                    "alt": getattr(fig, "alt_text", ""),
                    "caption": getattr(fig, "caption", ""),
                    "page": page_num
                })

            # Append page tables
            page_tbls = [t for t in tables if getattr(t, "page_num", 0) == page_num]
            for tbl in page_tbls:
                current_section["elements"].append({
                    "tag": "table",
                    "id": getattr(tbl, "id", f"tbl_{page_num}"),
                    "caption": getattr(tbl, "caption", ""),
                    "rows": getattr(tbl, "rows", []),
                    "reconstruction": getattr(tbl, "reconstruction", ""),
                    "page": page_num
                })

            # Append page equations
            page_eqs = [e for e in equations if getattr(e, "page_num", 0) == page_num]
            for eq in page_eqs:
                current_section["elements"].append({
                    "tag": "equation",
                    "id": getattr(eq, "id", f"eq_{page_num}"),
                    "mathml": getattr(eq, "mathml", ""),
                    "text": getattr(eq, "text", ""),
                    "page": page_num
                })

        # Ensure all filenames in tagged_sections are unique
        used_files = set()
        for idx, sec in enumerate(tagged_sections):
            f = sec.get("file", f"Chapter_{idx:02d}.xhtml")
            if f in used_files:
                base, ext = os.path.splitext(f)
                f = f"{base}_{idx:02d}{ext}"
                sec["file"] = f
            used_files.add(f)

        return tagged_sections
