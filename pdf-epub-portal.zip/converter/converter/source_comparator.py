import re
import zipfile
from typing import List, Dict, Any
from converter.models import PageData, QAIssue

class SourceComparator:
    def compare(self, pages: List[PageData], epub_path: str) -> List[QAIssue]:
        issues: List[QAIssue] = []

        # Read text content from XHTML files inside EPUB zip
        epub_text_by_page: Dict[int, str] = {}
        try:
            with zipfile.ZipFile(epub_path, "r") as zf:
                xhtml_files = [f for f in zf.namelist() if f.endswith(".xhtml")]
                for xf in xhtml_files:
                    content = zf.read(xf).decode("utf-8")
                    # Extract pagebreak markers like id="page_N"
                    page_matches = re.finditer(r'id="page_(\d+)"', content)
                    for m in page_matches:
                        p_num = int(m.group(1))
                        epub_text_by_page[p_num] = content
        except Exception as e:
            issues.append(QAIssue(
                page=1,
                type="EPUB_READ_ERROR",
                severity="CRITICAL",
                expected="Readable EPUB package",
                actual=str(e),
                status="UNRESOLVED"
            ))
            return issues

        for page in pages:
            p_num = page.page_number
            pdf_raw = page.raw_text.strip()
            
            # Check pagebreak existence in EPUB
            if p_num not in epub_text_by_page and len(pdf_raw) > 0:
                issues.append(QAIssue(
                    page=p_num,
                    type="MISSING_PAGEBREAK",
                    severity="WARNING",
                    expected=f"Pagebreak marker for page {p_num}",
                    actual="No pagebreak marker found in EPUB XHTML",
                    status="UNRESOLVED"
                ))

            # Check text word count comparison
            pdf_words = len(re.findall(r'\w+', pdf_raw))
            epub_content = epub_text_by_page.get(p_num, "")
            # strip html tags for text comparison
            epub_plain = re.sub(r'<[^>]+>', ' ', epub_content)
            epub_words = len(re.findall(r'\w+', epub_plain))

            if pdf_words > 0 and (abs(pdf_words - epub_words) / float(pdf_words)) > 0.40:
                issues.append(QAIssue(
                    page=p_num,
                    type="TEXT_DISCREPANCY",
                    severity="WARNING",
                    expected=f"~{pdf_words} words from PDF text layer",
                    actual=f"{epub_words} words found in EPUB",
                    status="UNRESOLVED"
                ))

        return issues
