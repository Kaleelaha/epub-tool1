from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

@dataclass
class TextBlock:
    text: str
    bbox: List[float] # [x0, y0, x1, y1]
    font_size: float
    font_name: str
    is_bold: bool = False
    is_italic: bool = False
    block_type: str = "paragraph" # heading, paragraph, list_item, caption, header, footer, page_number, equation

@dataclass
class ExtractedImage:
    id: str
    page_num: int
    bbox: List[float]
    image_bytes: bytes
    format: str # png, jpeg
    width: int
    height: int
    caption: str = ""
    alt_text: str = ""

@dataclass
class ExtractedTable:
    id: str
    page_num: int
    bbox: List[float]
    rows: List[List[str]] # 2D array of cell texts
    caption: str = ""
    reconstruction: str = "table" # "table" or "image"

@dataclass
class ExtractedEquation:
    id: str
    page_num: int
    text: str
    eq_type: str = "inline" # "inline", "block", "chemical"
    mathml: str = ""

@dataclass
class PageData:
    page_number: int
    width: float
    height: float
    text_blocks: List[TextBlock] = field(default_factory=list)
    raw_text: str = ""
    quality_score: float = 1.0
    ocr_required: bool = False
    ocr_status: str = "skipped" # skipped, processed, failed, unavailable
    column_count: int = 1
    heading_count: int = 0
    paragraph_count: int = 0
    list_item_count: int = 0
    image_count: int = 0
    table_count: int = 0
    equation_count: int = 0

@dataclass
class PipelineStepResult:
    stage: str
    status: str # COMPLETED, WARNING, FAILED
    progress: int # 0 to 100
    items: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

@dataclass
class QAIssue:
    page: int
    type: str
    severity: str # CRITICAL, WARNING, INFO
    expected: str
    actual: str
    status: str = "UNRESOLVED"
