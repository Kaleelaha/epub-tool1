import os
import zipfile

class EPUBPackager:
    def package(self, root_dir: str, output_epub_path: str) -> str:
        os.makedirs(os.path.dirname(output_epub_path), exist_ok=True)
        
        # 1. Create META-INF/container.xml inside root_dir if missing
        meta_inf_dir = os.path.join(root_dir, "META-INF")
        os.makedirs(meta_inf_dir, exist_ok=True)
        container_xml_path = os.path.join(meta_inf_dir, "container.xml")
        
        container_content = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>
"""
        with open(container_xml_path, "w", encoding="utf-8") as f:
            f.write(container_content)

        # 2. Build ZIP package with mimetype first uncompressed
        with zipfile.ZipFile(output_epub_path, "w") as zf:
            # Write mimetype uncompressed
            zf.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)

            # Write all other files with ZIP_DEFLATED
            for root, _, files in os.walk(root_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, root_dir).replace("\\", "/")
                    if rel_path == "mimetype":
                        continue
                    zf.write(full_path, rel_path, compress_type=zipfile.ZIP_DEFLATED)

        return output_epub_path
