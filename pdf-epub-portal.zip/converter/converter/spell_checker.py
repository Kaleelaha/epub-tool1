import re
from typing import List, Dict, Any
from spellchecker import SpellChecker as PySpellChecker

class SpellChecker:
    def __init__(self):
        try:
            self.checker = PySpellChecker()
        except Exception:
            self.checker = None

    def check(self, tagged_sections: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        flagged_words: List[Dict[str, Any]] = []
        if not self.checker:
            return flagged_words

        for sec in tagged_sections:
            f = sec.get("file", "")
            for elem in sec.get("elements", []):
                text = elem.get("text", "")
                if not text:
                    continue

                words = [w.strip() for w in re.split(r'\s+', text) if w.strip()]
                for word in words:
                    cleaned = re.sub(r'[^a-zA-Z]', '', word)
                    # Ignore acronyms, numbers, chemicals, short words
                    if not cleaned or len(cleaned) < 4 or cleaned.isupper() or any(c.isdigit() for c in word):
                        continue
                    
                    if cleaned.lower() in self.checker:
                        continue

                    # Flag unknown word without mutating original text
                    flagged_words.append({
                        "file": f,
                        "word": word,
                        "suggestions": list(self.checker.candidates(cleaned.lower()) or [])[:3],
                        "status": "flagged"
                    })

        return flagged_words
