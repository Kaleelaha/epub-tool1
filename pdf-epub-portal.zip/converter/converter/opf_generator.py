import os
import glob
from typing import List, Dict, Any

class OPFGenerator:
    def generate(self, metadata: Dict[str, str], tagged_sections: List[Dict[str, Any]], oebps_dir: str) -> str:
        opf_path = os.path.join(oebps_dir, "content.opf")

        title = metadata.get("title", "EPUB 3 Converted Document")
        author = metadata.get("author", "Unknown Author")
        identifier = metadata.get("identifier", "urn:uuid:12345678-1234-5678-1234-567812345678")
        language = metadata.get("language", "en")

        manifest_items = [
            '    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>',
            '    <item id="css" href="styles/Styles.css" media-type="text/css"/>'
        ]

        spine_items = []

        for idx, sec in enumerate(tagged_sections):
            f = sec.get("file", "")
            item_id = f"xhtml_{idx+1:02d}"
            
            # Check if MathML is used
            has_mathml = any(e.get("tag") == "equation" for e in sec.get("elements", []))
            prop_str = ' properties="mathml"' if has_mathml else ''
            
            manifest_items.append(f'    <item id="{item_id}" href="{f}" media-type="application/xhtml+xml"{prop_str}/>')
            spine_items.append(f'    <itemref idref="{item_id}"/>')

        # Scan images directory
        img_dir = os.path.join(oebps_dir, "images")
        if os.path.exists(img_dir):
            for img_path in glob.glob(os.path.join(img_dir, "*.*")):
                img_name = os.path.basename(img_path)
                ext = img_name.split(".")[-1].lower()
                m_type = "image/png" if ext == "png" else "image/jpeg"
                img_id = f"img_{img_name.replace('.', '_')}"
                prop_str = ' properties="cover-image"' if "cover" in img_name.lower() or img_id == "img_image_f1_1_png" else ''
                manifest_items.append(f'    <item id="{img_id}" href="images/{img_name}" media-type="{m_type}"{prop_str}/>')

        opf_content = f"""<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="pub-id">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="pub-id">{identifier}</dc:identifier>
    <dc:title>{self._escape(title)}</dc:title>
    <dc:language>{language}</dc:language>
    <dc:creator>{self._escape(author)}</dc:creator>
    <meta property="dcterms:modified">2026-09-29T00:00:00Z</meta>
  </metadata>

  <manifest>
{chr(10).join(manifest_items)}
  </manifest>

  <spine>
{chr(10).join(spine_items)}
  </spine>
</package>
"""
        with open(opf_path, "w", encoding="utf-8") as f:
            f.write(opf_content)
        return opf_path

    def _escape(self, s: str) -> str:
        if not s:
            return ""
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
