import argparse
import json
import os
import sys
from converter.pipeline import ConversionPipeline

def main():
    parser = argparse.ArgumentParser(description="PDF to EPUB 3 Converter CLI")
    parser.add_argument("--project", required=True, help="Project ID")
    parser.add_argument("--config", required=True, help="Config JSON string or file path")
    args = parser.parse_args()

    config_data = {}
    if os.path.exists(args.config):
        with open(args.config, "r", encoding="utf-8") as f:
            config_data = json.load(f)
    else:
        try:
            config_data = json.loads(args.config)
        except Exception:
            sys.stderr.write("Invalid JSON config provided.\n")
            sys.exit(1)

    pipeline = ConversionPipeline(args.project, config_data)
    result = pipeline.run()

    if result.get("pipeline_status") == "FAILED":
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
