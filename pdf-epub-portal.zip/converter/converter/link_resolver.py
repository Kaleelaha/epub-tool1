import re
from typing import List, Dict, Any

class LinkResolver:
    def resolve(self, tagged_sections: List[Dict[str, Any]], id_report: Dict[str, Any]) -> Dict[str, Any]:
        all_ids = set(id_report.get("all_ids", []))
        
        # Build map of id -> file containing that id
        id_to_file: Dict[str, str] = {}
        for sec in tagged_sections:
            f = sec.get("file", "")
            if "id" in sec:
                id_to_file[sec["id"]] = f
            for elem in sec.get("elements", []):
                if "id" in elem:
                    id_to_file[elem["id"]] = f

        resolved_links = []
        broken_links = []

        for sec in tagged_sections:
            current_file = sec.get("file", "")

            for elem in sec.get("elements", []):
                text = elem.get("text", "")
                if not text or elem.get("tag") in ("span", "figure", "table", "equation"):
                    continue

                # Pattern match references: "Section 2.1", "Figure 1.1", "Table 2.1", "Equation 2.1", "page 2"
                patterns = [
                    (r'\b(Section\s+(\d+\.\d+))\b', 'sec', lambda m: f"sec{m.group(2).replace('.', '-')}"),
                    (r'\b(Figure\s+(\d+\.\d+))\b', 'fig', lambda m: f"f{m.group(2)}"),
                    (r'\b(Table\s+(\d+\.\d+))\b', 'tbl', lambda m: f"t{m.group(2)}"),
                    (r'\b(Equation\s+(\d+\.\d+))\b', 'eq', lambda m: f"eq{m.group(2)}"),
                    (r'\b(page\s+(\d+))\b', 'pg', lambda m: f"page_{m.group(2)}")
                ]

                new_text = text
                for pat, ref_type, id_builder in patterns:
                    matches = list(re.finditer(pat, new_text, re.IGNORECASE))
                    for m in matches:
                        full_match = m.group(1)
                        target_id = id_builder(m)

                        if target_id in all_ids:
                            target_file = id_to_file.get(target_id, "")
                            if target_file == current_file:
                                href = f"#{target_id}"
                            else:
                                href = f"{target_file}#{target_id}"

                            link_html = f'<a href="{href}">{full_match}</a>'
                            new_text = new_text.replace(full_match, link_html)
                            resolved_links.append({
                                "source_file": current_file,
                                "target_id": target_id,
                                "href": href,
                                "status": "resolved"
                            })
                        else:
                            broken_links.append({
                                "source_file": current_file,
                                "text": full_match,
                                "target_id": target_id,
                                "status": "broken"
                            })

                elem["text"] = new_text

        report = {
            "total_links": len(resolved_links) + len(broken_links),
            "resolved_count": len(resolved_links),
            "broken_count": len(broken_links),
            "resolved_links": resolved_links,
            "broken_links": broken_links
        }

        return {
            "tagged_sections": tagged_sections,
            "link_report": report
        }
