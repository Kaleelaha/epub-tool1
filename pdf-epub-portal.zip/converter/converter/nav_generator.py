import os
from typing import List, Dict, Any

class NavGenerator:
    def generate(self, tagged_sections: List[Dict[str, Any]], page_count: int, oebps_dir: str) -> str:
        nav_path = os.path.join(oebps_dir, "nav.xhtml")
        
        toc_items = []
        for sec in tagged_sections:
            f = sec.get("file", "")
            title = sec.get("title", "Chapter")
            sec_id = sec.get("id", "")
            href = f"{f}#{sec_id}" if sec_id else f
            toc_items.append(f'        <li><a href="{href}">{self._escape(title)}</a></li>')

        page_list_items = []
        for p in range(1, page_count + 1):
            # Map page number to target file
            target_file = tagged_sections[0].get("file", "Cover.xhtml")
            for sec in tagged_sections:
                for elem in sec.get("elements", []):
                    if elem.get("tag") == "span" and elem.get("id") == f"page_{p}":
                        target_file = sec.get("file", target_file)
                        break

            page_list_items.append(f'        <li><a href="{target_file}#page_{p}">{p}</a></li>')

        nav_content = f"""<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="en" lang="en">
<head>
  <meta charset="utf-8"/>
  <title>Navigation</title>
  <link rel="stylesheet" type="text/css" href="styles/Styles.css"/>
</head>
<body>
  <nav epub:type="toc" id="toc">
    <h1>Table of Contents</h1>
    <ol>
{chr(10).join(toc_items)}
    </ol>
  </nav>

  <nav epub:type="landmarks" id="landmarks">
    <h2>Landmarks</h2>
    <ol>
      <li><a epub:type="toc" href="#toc">Table of Contents</a></li>
      <li><a epub:type="bodymatter" href="{tagged_sections[0].get('file', 'Cover.xhtml')}">Begin Reading</a></li>
    </ol>
  </nav>

  <nav epub:type="page-list" id="page-list" hidden="hidden">
    <h2>Page List</h2>
    <ol>
{chr(10).join(page_list_items)}
    </ol>
  </nav>
</body>
</html>
"""
        with open(nav_path, "w", encoding="utf-8") as f:
            f.write(nav_content)
        return nav_path

    def _escape(self, s: str) -> str:
        if not s:
            return ""
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
