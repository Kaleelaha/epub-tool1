import os
import pymupdf as fitz
import pdfplumber
from typing import List, Dict, Any
from converter.models import PageData, TextBlock

class PDFAnalyzer:
    def __init__(self, pdf_path: str):
        self.pdf_path = pdf_path

    def analyze(self) -> List[PageData]:
        doc = fitz.open(self.pdf_path)
        pages_data: List[PageData] = []
        
        plumber_doc = None
        try:
            plumber_doc = pdfplumber.open(self.pdf_path)
        except Exception:
            plumber_doc = None

        total_pages = len(doc)
        
        # Header/footer frequency detection across pages
        header_footer_candidates: Dict[str, int] = {}
        for page_num in range(total_pages):
            page = doc[page_num]
            text = page.get_text("text").splitlines()
            if text:
                top_line = text[0].strip()
                bot_line = text[-1].strip()
                if top_line:
                    header_footer_candidates[top_line] = header_footer_candidates.get(top_line, 0) + 1
                if bot_line:
                    header_footer_candidates[bot_line] = header_footer_candidates.get(bot_line, 0) + 1

        for i, page in enumerate(doc):
            page_num = i + 1
            rect = page.rect
            width, height = rect.width, rect.height
            
            blocks = page.get_text("dict").get("blocks", [])
            text_blocks: List[TextBlock] = []
            
            for b in blocks:
                if b.get("type") == 0: # text block
                    for line in b.get("lines", []):
                        for span in line.get("spans", []):
                            text = span.get("text", "").strip()
                            if not text:
                                continue
                            font_size = round(span.get("size", 10.0), 1)
                            font_name = span.get("font", "helv")
                            flags = span.get("flags", 0)
                            is_bold = bool(flags & 2) or ("bold" in font_name.lower())
                            is_italic = bool(flags & 1) or ("oblique" in font_name.lower() or "italic" in font_name.lower())
                            bbox = list(span.get("bbox", [0, 0, 0, 0]))
                            
                            # Determine block type
                            block_type = "paragraph"
                            # Top/bottom header/footer check
                            if (bbox[1] < 50 or bbox[3] > height - 50) and header_footer_candidates.get(text, 0) > 1:
                                block_type = "header" if bbox[1] < 50 else "footer"
                            elif text.isdigit() and (bbox[1] < 50 or bbox[3] > height - 50):
                                block_type = "page_number"
                            
                            text_blocks.append(TextBlock(
                                text=text,
                                bbox=bbox,
                                font_size=font_size,
                                font_name=font_name,
                                is_bold=is_bold,
                                is_italic=is_italic,
                                block_type=block_type
                            ))
            
            # Sort text_blocks in top-to-bottom, left-to-right reading order
            # (Sort by top y coordinate clustered into lines ~5pt threshold, then x coordinate)
            text_blocks.sort(key=lambda b: (round(b.bbox[1] / 8.0) * 8.0, b.bbox[0]))
            
            # Estimate column count
            x0_positions = [b.bbox[0] for b in text_blocks if b.block_type == "paragraph"]
            col_count = 1
            if len(x0_positions) > 5:
                # check if there are distinct x0 clusters (e.g. > 150pt apart)
                left_col = [x for x in x0_positions if x < width / 2.0]
                right_col = [x for x in x0_positions if x >= width / 2.0]
                if len(left_col) > 3 and len(right_col) > 3:
                    col_count = 2

            # Plumber tables count
            table_count = 0
            if plumber_doc and i < len(plumber_doc.pages):
                try:
                    tables = plumber_doc.pages[i].find_tables()
                    table_count = len(tables)
                except Exception:
                    table_count = 0

            # Images count
            images = page.get_images()
            image_count = len(images)
            
            raw_text = "\n".join([b.text for b in text_blocks if b.block_type not in ("header", "footer")])

            pages_data.append(PageData(
                page_number=page_num,
                width=width,
                height=height,
                text_blocks=text_blocks,
                raw_text=raw_text,
                column_count=col_count,
                image_count=image_count,
                table_count=table_count
            ))

        if plumber_doc:
            plumber_doc.close()
        doc.close()
        return pages_data
