import os
import re
import pdfplumber
from typing import List, Dict, Any
from converter.models import PageData, ExtractedTable

class TableProcessor:
    def __init__(self, pdf_path: str):
        self.pdf_path = pdf_path

    def process(self, pages: List[PageData]) -> List[ExtractedTable]:
        tables: List[ExtractedTable] = []
        
        try:
            with pdfplumber.open(self.pdf_path) as pdf:
                for page_data in pages:
                    p_idx = page_data.page_number - 1
                    if p_idx >= len(pdf.pages):
                        continue
                    
                    plumber_page = pdf.pages[p_idx]
                    extracted_tables = plumber_page.extract_tables()
                    
                    # Detect table caption on page
                    caption = ""
                    for b in page_data.text_blocks:
                        m = re.search(r'(Table\s+\d+(\.\d+)?)[\:\.\s]*(.*)', b.text, re.IGNORECASE)
                        if m:
                            caption = b.text.strip()
                            break

                    for t_idx, raw_table in enumerate(extracted_tables):
                        if not raw_table or len(raw_table) < 2:
                            continue
                        
                        # Clean cells
                        cleaned_rows = []
                        for row in raw_table:
                            cleaned_row = [str(cell).strip() if cell is not None else "" for cell in row]
                            cleaned_rows.append(cleaned_row)

                        # Check consistency of column count
                        col_counts = [len(r) for r in cleaned_rows]
                        is_consistent = len(set(col_counts)) == 1 and col_counts[0] > 1

                        table_id = f"t{page_data.page_number}.{t_idx + 1}"
                        reconstruction = "table" if is_consistent else "image"

                        tables.append(ExtractedTable(
                            id=table_id,
                            page_num=page_data.page_number,
                            bbox=[72, 100, 520, 300],
                            rows=cleaned_rows,
                            caption=caption if caption else f"Table {page_data.page_number}.{t_idx + 1}",
                            reconstruction=reconstruction
                        ))
        except Exception:
            pass

        return tables
