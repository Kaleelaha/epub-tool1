import re
from typing import List, Dict, Any
from converter.models import PageData

class EntityDetector:
    def detect(self, pages: List[PageData]) -> List[Dict[str, Any]]:
        entities: List[Dict[str, Any]] = []

        for p in pages:
            for b in p.text_blocks:
                t = b.text.strip()
                # Chapter match
                m_chap = re.match(r'^(Chapter\s+(\d+|[IVXLCDM]+))[\:\.\s]*(.*)', t, re.IGNORECASE)
                if m_chap:
                    entities.append({
                        "type": "chapter",
                        "id": f"chap{m_chap.group(2).zfill(2)}",
                        "title": t,
                        "page": p.page_number
                    })
                
                # Section match (e.g. 1.1 or 2.1)
                m_sec = re.match(r'^(\d+\.\d+)\s+(.*)', t)
                if m_sec:
                    sec_num = m_sec.group(1).replace('.', '-')
                    entities.append({
                        "type": "section",
                        "id": f"sec{sec_num}",
                        "title": t,
                        "page": p.page_number
                    })

                # Footnote match
                m_fn = re.match(r'^\[?(\d+)\]?\s+(.*)', t)
                if m_fn and (b.bbox[1] > p.height - 150 or b.font_size < 9.5):
                    entities.append({
                        "type": "footnote",
                        "id": f"fn{m_fn.group(1)}",
                        "text": t,
                        "page": p.page_number
                    })

        return entities
