import os
import shutil
import subprocess
import json
import re
from typing import Dict, Any

class EPUBValidator:
    def __init__(self, epubcheck_path: str = None):
        self.epubcheck_path = epubcheck_path or os.environ.get("EPUBCHECK_PATH")

    def validate(self, epub_path: str) -> Dict[str, Any]:
        java_bin = shutil.which("java")
        
        # Check if EPUBCheck jar and Java exist
        if not (self.epubcheck_path and os.path.exists(self.epubcheck_path) and java_bin):
            return {
                "executed": False,
                "status": "EPUBCheck unavailable",
                "errors": [],
                "warnings": [],
                "error_count": 1,
                "warning_count": 0,
                "output": "EPUBCheck jar or Java runtime not found on system."
            }

        try:
            # Run EPUBCheck with JSON output flag if supported or standard CLI
            cmd = [java_bin, "-jar", self.epubcheck_path, epub_path]
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            
            output = res.stdout + res.stderr
            errors = re.findall(r"^ERROR.*", output, re.MULTILINE)
            warnings = re.findall(r"^WARNING.*", output, re.MULTILINE)

            return {
                "executed": True,
                "status": "COMPLETED" if len(errors) == 0 else "FAILED",
                "errors": errors,
                "warnings": warnings,
                "error_count": len(errors),
                "warning_count": len(warnings),
                "output": output
            }
        except Exception as e:
            return {
                "executed": False,
                "status": "EPUBCheck unavailable",
                "errors": [str(e)],
                "warnings": [],
                "error_count": 1,
                "warning_count": 0,
                "output": f"Execution error: {str(e)}"
            }
