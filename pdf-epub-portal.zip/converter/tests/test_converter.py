import os
import shutil
import pytest
from converter.pdf_analyzer import PDFAnalyzer
from converter.pdf_text_extractor import PDFTextExtractor
from converter.ocr_processor import OCRProcessor
from converter.document_structure_detector import DocumentStructureDetector
from converter.id_generator import IDGenerator
from converter.link_resolver import LinkResolver
from converter.xhtml_generator import XHTMLGenerator
from converter.nav_generator import NavGenerator
from converter.opf_generator import OPFGenerator
from converter.epub_packager import EPUBPackager
from converter.epub_validator import EPUBValidator
from converter.qa_engine import QAEngine

SAMPLE_A_PATH = "samples/sample_a.pdf"
SAMPLE_B_PATH = "samples/sample_b.pdf"

def test_pdf_analysis():
    analyzer = PDFAnalyzer(SAMPLE_A_PATH)
    pages = analyzer.analyze()
    assert len(pages) == 3
    assert pages[0].page_number == 1

def test_text_extraction_and_ocr_routing():
    analyzer = PDFAnalyzer(SAMPLE_A_PATH)
    pages = analyzer.analyze()
    
    extractor = PDFTextExtractor()
    processed_pages = extractor.process(pages)
    
    # Born digital pages must not require OCR
    assert not processed_pages[0].ocr_required
    assert processed_pages[0].quality_score > 0.6

    # Test sample B (image-only page)
    analyzer_b = PDFAnalyzer(SAMPLE_B_PATH)
    pages_b = analyzer_b.analyze()
    processed_b = extractor.process(pages_b)
    assert processed_b[0].ocr_required

def test_id_generation_and_duplicates():
    tagged_sections = [
        {
            "type": "chapter",
            "file": "Chapter_01.xhtml",
            "elements": [
                {"tag": "h1", "text": "Section 1.1 Introduction"},
                {"tag": "p", "text": "Paragraph text"}
            ]
        }
    ]
    gen = IDGenerator()
    res = gen.generate(tagged_sections)
    assert res["id_report"]["duplicate_count"] == 0
    assert "sec1-1" in res["id_report"]["all_ids"]

def test_link_resolution():
    tagged_sections = [
        {
            "type": "chapter",
            "file": "Chapter_01.xhtml",
            "id": "chap01",
            "elements": [
                {"tag": "h1", "id": "sec1-1", "text": "1.1 Introduction"},
                {"tag": "p", "text": "See Section 1.1 for more details."}
            ]
        }
    ]
    id_report = {"all_ids": ["chap01", "sec1-1"]}
    resolver = LinkResolver()
    res = resolver.resolve(tagged_sections, id_report)
    assert res["link_report"]["broken_count"] == 0
    assert res["link_report"]["resolved_count"] == 1

def test_xhtml_nav_opf_packaging(tmp_path):
    oebps_dir = str(tmp_path / "OEBPS")
    output_epub = str(tmp_path / "test.epub")

    tagged_sections = [
        {
            "type": "chapter",
            "file": "Chapter_01.xhtml",
            "title": "Chapter 1",
            "elements": [
                {"tag": "h1", "text": "Chapter 1"},
                {"tag": "p", "text": "Test body content."}
            ]
        }
    ]

    xhtml_gen = XHTMLGenerator()
    xhtml_files = xhtml_gen.generate(tagged_sections, oebps_dir)
    assert len(xhtml_files) == 1

    nav_gen = NavGenerator()
    nav_path = nav_gen.generate(tagged_sections, 1, oebps_dir)
    assert os.path.exists(nav_path)

    opf_gen = OPFGenerator()
    opf_path = opf_gen.generate({"title": "Test Title"}, tagged_sections, oebps_dir)
    assert os.path.exists(opf_path)

    packager = EPUBPackager()
    packaged_path = packager.package(str(tmp_path), output_epub)
    assert os.path.exists(packaged_path)

def test_epubcheck_validator_graceful_degradation():
    validator = EPUBValidator(epubcheck_path="non_existent_epubcheck.jar")
    res = validator.validate("dummy.epub")
    assert not res["executed"]
    assert res["status"] == "EPUBCheck unavailable"

def test_qa_engine_evaluation():
    qa = QAEngine()
    context = {
        "id_report": {"duplicate_count": 0},
        "link_report": {"broken_count": 0},
        "validation_result": {"executed": False, "status": "EPUBCheck unavailable", "error_count": 1},
        "qa_issues": []
    }
    eval_res = qa.evaluate(context)
    assert eval_res["final_status"] == "FAIL"
