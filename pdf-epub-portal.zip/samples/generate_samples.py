import os
import pymupdf as fitz # PyMuPDF

def generate_sample_a(output_path: str):
    """Generate a born-digital PDF with title page, 2 chapters, headings, paragraphs, list, figure, table, equation, cross-refs, and metadata."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    doc = fitz.open()
    
    # Metadata
    doc.set_metadata({
        "title": "Comprehensive EPUB 3 Test Document",
        "author": "Department of Digital Standards",
        "subject": "PDF to EPUB 3 Conversion Benchmark",
        "keywords": "EPUB3, Conversion, Accessibility, Sample"
    })
    
    # Page 1: Cover & Title Page
    page1 = doc.new_page(width=595, height=842) # A4
    page1.insert_text(fitz.Point(72, 100), "Comprehensive EPUB 3 Test Document", fontsize=24, fontname="helv", color=(0.1, 0.2, 0.6))
    page1.insert_text(fitz.Point(72, 140), "Standard Guidelines & Specifications", fontsize=16, fontname="helv", color=(0.3, 0.3, 0.3))
    page1.insert_text(fitz.Point(72, 200), "Author: Department of Digital Standards", fontsize=12, fontname="helv")
    page1.insert_text(fitz.Point(72, 220), "Date: 2026-09-29", fontsize=12, fontname="helv")
    page1.insert_text(fitz.Point(72, 750), "Copyright (c) 2026 Digital Publishing Division. All rights reserved.", fontsize=10, fontname="helv")
    
    # Page 2: Chapter 1 - Introduction
    page2 = doc.new_page(width=595, height=842)
    page2.insert_text(fitz.Point(72, 72), "Chapter 1: Introduction to Standard EPUB Conversion", fontsize=18, fontname="helv", color=(0.1, 0.2, 0.6))
    
    text_p1 = "Electronic Publication (EPUB) 3 is the standard format for digital books. This document provides sample content including formatted text, lists, figures, tables, and mathematical formulas for testing automated conversion algorithms."
    rect_p1 = fitz.Rect(72, 100, 523, 160)
    page2.insert_textbox(rect_p1, text_p1, fontsize=11, fontname="helv")
    
    page2.insert_text(fitz.Point(72, 180), "1.1 Primary Objectives", fontsize=14, fontname="helv", color=(0.2, 0.2, 0.2))
    text_p2 = "The main goal of EPUB 3 conversion is to preserve semantic structure rather than visual representation. See Section 2.1 for structural details."
    rect_p2 = fitz.Rect(72, 200, 523, 240)
    page2.insert_textbox(rect_p2, text_p2, fontsize=11, fontname="helv")
    
    # Bullet List
    page2.insert_text(fitz.Point(72, 260), "Key Requirements:", fontsize=11, fontname="helv")
    page2.insert_text(fitz.Point(90, 280), "* Semantic HTML5 tagging for headings and sections", fontsize=11, fontname="helv")
    page2.insert_text(fitz.Point(90, 300), "* Accessible figure descriptions and visual alt text", fontsize=11, fontname="helv")
    page2.insert_text(fitz.Point(90, 320), "* Structured tables with header cells and caption alignment", fontsize=11, fontname="helv")
    page2.insert_text(fitz.Point(90, 340), "* Valid MathML representation of equations", fontsize=11, fontname="helv")
    
    # Figure simulation (draw a rect with text inside)
    fig_rect = fitz.Rect(72, 380, 523, 500)
    page2.draw_rect(fig_rect, color=(0.2, 0.4, 0.8), fill=(0.9, 0.95, 1.0), width=1.5)
    page2.insert_text(fitz.Point(200, 440), "[ Sample Workflow Diagram ]", fontsize=12, fontname="helv", color=(0.2, 0.4, 0.8))
    page2.insert_text(fitz.Point(72, 515), "Figure 1.1: System Architecture Workflow for PDF to EPUB 3 Pipeline.", fontsize=10, fontname="helv")
    
    # Page 3: Chapter 2 - Technical Specifications
    page3 = doc.new_page(width=595, height=842)
    page3.insert_text(fitz.Point(72, 72), "Chapter 2: Technical Specifications and Formulas", fontsize=18, fontname="helv", color=(0.1, 0.2, 0.6))
    
    page3.insert_text(fitz.Point(72, 105), "2.1 Table Data and Structured Records", fontsize=14, fontname="helv", color=(0.2, 0.2, 0.2))
    page3.insert_text(fitz.Point(72, 125), "The following table summarizes conversion performance metrics across sample documents.", fontsize=11, fontname="helv")
    
    # Draw simple table grid and content
    # Table Header
    page3.draw_rect(fitz.Rect(72, 145, 523, 170), fill=(0.85, 0.9, 0.95), color=(0.5, 0.5, 0.5))
    page3.insert_text(fitz.Point(80, 162), "Stage", fontsize=10, fontname="helv")
    page3.insert_text(fitz.Point(220, 162), "Metric", fontsize=10, fontname="helv")
    page3.insert_text(fitz.Point(360, 162), "Target Value", fontsize=10, fontname="helv")
    
    # Table Rows
    rows = [
        ("Text Extraction", "Character Accuracy", "99.8%"),
        ("OCR Processing", "Word Confidence", "95.0%"),
        ("Link Resolution", "Broken Links", "0"),
        ("ID Generation", "Duplicate IDs", "0")
    ]
    y = 170
    for r in rows:
        page3.draw_rect(fitz.Rect(72, y, 523, y + 25), color=(0.7, 0.7, 0.7))
        page3.insert_text(fitz.Point(80, y + 17), r[0], fontsize=10, fontname="helv")
        page3.insert_text(fitz.Point(220, y + 17), r[1], fontsize=10, fontname="helv")
        page3.insert_text(fitz.Point(360, y + 17), r[2], fontsize=10, fontname="helv")
        y += 25
        
    page3.insert_text(fitz.Point(72, y + 15), "Table 2.1: Key Quality Metrics for Conversion Pipeline.", fontsize=10, fontname="helv")
    
    # Equation section
    y_eq = y + 45
    page3.insert_text(fitz.Point(72, y_eq), "2.2 Mathematical Equations", fontsize=14, fontname="helv", color=(0.2, 0.2, 0.2))
    text_eq_p = "Energy equivalence and chemical compounds such as H2O and CO2 follow standard rules. See Equation 2.1 below:"
    page3.insert_textbox(fitz.Rect(72, y_eq + 15, 523, y_eq + 40), text_eq_p, fontsize=11, fontname="helv")
    
    # Equation block
    page3.insert_text(fitz.Point(200, y_eq + 65), "E = m * c^2", fontsize=14, fontname="helv")
    page3.insert_text(fitz.Point(450, y_eq + 65), "(Equation 2.1)", fontsize=11, fontname="helv")
    
    doc.save(output_path)
    doc.close()
    print(f"Generated Sample A at {output_path}")

def generate_sample_b(output_path: str):
    """Generate a scanned/image-only PDF for testing OCR routing."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    
    # Create an image containing text
    pix = fitz.Pixmap(fitz.csRGB, fitz.Rect(0, 0, 595, 842), False)
    pix.clear_with(255) # white background
    
    # We create a temporary document to render text to an image
    temp_doc = fitz.open()
    tp = temp_doc.new_page(width=595, height=842)
    tp.insert_text(fitz.Point(72, 100), "SCANNED DOCUMENT TEST PAGE", fontsize=20, fontname="helv")
    tp.insert_text(fitz.Point(72, 150), "This page contains no text layer. It requires OCR processing to extract text.", fontsize=12, fontname="helv")
    tp.insert_text(fitz.Point(72, 180), "Sample scanned text: O/0 I/l/1 S/5 confusion verification.", fontsize=12, fontname="helv")
    
    img_pix = tp.get_pixmap(dpi=150)
    page.insert_image(page.rect, pixmap=img_pix)
    
    temp_doc.close()
    doc.save(output_path)
    doc.close()
    print(f"Generated Sample B at {output_path}")

if __name__ == "__main__":
    generate_sample_a("samples/sample_a.pdf")
    generate_sample_b("samples/sample_b.pdf")
