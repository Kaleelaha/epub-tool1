# Architecture & Engineering Decisions

## 1. Environment & Binaries
- **Python Execution:** Using Python 3.13 (`py` launcher on Windows, `python3` on Linux/Docker) to run the `converter` module.
- **OCR Engine (Tesseract):** Tesseract CLI is detected at runtime. If missing, text extraction relies on PyMuPDF/pdfplumber text layer; if OCR is required on image-only pages and Tesseract is missing, OCR processor logs graceful degradation warnings and flags pages with `ocr_status: "unavailable"`.
- **EPUB Validation (EPUBCheck):** EPUBCheck run via Java (`java -jar $EPUBCHECK_PATH`). If EPUBCheck jar is absent or Java invocation fails, the system outputs `"EPUBCheck unavailable"`, marks the EPUBCheck gate as `FAILED` (or `WARNING`/`UNAVAILABLE` as specified), sets final project status to `FAIL` per Rule 1, and continues without throwing unhandled exceptions.

## 2. Document Model & Semantic Mapping
- **Structure Detection:** Uses relative font sizes, font weights, regex patterns for headings (`H1`-`H4`), headers, footers, and page numbers to structure standard EPUB 3 semantic tags (`<section>`, `<h1>`-`<h4>`, `<p>`, `<ul>`, `<ol>`, `<figure>`, `<table>`, `<math>`).
- **Equation & MathML Handling:** Mathematical blocks and inline formulas are detected via character set and structural analysis. Inline formulas convert to semantic HTML with `<sub>` / `<sup>` (e.g. $H_2O$, $CO_2$) or MathML elements (`<math>`).
- **Deterministic ID Generation:** IDs are generated based on element index and tag (e.g. `chap01`, `sec2-1`, `f2.2`, `t5.1`, `eq3.4`, `fn1`, `page_2`).

## 3. Storage & Artifact Management
- Local project artifacts stored in `storage/processing/<project-id>/` and output in `storage/output/<project-id>/`.
- MongoDB collections store structured metadata (projects, pages, figures, tables, equations, cross-references, QA issues, pipeline logs).

## 4. UI / UX Design System
- Strict compliance with simple Government Online Service Portal aesthetic: white background (`#ffffff`), dark gray text (`#1f2937`), simple blue accents (`#1d4ed8`), thin gray borders (`#e5e7eb`), sans-serif system font stack.
- Zero unnecessary animations, zero glassmorphism, zero dark-mode toggles, zero gradients. Highly accessible with ARIA roles and contrast compliance.
